import React, { Component } from 'react'
import Snake from "./Snake.jsx";
import Food from "./Food.jsx";

const getRandomCoordinates = () => {
  let min = 1;
  let max = 98;
  let left = Math.floor((Math.random() * max + min) / 2) * 2;
  let top = Math.floor((Math.random() * max + min) / 2) * 2;
  return [left, top]
}
class App extends Component {
  state = {
    food: getRandomCoordinates(),
    direction: 'RIGHT',
    snakeDots: [
      [0, 0],
      [2, 0]
    ]
  }

  // 键盘事件
  componentDidMount() {
    document.onkeydown = this.onkeydown;
    setInterval(this.snakeMove, 200);
  }
  onkeydown = e => {
    const direciton = this.state.direction;
    const keyCode = {
      37: () => {
        return direciton != 'RIGHT' ? 'LEFT' : direciton
      },
      38: () => {
        return direciton != 'DOWN' ? 'UP' : direciton
      },
      39: () => {
        return direciton != 'LEFT' ? 'RIGHT' : direciton
      },
      40: () => {
        return direciton != 'UP' ? 'DOWN' : direciton
      },
    }
    
    this.setState({
      direction: keyCode[e.keyCode]() || 'RIGHT'
    })
  }
  snakeMove = () => {
    let dots = this.state.snakeDots;
    let head = dots[dots.length - 1];
    const moveObj = {
      'RIGHT': () => {
        head = [head[0] + 2, head[1]];
      },
      'LEFT': () => {
        head = [head[0] - 2, head[1]];
      },
      'UP': () => {
        head = [head[0], head[1] - 2];
      },
      'DOWN': () => {
        head = [head[0], head[1] + 2];
      },
    }
    moveObj[this.state.direction]();
    if (head[0] > 98 || head[1] > 98 || head[0] < 0 || head[1] < 0) {
      alert('GAME OVER');
      return;
    }
    dots.push(head);
    if (head.toString() == this.state.food.toString()) {
      this.setState({
        food: getRandomCoordinates()
      })
    } else {
      dots.shift();
    }
    this.setState({
      snakeDots: dots
    })
  }
  render() {
    return (
      <div className='game-area'>
        <Snake snakeDots = {this.state.snakeDots}></Snake>
        <Food food={this.state.food}></Food>
      </div>
    )
  }
}

export default App;
