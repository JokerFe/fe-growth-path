import React from 'react'

const Food = ({food}) => {
    const styleObj = {
        left: `${food[0]}%`,
        top: `${food[1]}%`,
    }
    return (
        <div className='snake-food' style={styleObj}></div>
    )
}
export default Food;