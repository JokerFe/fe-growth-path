import React from 'react'

const Snake = (props) => {
    return (
        <div>
            {
                props.snakeDots.map((dot, i) => {
                    const styleObj = {
                        top: `${dot[1]}%`,
                        left: `${dot[0]}%`,
                    }
                    return (
                        <div key={i} className='snake-dot' style={styleObj}></div>
                    )
                })
            }
        </div>
    )
}

export default Snake;