import React, { Component } from "react";

class App extends Component {
  render() {
    return (
      <div className="todo-app container">
        <h1 className="center blue-text">任务列表</h1>
      </div>
    );
  }
}

export default App;
