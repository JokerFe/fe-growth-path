import React from "react";
const Todos = ({ todos, deleteItem }) => {
  const todoList = todos.length ? (
    todos.map((todo) => {
      return (
        <div className="collection-item" key={todo.id}>
            <span>{todo.content}</span>
            <button onClick={() => {
                deleteItem(todo.id)
            }}>X</button>
        </div>
      );
    })
  ) : (
    <p className="center">全部完成</p>
  );
  return <div className="todos collection">{todoList}</div>;
};
export default Todos;
