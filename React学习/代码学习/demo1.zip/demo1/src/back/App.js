import React, { Component } from "react";
import "./App.css";
import Todos from "./Todos.js";

class App extends Component {
  state = {
    todos: [
      {
        id: 1,
        content: "a",
      },
      {
        id: 2,
        content: "b",
      },
      {
        id: 3,
        content: "c",
      },
      {
        id: 4,
        content: "d",
      },
    ],
  };
  deleteItem = (id) => {
    const newTodos = this.state.todos.filter((item) => item.id != id);
    this.setState({
      todos: newTodos,
    });
  };
  render() {
    return (
      <div className="todo-app container">
        <h1 className="center blue-text">任务列表</h1>
        <Todos todos={this.state.todos} deleteItem={this.deleteItem}></Todos>
      </div>
    );
  }
}

export default App;
