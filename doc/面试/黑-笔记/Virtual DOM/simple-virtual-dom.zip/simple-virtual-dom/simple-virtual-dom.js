window.svd = require('./index')
