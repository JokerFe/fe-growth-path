exports.el = require('./lib/element')
exports.diff = require('./lib/diff')
exports.patch = require('./lib/patch')
