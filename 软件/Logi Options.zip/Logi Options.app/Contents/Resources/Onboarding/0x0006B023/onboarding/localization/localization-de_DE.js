title0 = "WILLKOMMEN ZU MX MASTER 3"
title0_forMac = "WILLKOMMEN ZU MX MASTER 3 FÜR MAC"
desc0 = "Stellen Sie sich das vor. Beherrschen Sie es."

title1 = "MAGSPEED&#153 SCROLLRAD"
desc1 = "Das Scrollrad wechselt automatisch vom langsamen Bildlauf pro Zeile zum freien Drehmodus, wenn Sie schneller scrollen."

title2 = "MODUS-SCHALTER"
desc2 = "Klicken zum manuellen Wechseln zwischen Präzisionsmodus und Freilaufmodus."

title3 = "GESTEN-SCHALTER"
desc3 = "Klicken und halten Sie die Taste, während Sie die Maus bewegen, um Gesten-Befehle zu verwenden."

title4 = "DAUMENRAD"
desc4 = "Horizontales Scrollen ist möglich mit einer leichten Drehung des Daumenrads."

title5 = "APP-SPEZIFISCHE EINSTELLUNGEN"
desc5 = "Bei der MX Master 3 sind für jede App benutzerdefinierte Einstellungen möglich."

title6 = "VORDEFINIERTE EINSTELLUNGEN"
desc6 = "Bewegen Sie den Mauszeiger über die Symbole, um die vordefinierten Anpassungen zu sehen, die Sie für diese Apps installieren können."

appSpeExample0 = "Horizontaler Bildlauf"
appSpeExample1 = "Zoom"
appSpeExample2 = "Größe des Pinsels"

appTitle_fallback = "ALLE ANDEREN ANWENDUNGEN";

wheel_opt_photoshop = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_premiere = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_finalcutpro = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_chrome = "Link in neuem Tab öffnen";
wheel_opt_safari = "Link in neuem Tab öffnen";
wheel_opt_edge = "Link in neuem Tab öffnen";
wheel_opt_word = "Automatisches Scrollen";
wheel_opt_wordMac = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_excel = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_excelMac = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_powerpoint = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_powerpointMac = "Schwenken (Halten und Bewegen der Maus)";
wheel_opt_msTeams = "Mittlere Taste";
wheel_opt_zoomUS = "Mittlere Taste";
wheel_opt_fallback = "Mittlere Taste";

sideWheel_opt_photoshop = "Größe des Pinsels anpassen";
sideWheel_opt_premiere = "Horizontaler Bildlauf in der Zeitachse";
sideWheel_opt_finalcutpro = "Horizontaler Bildlauf in der Zeitachse";
sideWheel_opt_chrome = "Registerkarten navigieren";
sideWheel_opt_safari = "Registerkarten navigieren";
sideWheel_opt_edge = "Registerkarten navigieren";
sideWheel_opt_word = "Zoom";
sideWheel_opt_excel = "Horizontaler Bildlauf";
sideWheel_opt_powerpoint = "Zoom";
sideWheel_opt_msTeams = "Lautstärkeregelung";
sideWheel_opt_zoomUS = "Lautstärkeregelung";
sideWheel_opt_fallback = "Horizontaler Bildlauf";

forwardButton_opt_photoshop = "Vorgang wiederholen";
forwardButton_opt_premiere = "Vorgang wiederholen";
forwardButton_opt_finalcutpro = "Vorgang wiederholen";
forwardButton_opt_chrome = "Vor";
forwardButton_opt_safari = "Vor";
forwardButton_opt_edge = "Vor";
forwardButton_opt_word = "Vorgang wiederholen";
forwardButton_opt_excel = "Vorgang wiederholen";
forwardButton_opt_powerpoint = "Vorgang wiederholen";
forwardButton_opt_msTeams = "Video starten/stoppen";
forwardButton_opt_zoomUS = "Video starten/stoppen";
forwardButton_opt_fallback = "Vor";

backwardButton_opt_photoshop = "Rückgängig";
backwardButton_opt_premiere = "Rückgängig";
backwardButton_opt_finalcutpro = "Rückgängig";
backwardButton_opt_chrome = "Zurück";
backwardButton_opt_safari = "Zurück";
backwardButton_opt_edge = "Zurück";
backwardButton_opt_word = "Rückgängig";
backwardButton_opt_excel = "Rückgängig";
backwardButton_opt_powerpoint = "Rückgängig";
backwardButton_opt_msTeams = "Mikrofon – Stumm schalten/Stummschaltung aufheben";
backwardButton_opt_zoomUS = "Mikrofon – Stumm schalten/Stummschaltung aufheben";
backwardButton_opt_fallback = "Zurück";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Aufgaben-Ansicht";
gesture_opt_left = "Desktops wechseln";
gesture_opt_right = "Desktops wechseln";
gesture_opt_bottom = "Desktop anzeigen/ausblenden";
gesture_opt_bottomMac = "App-Exposé";

btn_continue = "WEITER";
skip = "ÜBERSPRINGEN";
btn_continueToSetup = "INSTALLATION FORTSETZEN";

btn_back = "ZURÜCK";
btn_next = "WEITER";

link_website = "%logiwebsite%"
