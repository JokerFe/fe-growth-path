title0 = "ДОБРО ПОЖАЛОВАТЬ В MX MASTER 3"
title0_forMac = "ДОБРО ПОЖАЛОВАТЬ В MX MASTER 3 ДЛЯ MAC"
desc0 = "Интеллект. Мастерство."

title1 = "КОЛЕСИКО ПРОКРУТКИ MAGSPEED&#153"
desc1 = "Колесико автоматически переходит из режима построчной прокрутки в режим свободной прокрутки при увеличении скорости вращения."

title2 = "КНОПКА ПЕРЕКЛЮЧЕНИЯ РЕЖИМОВ"
desc2 = "Позволяет вручную переключаться между режимами пошаговой и свободной прокрутки."

title3 = "КНОПКА ЖЕСТОВ"
desc3 = "Для использования жестовых команд необходимо нажать и удерживать кнопку во время перемещения мыши."

title4 = "КОЛЕСИКО ДЛЯ БОЛЬШОГО ПАЛЬЦА"
desc4 = "Колесико обеспечивает горизонтальную прокрутку легкими движениями пальца."

title5 = "НАСТРОЙКИ ДЛЯ КОНКРЕТНЫХ ПРИЛОЖЕНИЙ"
desc5 = "Для работы в каждом из используемых приложений можно задать пользовательские настройки мыши MX Master 3."

title6 = "ПРЕДВАРИТЕЛЬНО ЗАДАННЫЕ НАСТРОЙКИ"
desc6 = "Наведите указатель на значки, чтобы просмотреть предварительно заданные настройки для этих приложений."

appSpeExample0 = "Горизонтальная прокрутка"
appSpeExample1 = "Масштаб"
appSpeExample2 = "Размер кисти"

appTitle_fallback = "ПРОЧИЕ ПРИЛОЖЕНИЯ";

wheel_opt_photoshop = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_premiere = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_finalcutpro = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_chrome = "Открытие ссылки в новой вкладке";
wheel_opt_safari = "Открытие ссылки в новой вкладке";
wheel_opt_edge = "Открытие ссылки в новой вкладке";
wheel_opt_word = "Автоматическая прокрутка";
wheel_opt_wordMac = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_excel = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_excelMac = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_powerpoint = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_powerpointMac = "Панорама (удерживайте нажатой клавишу и перемещайте мышь)";
wheel_opt_msTeams = "Средняя кнопка";
wheel_opt_zoomUS = "Средняя кнопка";
wheel_opt_fallback = "Средняя кнопка";

sideWheel_opt_photoshop = "Регулировка размера кисти";
sideWheel_opt_premiere = "Горизонтальная прокрутка шкалы времени";
sideWheel_opt_finalcutpro = "Горизонтальная прокрутка шкалы времени";
sideWheel_opt_chrome = "Переход между вкладками";
sideWheel_opt_safari = "Переход между вкладками";
sideWheel_opt_edge = "Переход между вкладками";
sideWheel_opt_word = "Масштаб";
sideWheel_opt_excel = "Горизонтальная прокрутка";
sideWheel_opt_powerpoint = "Масштаб";
sideWheel_opt_msTeams = "Регулировка громкости";
sideWheel_opt_zoomUS = "Регулировка громкости";
sideWheel_opt_fallback = "Горизонтальная прокрутка";

forwardButton_opt_photoshop = "Повтор";
forwardButton_opt_premiere = "Повтор";
forwardButton_opt_finalcutpro = "Повтор";
forwardButton_opt_chrome = "Вперед";
forwardButton_opt_safari = "Вперед";
forwardButton_opt_edge = "Вперед";
forwardButton_opt_word = "Повтор";
forwardButton_opt_excel = "Повтор";
forwardButton_opt_powerpoint = "Повтор";
forwardButton_opt_msTeams = "Запустить/остановить видео";
forwardButton_opt_zoomUS = "Запустить/остановить видео";
forwardButton_opt_fallback = "Вперед";

backwardButton_opt_photoshop = "Отмена";
backwardButton_opt_premiere = "Отмена";
backwardButton_opt_finalcutpro = "Отмена";
backwardButton_opt_chrome = "Назад";
backwardButton_opt_safari = "Назад";
backwardButton_opt_edge = "Назад";
backwardButton_opt_word = "Отмена";
backwardButton_opt_excel = "Отмена";
backwardButton_opt_powerpoint = "Отмена";
backwardButton_opt_msTeams = "Отключить/включить микрофон";
backwardButton_opt_zoomUS = "Отключить/включить микрофон";
backwardButton_opt_fallback = "Назад";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Обзор задачи";
gesture_opt_left = "Переключение между рабочими столами";
gesture_opt_right = "Переключение между рабочими столами";
gesture_opt_bottom = "Показ / скрытие рабочего стола";
gesture_opt_bottomMac = "App Exposé";

btn_continue = "ПРОДОЛЖИТЬ";
skip = "ПРОПУСТИТЬ";
btn_continueToSetup = "ПРОДОЛЖИТЬ УСТАНОВКУ";

btn_back = "НАЗАД";
btn_next = "ДАЛЕЕ";

link_website = "%logiwebsite%"
