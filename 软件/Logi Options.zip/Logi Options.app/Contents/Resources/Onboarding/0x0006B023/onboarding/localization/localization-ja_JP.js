title0 = "MX MASTER 3 へようこそ"
title0_forMac = "MAC 用 MX MASTER 3 へようこそ"
desc0 = "考えましょう。 マスターしましょう。"

title1 = "MAGSPEED&#153 スクロールホイール"
desc1 = "スクロールホイールは、速くスクロールすると、1 行ごとのスクロールからフリースピンスクロールに自動的にシフトします。"

title2 = "モードシフトボタン"
desc2 = "クリックして、ラチェットモードとフリースピンモード間を手動で切り替えます。"

title3 = "ジェスチャボタン"
desc3 = "ボタンをクリックしながら動かして、ジェスチャコマンドを使用します。"

title4 = "サムホイール"
desc4 = "サムホイールをそっと回転させると、水平にスクロールします。"

title5 = "アプリ固有の設定"
desc5 = "MX Master 3 には、あらゆるアプリ向けの様々な設定があります。"

title6 = "事前定義済の設定"
desc6 = "アイコン上にマウスカーソルを置くと、これらのアプリ用にインストールできる、事前定義済のカスタマイズが表示されます。"

appSpeExample0 = "水平スクロール"
appSpeExample1 = "ズーム"
appSpeExample2 = "ブラシのサイズ"

appTitle_fallback = "その他のすべてのアプリケーション";

wheel_opt_photoshop = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_premiere = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_finalcutpro = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_chrome = "新しいタブでリンクを開く";
wheel_opt_safari = "新しいタブでリンクを開く";
wheel_opt_edge = "新しいタブでリンクを開く";
wheel_opt_word = "自動スクロール";
wheel_opt_wordMac = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_excel = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_excelMac = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_powerpoint = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_powerpointMac = "パン（ボタンを押したままマウスを動かす）";
wheel_opt_msTeams = "ミドルボタン";
wheel_opt_zoomUS = "ミドルボタン";
wheel_opt_fallback = "ミドルボタン";

sideWheel_opt_photoshop = "ブラシサイズを調整";
sideWheel_opt_premiere = "タイムライン横スクロール";
sideWheel_opt_finalcutpro = "タイムライン横スクロール";
sideWheel_opt_chrome = "タブ間をナビゲート";
sideWheel_opt_safari = "タブ間をナビゲート";
sideWheel_opt_edge = "タブ間をナビゲート";
sideWheel_opt_word = "ズーム";
sideWheel_opt_excel = "水平スクロール";
sideWheel_opt_powerpoint = "ズーム";
sideWheel_opt_msTeams = "音量コントロール";
sideWheel_opt_zoomUS = "音量コントロール";
sideWheel_opt_fallback = "水平スクロール";

forwardButton_opt_photoshop = "やり直す";
forwardButton_opt_premiere = "やり直す";
forwardButton_opt_finalcutpro = "やり直す";
forwardButton_opt_chrome = "進む";
forwardButton_opt_safari = "進む";
forwardButton_opt_edge = "進む";
forwardButton_opt_word = "やり直す";
forwardButton_opt_excel = "やり直す";
forwardButton_opt_powerpoint = "やり直す";
forwardButton_opt_msTeams = "ビデオの開始/停止";
forwardButton_opt_zoomUS = "ビデオの開始/停止";
forwardButton_opt_fallback = "進む";

backwardButton_opt_photoshop = "元に戻す";
backwardButton_opt_premiere = "元に戻す";
backwardButton_opt_finalcutpro = "元に戻す";
backwardButton_opt_chrome = "戻る";
backwardButton_opt_safari = "戻る";
backwardButton_opt_edge = "戻る";
backwardButton_opt_word = "元に戻す";
backwardButton_opt_excel = "元に戻す";
backwardButton_opt_powerpoint = "元に戻す";
backwardButton_opt_msTeams = "マイクのミュート/ミュート解除";
backwardButton_opt_zoomUS = "マイクのミュート/ミュート解除";
backwardButton_opt_fallback = "戻る";

gesture_opt_topMac = "ミッションコントロール";
gesture_opt_top = "タスクビュー";
gesture_opt_left = "デスクトップ間を切り替える";
gesture_opt_right = "デスクトップ間を切り替える";
gesture_opt_bottom = "デスクトップを表示 / 非表示";
gesture_opt_bottomMac = "アプリ Exposé";

btn_continue = "続行";
skip = "スキップ";
btn_continueToSetup = "続行してインストールする";

btn_back = "戻る";
btn_next = "次へ";

link_website = "%logiwebsite%"
