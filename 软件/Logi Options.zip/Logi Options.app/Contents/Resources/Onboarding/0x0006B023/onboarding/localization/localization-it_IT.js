title0 = "BENVENUTO IN MX MASTER 3"
title0_forMac = "BENVENUTO IN MX MASTER 3 PER MAC"
desc0 = "Pensa. Domina."

title1 = "SCROLLER MAGSPEED&#153"
desc1 = "Lo scroller passa automaticamente dallo scorrimento riga per riga alla rotazione libera quando si scorre più velocemente."

title2 = "PULSANTE CAMBIO MODALITÀ"
desc2 = "Fai clic per passare manualmente tra le modalità A scatti e Scorrimento libero."

title3 = "PULSANTE GESTI"
desc3 = "Fai clic e tieni premuto il pulsante mentre sposti il mouse per utilizzare i comandi con gesti."

title4 = "SCROLLER DA POLLICE"
desc4 = "Scorri orizzontalmente con una leggera rotazione di questo scroller da utilizzare con il pollice."

title5 = "IMPOSTAZIONI SPECIFICHE PER APP"
desc5 = "MX Master 3 supporta impostazioni diverse per qualsiasi applicazione che utilizzi."

title6 = "IMPOSTAZIONI PREDEFINITE"
desc6 = "Posiziona il cursore del mouse sopra le icone per visualizzare le personalizzazioni predefinite che puoi installare per le app."

appSpeExample0 = "Scorrimento orizzontale"
appSpeExample1 = "Zoom"
appSpeExample2 = "Dimensioni pennello"

appTitle_fallback = "TUTTE LE ALTRE APPLICAZIONI";

wheel_opt_photoshop = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_premiere = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_finalcutpro = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_chrome = "Apri il collegamento in una nuova scheda";
wheel_opt_safari = "Apri il collegamento in una nuova scheda";
wheel_opt_edge = "Apri il collegamento in una nuova scheda";
wheel_opt_word = "Autoscroll";
wheel_opt_wordMac = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_excel = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_excelMac = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_powerpoint = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_powerpointMac = "Panoramica (tieni premuto e muovi il mouse)";
wheel_opt_msTeams = "Pulsante centrale";
wheel_opt_zoomUS = "Pulsante centrale";
wheel_opt_fallback = "Pulsante centrale";

sideWheel_opt_photoshop = "Regola dimensioni pennello";
sideWheel_opt_premiere = "Scorrimento orizzontale timeline";
sideWheel_opt_finalcutpro = "Scorrimento orizzontale timeline";
sideWheel_opt_chrome = "Navigazione fra schede";
sideWheel_opt_safari = "Navigazione fra schede";
sideWheel_opt_edge = "Navigazione fra schede";
sideWheel_opt_word = "Zoom";
sideWheel_opt_excel = "Scorrimento orizzontale";
sideWheel_opt_powerpoint = "Zoom";
sideWheel_opt_msTeams = "Controllo volume";
sideWheel_opt_zoomUS = "Controllo volume";
sideWheel_opt_fallback = "Scorrimento orizzontale";

forwardButton_opt_photoshop = "Ripeti";
forwardButton_opt_premiere = "Ripeti";
forwardButton_opt_finalcutpro = "Ripeti";
forwardButton_opt_chrome = "Avanti";
forwardButton_opt_safari = "Avanti";
forwardButton_opt_edge = "Avanti";
forwardButton_opt_word = "Ripeti";
forwardButton_opt_excel = "Ripeti";
forwardButton_opt_powerpoint = "Ripeti";
forwardButton_opt_msTeams = "Avvia/Interrompi video";
forwardButton_opt_zoomUS = "Avvia/Interrompi video";
forwardButton_opt_fallback = "Avanti";

backwardButton_opt_photoshop = "Annulla";
backwardButton_opt_premiere = "Annulla";
backwardButton_opt_finalcutpro = "Annulla";
backwardButton_opt_chrome = "Indietro";
backwardButton_opt_safari = "Indietro";
backwardButton_opt_edge = "Indietro";
backwardButton_opt_word = "Annulla";
backwardButton_opt_excel = "Annulla";
backwardButton_opt_powerpoint = "Annulla";
backwardButton_opt_msTeams = "Disattiva/Riattiva audio microfono";
backwardButton_opt_zoomUS = "Disattiva/Riattiva audio microfono";
backwardButton_opt_fallback = "Indietro";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Vista attività";
gesture_opt_left = "Cambia desktop";
gesture_opt_right = "Cambia desktop";
gesture_opt_bottom = "Mostra/nascondi desktop";
gesture_opt_bottomMac = "App Exposé";

btn_continue = "CONTINUA";
skip = "IGNORA";
btn_continueToSetup = "CONTINUA A INSTALLARE";

btn_back = "INDIETRO";
btn_next = "AVANTI";

link_website = "%logiwebsite%"
