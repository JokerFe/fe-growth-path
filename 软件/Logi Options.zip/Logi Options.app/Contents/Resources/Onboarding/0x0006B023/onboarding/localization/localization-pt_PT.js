title0 = "BEM-VINDO AO MX MASTER 3"
title0_forMac = "BEM-VINDO AO MX MASTER 3 PARA MAC"
desc0 = "Pense. Controle."

title1 = "RODA DE DESLOCAMENTO MAGSPEED&#153"
desc1 = "A roda de deslocamento muda automaticamente de deslocamento clique a clique para o deslocamento livre quando desloca mais rápido."

title2 = "BOTÃO DE MUDANÇA DE MODO"
desc2 = "Clique para alternar manualmente entre os modos Clique a clique e Deslocamento livre."

title3 = "BOTÃO DE GESTOS"
desc3 = "Mantenha premido o botão enquanto move o rato para utilizar os comandos de gestos."

title4 = "RODA DE POLEGAR"
desc4 = "Desloque horizontalmente com um toque suave na roda de polegar."

title5 = "DEFINIÇÕES ESPECÍFICAS DA APLICAÇÃO"
desc5 = "O seu MX Master 3 pode ter definições diferentes para qualquer aplicação que utilizar."

title6 = "PREDEFINIÇÕES"
desc6 = "Coloque o cursor do rato sobre os ícones para ver as predefinições personalizadas que pode instalar para estas aplicações."

appSpeExample0 = "Deslocamento horizontal"
appSpeExample1 = "Zoom"
appSpeExample2 = "Tamanho do pincel"

appTitle_fallback = "TODAS AS OUTRAS APLICAÇÕES";

wheel_opt_photoshop = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_premiere = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_finalcutpro = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_chrome = "Abrir ligação num novo separador";
wheel_opt_safari = "Abrir ligação num novo separador";
wheel_opt_edge = "Abrir ligação num novo separador";
wheel_opt_word = "Deslocamento automático";
wheel_opt_wordMac = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_excel = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_excelMac = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_powerpoint = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_powerpointMac = "Deslocar (prima o botão do rato e mova o rato)";
wheel_opt_msTeams = "Botão central";
wheel_opt_zoomUS = "Botão central";
wheel_opt_fallback = "Botão central";

sideWheel_opt_photoshop = "Ajustar o tamanho do pincel";
sideWheel_opt_premiere = "Deslocamento horizontal da linha de tempo";
sideWheel_opt_finalcutpro = "Deslocamento horizontal da linha de tempo";
sideWheel_opt_chrome = "Navegar entre separadores";
sideWheel_opt_safari = "Navegar entre separadores";
sideWheel_opt_edge = "Navegar entre separadores";
sideWheel_opt_word = "Zoom";
sideWheel_opt_excel = "Deslocamento horizontal";
sideWheel_opt_powerpoint = "Zoom";
sideWheel_opt_msTeams = "Controlo de volume";
sideWheel_opt_zoomUS = "Controlo de volume";
sideWheel_opt_fallback = "Deslocamento horizontal";

forwardButton_opt_photoshop = "Refazer";
forwardButton_opt_premiere = "Refazer";
forwardButton_opt_finalcutpro = "Refazer";
forwardButton_opt_chrome = "Avançar";
forwardButton_opt_safari = "Avançar";
forwardButton_opt_edge = "Avançar";
forwardButton_opt_word = "Refazer";
forwardButton_opt_excel = "Refazer";
forwardButton_opt_powerpoint = "Refazer";
forwardButton_opt_msTeams = "Iniciar/Parar vídeo";
forwardButton_opt_zoomUS = "Iniciar/Parar vídeo";
forwardButton_opt_fallback = "Avançar";

backwardButton_opt_photoshop = "Anular";
backwardButton_opt_premiere = "Anular";
backwardButton_opt_finalcutpro = "Anular";
backwardButton_opt_chrome = "Retroceder";
backwardButton_opt_safari = "Retroceder";
backwardButton_opt_edge = "Retroceder";
backwardButton_opt_word = "Anular";
backwardButton_opt_excel = "Anular";
backwardButton_opt_powerpoint = "Anular";
backwardButton_opt_msTeams = "Desactivar/Activar o microfone";
backwardButton_opt_zoomUS = "Desactivar/Activar o microfone";
backwardButton_opt_fallback = "Retroceder";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Vista de tarefas";
gesture_opt_left = "Alternar entre ambientes de trabalho";
gesture_opt_right = "Alternar entre ambientes de trabalho";
gesture_opt_bottom = "Mostrar/Ocultar ambiente de trabalho";
gesture_opt_bottomMac = "Aplicação Exposé";

btn_continue = "CONTINUAR";
skip = "IGNORAR";
btn_continueToSetup = "CONTINUE PARA INSTALAR";

btn_back = "RETROCEDER";
btn_next = "SEGUINTE";

link_website = "%logiwebsite%"
