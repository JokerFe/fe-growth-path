var screenNb = 0;
var start;
var mainOverlay,
  functionDescription,
  appSpecificTextBlock;
var globalInterval = -1;
var hoverInterval = -1;
var incr = 0;
var appAmount,
  slides;

window.onload = function() {
  document.addEventListener('contextmenu', event => event.preventDefault());
  slides = document.getElementsByClassName('screens');
  mainOverlay = document.getElementsByClassName("mainOverlay");
  functionDescription = document.getElementsByClassName('functionDescription');
  appSpecificTextBlock = document.getElementsByClassName('appSpecificTextBlock');
  var mouseImg = document.getElementsByClassName("mouseImg");
  var mouseParam = (query('mouse') != null)
    ? (query('mouse').toLowerCase())
    : "0x0006B023_0x0000";
  var mouseExtendedID = mouseParam.split('_');
  var mouseColor = (mouseExtendedID.length == 2)
    ? (mouseExtendedID[1][mouseExtendedID[1].length - 1])
    : "0";
  for (var i = 0; i < mouseImg.length; i++) {
    var path = "resources/productImg/" + mouseColor;
    mouseImg[i].src = path + "/01.png";
  }
  document.getElementsByClassName("GestureInfoImg")[0].children[0].src = path + "/02.png";
  var os = (query('os') != null)
    ? (query('os').toLowerCase())
    : "windows";
  if (os == "windows") {
    appAmount = 10;
    gesture_opt_bottom = gesture_opt_bottom;
    gesture_opt_top = gesture_opt_top;
    var finalcutpro = document.getElementsByClassName('finalcutpro');
    var safari = document.getElementsByClassName('safari');
    for (var i = 0; i < finalcutpro.length; i++) {
      finalcutpro[i].parentNode.removeChild(finalcutpro[i]);
    }
    for (var i = 0; i < safari.length; i++) {
      safari[i].parentNode.removeChild(safari[i]);
    }
  } else {
    appAmount = 11;
    var edge = document.getElementsByClassName('edge');
    for (var i = 0; i < edge.length; i++) {
      edge[i].parentNode.removeChild(edge[i]);
    }
    gesture_opt_top = gesture_opt_topMac;
    gesture_opt_bottom = gesture_opt_bottomMac;
    wheel_opt_word = wheel_opt_wordMac;
    wheel_opt_excel = wheel_opt_excelMac;
    wheel_opt_powerpoint = wheel_opt_powerpointMac;
  }
  if (mouseColor == 3) {
    title0 = title0_forMac;
  }
  replaceString();
  slideMove(0);
  appSelect(0);

  for (var i = 0; i < slides.length - 1; i++) { //-2 instead of 1 becasue of direct jump to Options
    let dot = document.createElement("div");
    dot.id = i;
    dot.onclick = function() {
      jumpto(parseInt(this.id) + 1);
    }
    document.getElementById("caroussel").appendChild(dot);
  }

  start = true;
  setTimeout(function() {
    document.getElementById("screen0").classList.add("fadeIn");
    document.getElementById("screen0").getElementsByClassName("mouseImg")[0].style.top = "134px";
  }, 500);
  document.getElementById("movingMouse").addEventListener("transitionend", mouseMoved, false);
};

function slideMove(e) {
  console.log("slide moved to : ");
  var movingMousePos = [
    0,
    300,
    250,
    499,
    389,
    67,
    389
  ];

  // 381 x 457
  // 250 x 300
  //var movingMousePos = [0, 447, -447, 447, 447, -447, -1200];
  screenNb += e;

  console.log(screenNb);
  let caroussel = document.getElementById("caroussel");
  for (var i = 0; i < mainOverlay.length; i++) {
    mainOverlay[i].classList.remove("fadeIn");
  }
  document.getElementById("keyline").classList.remove("growLine");
  // document.getElementById("keyline").style.width = "0px";

  for (var i = 0; i < document.getElementsByClassName("appSpecificOverlay")[0].children.length; i++) {
    document.getElementsByClassName("appSpecificOverlay")[0].children[i].classList.remove("fadeIn");
  }
  if (screenNb > 0 && screenNb <= 6) {
    document.getElementById("movingMouse").style.left = movingMousePos[screenNb].toString() + "px";
    document.getElementById("movingMouse").classList.add("fadeIn");
    if (screenNb >= 5) {
      document.getElementById("movingMouse").style.height = "300px";
      document.getElementById("movingMouse").style.width = "250px";
    } else {
      document.getElementById("movingMouse").style.height = "457px";
      document.getElementById("movingMouse").style.width = "381px";
    }
    if (screenNb == 5) {
      for (var i = 0; i < document.getElementsByClassName("appSpecificOverlay")[0].children.length; i++) {
        document.getElementsByClassName("appSpecificOverlay")[0].children[i].style.display = "inline-block";
      }
    }
    if (screenNb == 6) {
      if (globalInterval) {
        clearInterval(globalInterval);
      }
      globalInterval = setInterval(appSpeTransition, 1750);

      document.getElementById("movingMouse").style.top = "240px";
    } else {
      document.getElementById("movingMouse").style.top = "50%";
    }
    for (var i = 0; i < caroussel.children.length; i++) {
      caroussel.children[i].classList.remove("activeDot");
    }
    caroussel.children[screenNb - 1].classList.add("activeDot");
  }
  if (screenNb > 0) {
    mainOverlay[screenNb - 1].style.display = "block";
  }

  //remove navigation
  if (screenNb > 6 || screenNb <= 0) {
    caroussel.style.display = "none";
    document.getElementById("back").style.display = "none";
    document.getElementById("next").style.display = "none";
  } else {
    caroussel.style.display = "flex";
    //remove back on first page
    if (screenNb != 1) {
      document.getElementById("back").style.display = "block";
    } else {
      document.getElementById("back").style.display = "none";
    }
    document.getElementById("next").style.display = "block";
  }

  if (screenNb >= 6) {
    document.getElementById("movingMouse").style.left = movingMousePos[movingMousePos.length - 1] + "px";
    document.getElementById("skipbutton").style.display = "none";
    document.getElementById("next").style.display = "none";
    document.getElementById("continueToSetup").style.display = "inline-block";
  } else {
    if (screenNb > 0) {
      document.getElementById("next").style.display = "inline-block";
    }
    document.getElementById("continueToSetup").style.display = "none";
    document.getElementById("skipbutton").style.display = "block";
  }

  var id = 'screen' + (
  screenNb).toString();
  var displaySlide = document.getElementById(id);

  for (var i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  for (var i = 0; i < functionDescription.length; i++) {
    functionDescription[i].classList.remove("fadeIn");
  }
  document.getElementById("appSpecificBlock").classList.remove("fadeIn");

  displaySlide.style.display = 'block';
}

function mouseMoved() {
  console.log("overlay: ");

  if (screenNb <= 6) {
    console.log(screenNb - 1);
    mainOverlay[screenNb - 1].classList.add("fadeIn");
    if (screenNb > 0) {
      document.getElementById("screen" + screenNb.toString()).getElementsByClassName("functionDescription")[0].classList.add("fadeIn");
      for (var i = 0; i < appSpecificTextBlock.length; i++) {
        appSpecificTextBlock[i]
      }
      for (var i = 0; i < document.getElementById("screen" + screenNb.toString()).getElementsByClassName("appSpecificTextBlock").length; i++) {
        document.getElementById("screen" + screenNb.toString()).getElementsByClassName("appSpecificTextBlock")[i].classList.add("fadeIn");
      }
    }
    if (screenNb == 5) {
      document.getElementById("keyline").classList.add("growLine");
      for (var i = 0; i < document.getElementsByClassName("appSpecificOverlay")[0].children.length; i++) {
        console.log(document.getElementsByClassName("appSpecificOverlay")[0].children[i]);
        document.getElementsByClassName("appSpecificOverlay")[0].children[i].classList.add("fadeIn");
      }
    }
    if (screenNb == 6) {
      document.getElementById("appSpecificBlock").classList.add("fadeIn");
    }
  } else {
    document.getElementById("movingMouse").classList.remove("fadeIn");
    document.getElementById("screen6").classList.add("fadeIn");
    mainOverlay[screenNb - 1].classList.add("fadeIn");
  }
  if (screenNb != 6 && !start) {
    console.log("lcreared transition");
    if (globalInterval) {
      clearInterval(globalInterval);
    }
    document.getElementById("appSpecificBlock").classList.remove("fadeIn");
    const el = document.getElementById("screen5").getElementsByClassName("overlays");
    for (var i = 0; i < el.length; i++) {
      console.log(el[i]);
      el[i].classList.remove("fadeIn");
    }
  }
  if (screenNb != 5 && !start) {
    const el = document.getElementById("screen5").getElementsByClassName("overlays");
    for (var i = 0; i < el.length; i++) {
      console.log(el[i]);
      el[i].classList.remove("fadeIn");
    }
    const el2 = document.getElementById("screen5").getElementsByClassName("appSpecificOverlay")[0].children;
    console.log(el2);
    for (var i = 0; i < el2.length; i++) {
      el2[i].classList.remove("fadeIn");
    }
  }
  if (screenNb != 4 && !start) {
    el = document.getElementById("screen4").getElementsByClassName("overlays");
    for (var i = 0; i < el.length; i++) {
      console.log(el[i]);
      el[i].classList.remove("fadeIn");
    }
  }
  if (screenNb != 3 && !start) {
    document.getElementById("screen3").getElementsByClassName("overlays")[0].classList.remove("fadeIn");
  }

  if (screenNb != 2 && !start) {
    var el = document.getElementById("screen2").getElementsByClassName("overlays");

    for (var i = 0; i < el.length; i++) {
      el[i].classList.remove("fadeIn");
      el[i].classList.add("dryStop");
    }
  }
  if (screenNb != 1 && !start) {
    document.getElementById("screen1").getElementsByClassName("overlays")[0].classList.remove("fadeIn");
  }
  if (screenNb != 0 && !start) {
    document.getElementById("screen0").getElementsByClassName("overlays")[0].classList.remove("fadeIn");
  }
}

// ----------------------------------------------------------------------------------------
function jumpto(slide) {
  screenNb = slide;
  slideMove(0);
}

function iconSelected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next') || el.getElementsByTagName('div')[0].classList.contains('btn_continueToSetup')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRightSelected.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeftSelected.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/closeSelected.png";
  }
}

function iconDeselected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next') || el.getElementsByTagName('div')[0].classList.contains('btn_continueToSetup')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRight.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeft.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/close.png";
  }
}

function appSelect(app) {
  const appIcons = document.getElementsByClassName('appIcons');
  const appTitle = document.getElementsByClassName('appTitle');
  const wheel_opt = document.getElementsByClassName('wheel_opt');
  const sideWheel_opt = document.getElementsByClassName('sideWheel_opt');
  const forwardButton_opt = document.getElementsByClassName('forwardButton_opt');
  const backwardButton_opt = document.getElementsByClassName('backwardButton_opt');
  for (var i = 0; i < appIcons.length; i++) {
    appIcons[i].style.opacity = .5;
  }
  for (var i = 0; i < appTitle.length; i++) {
    appTitle[i].style.display = "none";
  }
  for (var i = 0; i < wheel_opt.length; i++) {
    wheel_opt[i].style.display = "none";
  }
  for (var i = 0; i < sideWheel_opt.length; i++) {
    sideWheel_opt[i].style.display = "none";
  }
  for (var i = 0; i < backwardButton_opt.length; i++) {
    backwardButton_opt[i].style.display = "none";
  }
  for (var i = 0; i < forwardButton_opt.length; i++) {
    forwardButton_opt[i].style.display = "none";
  }
  if (app == undefined) {
    console.log("app is undefined");
    document.getElementsByClassName('chrome')[0].style.opacity = 1;
    document.getElementsByClassName('appTitle_chrome')[0].style.display = "block";
    document.getElementsByClassName('wheel_opt_chrome')[0].style.display = "block";
    document.getElementsByClassName('sideWheel_opt_chrome')[0].style.display = "block";
    document.getElementsByClassName('forwardButton_opt_chrome')[0].style.display = "block";
    document.getElementsByClassName('backwardButton_opt_chrome')[0].style.display = "block";
  } else {
    console.log(app);
    document.getElementsByClassName("appIcons")[app].style.opacity = 1;
    const appName = document.getElementsByClassName("appIcons")[app].classList[1];
    const titleToLoad = document.getElementsByClassName('appTitle_' + appName);
    const wheel_optToLoad = document.getElementsByClassName('wheel_opt_' + appName);
    const sideWheel_optToLoad = document.getElementsByClassName('sideWheel_opt_' + appName);
    const forwardButton_optToLoad = document.getElementsByClassName('forwardButton_opt_' + appName);
    const backwardButton_optToLoad = document.getElementsByClassName('backwardButton_opt_' + appName);

    titleToLoad[0].style.display = "block";
    wheel_optToLoad[0].style.display = "block";
    sideWheel_optToLoad[0].style.display = "block";
    forwardButton_optToLoad[0].style.display = "block";
    backwardButton_optToLoad[0].style.display = "block";
  }
}
function appSelected(e) {
  if (globalInterval) {
    clearInterval(globalInterval);
  }
  if (e > 0) {
    incr = e - 1;
  } else {
    incr = 0;
  }

  if (appAmount < 11 && e > 7) {
    incr = e - 2;
  }

  if (e == 1) {
    incr = 1;
  }

  appSelect(incr);
}
function appDeselected() {
  if (globalInterval) {
    clearInterval(globalInterval);
  }
  globalInterval = setInterval(appSpeTransition, 1750);
}
function appSpeTransition() {
  incr++;
  incr %= appAmount;
  console.log(incr);
  appSelect(incr);
}
