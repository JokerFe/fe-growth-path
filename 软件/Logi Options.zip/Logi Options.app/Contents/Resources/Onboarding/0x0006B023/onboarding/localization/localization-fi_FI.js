title0 = "TERVETULOA KÄYTTÄMÄÄN MX MASTER 3:A"
title0_forMac = "TERVETULOA KÄYTTÄMÄÄN MX MASTER 3:LLE MACille"
desc0 = "Ajattele se. Ota se haltuun."

title1 = "MAGSPEED&#153 -VIERITYSPYÖRÄ"
desc1 = "Vierityspyörä siirtyy automaattisesti rivinvaihdosta vapaaksi pyöriväksi, kun selaat nopeammin."

title2 = "TILANVAIHDIN"
desc2 = "Voit vaihtaa napsauttamalla asteittaisen ja vapaan pyörimisen välillä."

title3 = "ELEPAINIKE"
desc3 = "Käytä elekomentoja painamalla pitkään painiketta hiirtä liikutettaessa."

title4 = "PEUKALORULLA"
desc4 = "Selaa vaakasuunnassa kevyesti peukalorullaa kääntämällä."

title5 = "SOVELLUSKOHTAISET ASETUKSET"
desc5 = "MX Master 3:n asetuksia voi vaihtaa mihin tahansa sovellukseen."

title6 = "ESIMÄÄRITETYT ASETUKSET"
desc6 = "Vie hiiri kuvakkeiden päälle, niin näet esimääritetyt mukautukset, jotka näihin sovelluksiin voi asentaa."

appSpeExample0 = "Vaakavieritys"
appSpeExample1 = "Zoomaus"
appSpeExample2 = "Siveltimen koko"

appTitle_fallback = "KAIKKI MUUT SOVELLUKSET";

wheel_opt_photoshop = "Panoroi (liikuta hiirtä)";
wheel_opt_premiere = "Panoroi (liikuta hiirtä)";
wheel_opt_finalcutpro = "Panoroi (liikuta hiirtä)";
wheel_opt_chrome = "Avaa linkki uudessa välilehdessä";
wheel_opt_safari = "Avaa linkki uudessa välilehdessä";
wheel_opt_edge = "Avaa linkki uudessa välilehdessä";
wheel_opt_word = "Automaattinen vieritys";
wheel_opt_wordMac = "Panoroi (liikuta hiirtä)";
wheel_opt_excel = "Panoroi (liikuta hiirtä)";
wheel_opt_excelMac = "Panoroi (liikuta hiirtä)";
wheel_opt_powerpoint = "Panoroi (liikuta hiirtä)";
wheel_opt_powerpointMac = "Panoroi (liikuta hiirtä)";
wheel_opt_msTeams = "Keskipainike";
wheel_opt_zoomUS = "Keskipainike";
wheel_opt_fallback = "Keskipainike";

sideWheel_opt_photoshop = "Säädä harjan kokoa";
sideWheel_opt_premiere = "Aikajanan vaakavieritys";
sideWheel_opt_finalcutpro = "Aikajanan vaakavieritys";
sideWheel_opt_chrome = "Siirry välilehtien välillä";
sideWheel_opt_safari = "Siirry välilehtien välillä";
sideWheel_opt_edge = "Siirry välilehtien välillä";
sideWheel_opt_word = "Zoomaus";
sideWheel_opt_excel = "Vaakavieritys";
sideWheel_opt_powerpoint = "Zoomaus";
sideWheel_opt_msTeams = "Äänenvoimakkuuden säätö";
sideWheel_opt_zoomUS = "Äänenvoimakkuuden säätö";
sideWheel_opt_fallback = "Vaakavieritys";

forwardButton_opt_photoshop = "Tee uudelleen";
forwardButton_opt_premiere = "Tee uudelleen";
forwardButton_opt_finalcutpro = "Tee uudelleen";
forwardButton_opt_chrome = "Eteenpäin";
forwardButton_opt_safari = "Eteenpäin";
forwardButton_opt_edge = "Eteenpäin";
forwardButton_opt_word = "Tee uudelleen";
forwardButton_opt_excel = "Tee uudelleen";
forwardButton_opt_powerpoint = "Tee uudelleen";
forwardButton_opt_msTeams = "Käynnistä/pysäytä video";
forwardButton_opt_zoomUS = "Käynnistä/pysäytä video";
forwardButton_opt_fallback = "Eteenpäin";

backwardButton_opt_photoshop = "Kumoa";
backwardButton_opt_premiere = "Kumoa";
backwardButton_opt_finalcutpro = "Kumoa";
backwardButton_opt_chrome = "Takaisin";
backwardButton_opt_safari = "Takaisin";
backwardButton_opt_edge = "Takaisin";
backwardButton_opt_word = "Kumoa";
backwardButton_opt_excel = "Kumoa";
backwardButton_opt_powerpoint = "Kumoa";
backwardButton_opt_msTeams = "Vaimenna mikrofoni / poista vaimennus";
backwardButton_opt_zoomUS = "Vaimenna mikrofoni / poista vaimennus";
backwardButton_opt_fallback = "Takaisin";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Tehtävänäkymä";
gesture_opt_left = "Vaihtele työpöytien välillä";
gesture_opt_right = "Vaihtele työpöytien välillä";
gesture_opt_bottom = "Näytä/piilota työpöytä";
gesture_opt_bottomMac = "App Exposé";

btn_continue = "JATKA";
skip = "OHITA";
btn_continueToSetup = "JATKA ASENNUKSEEN";

btn_back = "TAKAISIN";
btn_next = "SEURAAVA";

link_website = "%logiwebsite%"
