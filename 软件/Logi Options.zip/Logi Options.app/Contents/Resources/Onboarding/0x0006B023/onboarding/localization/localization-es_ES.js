title0 = "BIENVENIDO A MX MASTER 3"
title0_forMac = "BIENVENIDO A MX MASTER 3 PARA MAC"
desc0 = "Piénselo. Domínelo."

title1 = "BOTÓN RUEDA MAGSPEED&#153"
desc1 = "Al accionarlo con rapidez, el botón rueda cambia automáticamente de desplazamiento línea a línea a giro libre."

title2 = "BOTÓN DE CAMBIO DE MODO"
desc2 = "Haga clic para alternar manualmente entre los modos de giro gradual y giro libre."

title3 = "BOTÓN DE GESTOS"
desc3 = "Mantenga pulsado el botón mientras mueve el ratón para usar comandos de gestos."

title4 = "BOTÓN PARA EL PULGAR"
desc4 = "Desplácese horizontalmente con un leve giro del botón para el pulgar."

title5 = "CONFIGURACIÓN ESPECÍFICA DE APLICACIÓN"
desc5 = "MX Master 3 puede tener una configuración distinta para cada aplicación con la que se use."

title6 = "CONFIGURACIÓN PREDEFINIDA"
desc6 = "Pase el ratón sobre los iconos para ver las personalizaciones predefinidas que puede instalar para estas aplicaciones."

appSpeExample0 = "Desplazamiento horizontal"
appSpeExample1 = "Zoom"
appSpeExample2 = "Tamaño de pincel"

appTitle_fallback = "OTRAS APLICACIONES";

wheel_opt_photoshop = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_premiere = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_finalcutpro = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_chrome = "Abrir vínculo en una pestaña nueva";
wheel_opt_safari = "Abrir vínculo en una pestaña nueva";
wheel_opt_edge = "Abrir vínculo en una pestaña nueva";
wheel_opt_word = "AutoScroll";
wheel_opt_wordMac = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_excel = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_excelMac = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_powerpoint = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_powerpointMac = "Panorámica (mantener pulsación y mover ratón)";
wheel_opt_msTeams = "Botón central";
wheel_opt_zoomUS = "Botón central";
wheel_opt_fallback = "Botón central";

sideWheel_opt_photoshop = "Ajustar tamaño del pincel";
sideWheel_opt_premiere = "Desplazamiento horizontal en línea de tiempo";
sideWheel_opt_finalcutpro = "Desplazamiento horizontal en línea de tiempo";
sideWheel_opt_chrome = "Navegar entre fichas";
sideWheel_opt_safari = "Navegar entre fichas";
sideWheel_opt_edge = "Navegar entre fichas";
sideWheel_opt_word = "Zoom";
sideWheel_opt_excel = "Desplazamiento horizontal";
sideWheel_opt_powerpoint = "Zoom";
sideWheel_opt_msTeams = "Control de volumen";
sideWheel_opt_zoomUS = "Control de volumen";
sideWheel_opt_fallback = "Desplazamiento horizontal";

forwardButton_opt_photoshop = "Rehacer";
forwardButton_opt_premiere = "Rehacer";
forwardButton_opt_finalcutpro = "Rehacer";
forwardButton_opt_chrome = "Adelante";
forwardButton_opt_safari = "Adelante";
forwardButton_opt_edge = "Adelante";
forwardButton_opt_word = "Rehacer";
forwardButton_opt_excel = "Rehacer";
forwardButton_opt_powerpoint = "Rehacer";
forwardButton_opt_msTeams = "Iniciar/Detener vídeo";
forwardButton_opt_zoomUS = "Iniciar/Detener vídeo";
forwardButton_opt_fallback = "Adelante";

backwardButton_opt_photoshop = "Deshacer";
backwardButton_opt_premiere = "Deshacer";
backwardButton_opt_finalcutpro = "Deshacer";
backwardButton_opt_chrome = "Atrás";
backwardButton_opt_safari = "Atrás";
backwardButton_opt_edge = "Atrás";
backwardButton_opt_word = "Deshacer";
backwardButton_opt_excel = "Deshacer";
backwardButton_opt_powerpoint = "Deshacer";
backwardButton_opt_msTeams = "Silenciar/Reactivar micrófono";
backwardButton_opt_zoomUS = "Silenciar/Reactivar micrófono";
backwardButton_opt_fallback = "Atrás";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Vista de tareas";
gesture_opt_left = "Alternar entre escritorios";
gesture_opt_right = "Alternar entre escritorios";
gesture_opt_bottom = "Mostrar / Ocultar escritorio";
gesture_opt_bottomMac = "Aplicación Exposé";

btn_continue = "CONTINUAR";
skip = "OMITIR";
btn_continueToSetup = "INSTALAR";

btn_back = "ATRÁS";
btn_next = "SIGUIENTE";

link_website = "%logiwebsite%"
