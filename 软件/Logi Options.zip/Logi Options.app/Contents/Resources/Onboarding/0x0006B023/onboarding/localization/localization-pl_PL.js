title0 = "MYSZ MX MASTER 3 — ZAPRASZAMY!"
title0_forMac = "MYSZ MX MASTER 3 DLA SYSTEMU MAC — ZAPRASZAMY!"
desc0 = "Przemyśl. Opanuj."

title1 = "KÓŁKO PRZEWIJANIA MAGSPEED&#153"
desc1 = "Kółko przewijania automatycznie przełącza się z przewijania wiersz po wierszu w tryb swobodnego obrotu, gdy przewijasz szybciej."

title2 = "PRZYCISK ZMIANY TRYBU"
desc2 = "Kliknij, aby ręcznie przełączać między trybem zapadkowym i swobodnym."

title3 = "PRZYCISK GESTÓW"
desc3 = "Kliknij i przytrzymaj przycisk, poruszając myszą, aby użyć poleceń opartych na gestach."

title4 = "KÓŁKO OBSŁUGIWANE KCIUKIEM"
desc4 = "Przewijaj w poziomie, delikatnie obracając kółkiem obsługiwanym kciukiem."

title5 = "USTAWIENIA SPECYFICZNE DLA APLIKACJI"
desc5 = "Mysz MX Master 3 pozwala skonfigurować różne ustawienia dla każdej używanej aplikacji."

title6 = "USTAWIENIA WSTĘPNE"
desc6 = "Najedź kursorem na ikony, aby zobaczyć wstępnie zdefiniowane ustawienia, które można zainstalować dla danych aplikacji."

appSpeExample0 = "Przewijanie w poziomie"
appSpeExample1 = "Powiększ"
appSpeExample2 = "Rozmiar pędzla"

appTitle_fallback = "WSZYSTKIE INNE APLIKACJE";

wheel_opt_photoshop = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_premiere = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_finalcutpro = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_chrome = "Otwórz łącze w nowej karcie";
wheel_opt_safari = "Otwórz łącze w nowej karcie";
wheel_opt_edge = "Otwórz łącze w nowej karcie";
wheel_opt_word = "Przewijanie automatyczne";
wheel_opt_wordMac = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_excel = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_excelMac = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_powerpoint = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_powerpointMac = "Pan (przytrzymaj i poruszaj myszą)";
wheel_opt_msTeams = "Środkowy przycisk";
wheel_opt_zoomUS = "Środkowy przycisk";
wheel_opt_fallback = "Środkowy przycisk";

sideWheel_opt_photoshop = "Zmień rozmiar pędzla";
sideWheel_opt_premiere = "Przewijanie osi czasu w poziomie";
sideWheel_opt_finalcutpro = "Przewijanie osi czasu w poziomie";
sideWheel_opt_chrome = "Nawigacja między kartami";
sideWheel_opt_safari = "Nawigacja między kartami";
sideWheel_opt_edge = "Nawigacja między kartami";
sideWheel_opt_word = "Powiększ";
sideWheel_opt_excel = "Przewijanie w poziomie";
sideWheel_opt_powerpoint = "Powiększ";
sideWheel_opt_msTeams = "Sterowanie głośnością";
sideWheel_opt_zoomUS = "Sterowanie głośnością";
sideWheel_opt_fallback = "Przewijanie w poziomie";

forwardButton_opt_photoshop = "Powtórz";
forwardButton_opt_premiere = "Powtórz";
forwardButton_opt_finalcutpro = "Powtórz";
forwardButton_opt_chrome = "Do przodu";
forwardButton_opt_safari = "Do przodu";
forwardButton_opt_edge = "Do przodu";
forwardButton_opt_word = "Powtórz";
forwardButton_opt_excel = "Powtórz";
forwardButton_opt_powerpoint = "Powtórz";
forwardButton_opt_msTeams = "Start/Stop filmu";
forwardButton_opt_zoomUS = "Start/Stop filmu";
forwardButton_opt_fallback = "Do przodu";

backwardButton_opt_photoshop = "Cofnij";
backwardButton_opt_premiere = "Cofnij";
backwardButton_opt_finalcutpro = "Cofnij";
backwardButton_opt_chrome = "Do tyłu";
backwardButton_opt_safari = "Do tyłu";
backwardButton_opt_edge = "Do tyłu";
backwardButton_opt_word = "Cofnij";
backwardButton_opt_excel = "Cofnij";
backwardButton_opt_powerpoint = "Cofnij";
backwardButton_opt_msTeams = "Wycisz/odcisz mikrofon";
backwardButton_opt_zoomUS = "Wycisz/odcisz mikrofon";
backwardButton_opt_fallback = "Do tyłu";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Widok zadań";
gesture_opt_left = "Przełącz między pulpitami";
gesture_opt_right = "Przełącz między pulpitami";
gesture_opt_bottom = "Pokaż/Ukryj pulpit";
gesture_opt_bottomMac = "App Exposé";

btn_continue = "KONTYNUUJ";
skip = "POMIŃ";
btn_continueToSetup = "KONTYNUUJ, ABY ZAINSTALOWAĆ";

btn_back = "DO TYŁU";
btn_next = "DALEJ";

link_website = "%logiwebsite%"
