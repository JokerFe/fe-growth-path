title0 = "VÄLKOMMEN TILL MX MASTER 3"
title0_forMac = "VÄLKOMMEN TILL MX MASTER 3 FÖR MAC"
desc0 = "Tänk det. Bemästra det."

title1 = "MAGSPEED&#153 – RULLNINGSHJUL"
desc1 = "Rullningshjulet växlar automatiskt från linje-till-linje till fri rullning när du rullar snabbare."

title2 = "KNAPPEN LÄGESVÄXLING"
desc2 = "Klicka för att manuellt växla mellan lägena Precision och Fri rullning."

title3 = "GESTKNAPPEN"
desc3 = "Klicka och håll ned knappen när du flyttar musen för att använda gestkommandon."

title4 = "TUMJHUL"
desc4 = "Rulla horisontellt med en försiktig vridning av tumhjulet."

title5 = "APPSPECIFIKA INSTÄLLNINGAR"
desc5 = "Din MX Master 3 kan ha olika inställningar för alla appar du använder."

title6 = "FÖRDEFINIERADE INSTÄLLNINGAR"
desc6 = "Håll muspekaren över ikonerna för att se de fördefinierade anpassningar du kan installera för dessa appar."

appSpeExample0 = "Horisontell rullning"
appSpeExample1 = "Zooma"
appSpeExample2 = "Penselstorlek"

appTitle_fallback = "ALLA ANDRA APPLIKATIONER";

wheel_opt_photoshop = "Panorera (håll och flytta mus)";
wheel_opt_premiere = "Panorera (håll och flytta mus)";
wheel_opt_finalcutpro = "Panorera (håll och flytta mus)";
wheel_opt_chrome = "Öppna länk i ny flik";
wheel_opt_safari = "Öppna länk i ny flik";
wheel_opt_edge = "Öppna länk i ny flik";
wheel_opt_word = "Rulla automatiskt";
wheel_opt_wordMac = "Panorera (håll och flytta mus)";
wheel_opt_excel = "Panorera (håll och flytta mus)";
wheel_opt_excelMac = "Panorera (håll och flytta mus)";
wheel_opt_powerpoint = "Panorera (håll och flytta mus)";
wheel_opt_powerpointMac = "Panorera (håll och flytta mus)";
wheel_opt_msTeams = "Mittknapp";
wheel_opt_zoomUS = "Mittknapp";
wheel_opt_fallback = "Mittknapp";

sideWheel_opt_photoshop = "Justera penselstorlek";
sideWheel_opt_premiere = "Tidslinje horisontell rullning";
sideWheel_opt_finalcutpro = "Tidslinje horisontell rullning";
sideWheel_opt_chrome = "Navigera mellan appar";
sideWheel_opt_safari = "Navigera mellan appar";
sideWheel_opt_edge = "Navigera mellan appar";
sideWheel_opt_word = "Zooma";
sideWheel_opt_excel = "Horisontell rullning";
sideWheel_opt_powerpoint = "Zooma";
sideWheel_opt_msTeams = "Volymkontroll";
sideWheel_opt_zoomUS = "Volymkontroll";
sideWheel_opt_fallback = "Horisontell rullning";

forwardButton_opt_photoshop = "Gör om";
forwardButton_opt_premiere = "Gör om";
forwardButton_opt_finalcutpro = "Gör om";
forwardButton_opt_chrome = "Framåt";
forwardButton_opt_safari = "Framåt";
forwardButton_opt_edge = "Framåt";
forwardButton_opt_word = "Gör om";
forwardButton_opt_excel = "Gör om";
forwardButton_opt_powerpoint = "Gör om";
forwardButton_opt_msTeams = "Starta/stoppa video";
forwardButton_opt_zoomUS = "Starta/stoppa video";
forwardButton_opt_fallback = "Framåt";

backwardButton_opt_photoshop = "Ångra";
backwardButton_opt_premiere = "Ångra";
backwardButton_opt_finalcutpro = "Ångra";
backwardButton_opt_chrome = "Tillbaka";
backwardButton_opt_safari = "Tillbaka";
backwardButton_opt_edge = "Tillbaka";
backwardButton_opt_word = "Ångra";
backwardButton_opt_excel = "Ångra";
backwardButton_opt_powerpoint = "Ångra";
backwardButton_opt_msTeams = "Mikrofonljud av/på";
backwardButton_opt_zoomUS = "Mikrofonljud av/på";
backwardButton_opt_fallback = "Tillbaka";

gesture_opt_topMac = "Mission Control";
gesture_opt_top = "Uppdragsvy";
gesture_opt_left = "Växla mellan skrivbord";
gesture_opt_right = "Växla mellan skrivbord";
gesture_opt_bottom = "Visa/dölj skrivbord";
gesture_opt_bottomMac = "App Exposé";

btn_continue = "FORTSÄTT";
skip = "HOPPA ÖVER";
btn_continueToSetup = "FORTSÄTT FÖR ATT INSTALLERA";

btn_back = "TILLBAKA";
btn_next = "NÄSTA";

link_website = "%logiwebsite%"
