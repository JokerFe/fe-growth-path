btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "DE DRAAIKNOP PAST ZICH AAN UW SELECTIE AAN"
desc0 = "Selecteer een object en raak de draaiknop aan om de bijbehorende opties te zien"

title1 = "LIJNGROOTTE WIJZIGEN"
desc1 = "Roteer de draaiknop om de lijngrootte van het geselecteerde object aan te passen"

title2 = "LIJNKLEUR WIJZIGEN"
desc2 = "Roteer de draaiknop om de kleur van de lijn te wijzigen"
