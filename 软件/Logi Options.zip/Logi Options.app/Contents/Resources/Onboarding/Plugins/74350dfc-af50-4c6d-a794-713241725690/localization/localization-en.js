btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "THE CROWN IS CONTEXTUAL TO YOUR SELECTION"
desc0 = "Select an a object and touch the Crown to see the associated options"

title1 = "CHANGE STROKE SIZE"
desc1 = "Turn the Crown to adjust the stroke size of the selected object"

title2 = "CHANGE STROKE COLOR"
desc2 = "Turn the Crown to change the color of the stroke"


