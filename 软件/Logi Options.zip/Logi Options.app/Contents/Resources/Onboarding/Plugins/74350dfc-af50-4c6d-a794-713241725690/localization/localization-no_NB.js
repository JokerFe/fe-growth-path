btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "KRONEN ER KONTEKSTAVHENGIG I FORHOLD TIL UTVALGET"
desc0 = "Velg et objekt og berør kronen for å vise tilknyttede alternativer"

title1 = "ENDRE STRØKSTØRRELSE"
desc1 = "Drei på kronen for å justere strøkstørrelsen på det valgte objektet"

title2 = "ENDRE STRØKFARGE"
desc2 = "Drei på kronen for å endre strøkfarge"
