btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "A COROA É CONTEXTUAL À SUA SELECÇÃO"
desc0 = "Seleccione um objecto e toque na Coroa para ver as opções associadas"

title1 = "ALTERAR O TAMANHO DO TRAÇO"
desc1 = "Rode a Coroa para ajustar o tamanho do traço do objecto seleccionado"

title2 = "ALTERAR A COR DO TRAÇO"
desc2 = "Rode a Coroa para alterar a cor do traço"
