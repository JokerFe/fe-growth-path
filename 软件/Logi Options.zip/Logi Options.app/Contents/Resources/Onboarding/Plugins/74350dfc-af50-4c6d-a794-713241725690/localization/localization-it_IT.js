btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "IL PULSANTE GIREVOLE È CONTESTUALE RISPETTO ALLA SELEZIONE"
desc0 = "Seleziona un oggetto e tocca il pulsante girevole per visualizzare le opzioni associate"

title1 = "MODIFICA DELLE DIMENSIONI DEL TRATTO"
desc1 = "Ruota il pulsante girevole per regolare le dimensioni del tratto dell'oggetto selezionato"

title2 = "MODIFICA DEL COLORE DEL TRATTO"
desc2 = "Ruota il pulsante girevole per modificare il colore del tratto"
