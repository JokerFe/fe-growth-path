btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "CROWN ER KONTEKSTAFHÆNGIG I FORHOLD TIL DET MARKEREDE"
desc0 = "Markér et objekt, og tryk på Crown for at se valgmulighederne"

title1 = "SKIFT STRØGTYKKELSE"
desc1 = "Drej Crown for at justere strøgtykkelsen for det valgte objekt"

title2 = "SKIFT STRØGFARVE"
desc2 = "Drej Crown for at ændre strøgfarven"
