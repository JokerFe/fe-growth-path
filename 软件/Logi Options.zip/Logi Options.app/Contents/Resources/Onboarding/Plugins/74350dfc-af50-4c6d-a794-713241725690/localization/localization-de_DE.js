btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "DAS DREHRAD IST ABHÄNGIG VOM KONTEXT IHRER AUSWAHL"
desc0 = "Wählen Sie ein Objekt aus und berühren Sie das Drehrad zum Anzeigen der damit verbundenen Optionen"

title1 = "ÄNDERN DER KONTURGRÖSSE"
desc1 = "Drehen Sie das Drehrad zum Anpassen der Konturgröße des ausgewählten Objekts"

title2 = "ÄNDERN DER KONTURFARBE"
desc2 = "Drehen Sie das Drehrad zum Ändern der Konturfarbe"
