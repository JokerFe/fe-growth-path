btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "O CROWN É CONTEXTUAL À SUA SELEÇÃO"
desc0 = "Selecione um objeto e toque no Crown para ver as opções associadas"

title1 = "TROQUE O TAMANHO DO CONTORNO"
desc1 = "Ative o Crown para ajustar tamanho do contorno do objeto selecionado"

title2 = "TROQUE A COR DO CONTORNO"
desc2 = "Gire o Crown para alterar a cor do contorno"
