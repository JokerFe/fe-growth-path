btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "LA CORONA ES CONTEXTUAL PARA LA SELECCIÓN"
desc0 = "Seleccione un objeto y toque la corona para ver las opciones asociadas"

title1 = "CAMBIAR TAMAÑO DE TRAZO"
desc1 = "Gire la corona para ajustar el tamaño de trazo del objeto seleccionado"

title2 = "CAMBIAR COLOR DE TRAZO"
desc2 = "Gire la corona para cambiar el color del trazo"
