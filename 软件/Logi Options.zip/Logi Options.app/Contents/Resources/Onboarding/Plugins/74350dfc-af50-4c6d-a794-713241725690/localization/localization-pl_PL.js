btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "KORONA ZAPEWNIA KONTEKSTOWE FUNKCJE NA POTRZEBY ZAZNACZENIA"
desc0 = "Zaznacz obiekt i dotknij korony, aby wyświetlić powiązane opcje"

title1 = "ZMIANA ROZMIARU OBRYSU"
desc1 = "Obróć koronę, aby zmienić rozmiar obrysu zaznaczonego obiektu"

title2 = "ZMIANA KOLORU OBRYSU"
desc2 = "Obróć koronę, aby zmienić kolor obrysu"
