btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "LA MOLETTE EST CONTEXTUELLE EN FONCTION DE VOTRE SÉLECTION"
desc0 = "Sélectionnez un objet et touchez la molette pour voir les options associées."

title1 = "MODIFIEZ l'ÉPAISSEUR DU CONTOUR"
desc1 = "Tournez la molette pour ajuster l'épaisseur du contour de l'objet sélectionné."

title2 = "MODIFIEZ LA COULEUR DU CONTOUR"
desc2 = "Tournez la molette pour modifier la couleur du contour."
