btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "KRONAN ÄR KONTEXTKÄNSLIG FÖR DITT VAL"
desc0 = "Välj ett objekt och tryck på kronan för att se de associerade alternativen"

title1 = "ÄNDRA STRECKGROVLEK"
desc1 = "Vrid kronan för att justera streckgrovleken för det valda objektet"

title2 = "ÄNDRA STRECKFÄRG"
desc2 = "Vrid kronan för att ändra streckfärg"
