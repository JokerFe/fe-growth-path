btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "KRUUNU ON SISÄLTÖKOHTAINEN VALINTASI MUKAAN"
desc0 = "Valitse kohde ja kosketa kruunua, niin näet siihen liittyvät toiminnot"

title1 = "MUUTA VIIVAN KOKOA"
desc1 = "Käännä kruunua säätääksesi valitun kohteen viivan kokoa"

title2 = "MUUTA VIIVAN VÄRIÄ"
desc2 = "Käännä kruunua vaihtaaksesi viivan väriä"
