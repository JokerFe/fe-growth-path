btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "MODIFIEZ LA TAILLE DE LA POLICE"
desc0 = "Sélectionnez du texte et tournez la molette pour ajuster la taille de la police."

title1 = "MODIFIEZ L'INTERLIGNE DE LA POLICE"
desc1 = "Sélectionnez du texte et tournez la molette pour ajuster l'interligne de la police."

title2 = "MODIFIEZ LA TAILLE DE L'IMAGE"
desc2 = "Sélectionnez une image dans votre document et tournez la molette pour ajuster sa taille."

title3 = "MODIFIEZ L'OPACITÉ DE L'IMAGE"
desc3 = "Appuyez sur la molette et sélectionnez l'option d'opacité pour modifier sa valeur."

