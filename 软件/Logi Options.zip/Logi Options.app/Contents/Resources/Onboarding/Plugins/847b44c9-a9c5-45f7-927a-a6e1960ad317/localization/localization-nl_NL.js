btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "LETTERGROOTTE WIJZIGEN"
desc0 = "Selecteer wat tekst en roteer de draaiknop om de lettergrootte aan te passen"

title1 = "REGELAFSTAND LETTERTYPE WIJZIGEN"
desc1 = "Selecteer wat tekst en roteer de draaiknop om de regelafstand van het lettertype aan te passen"

title2 = "AFBEELDINGSGROOTTE WIJZIGEN"
desc2 = "Selecteer een afbeelding in uw document en roteer de draaiknop om de grootte aan te passen"

title3 = "DEKKING AFBEELDING WIJZIGEN"
desc3 = "Tik op de draaiknop en selecteer de dekkingsoptie om de waarde ervan te wijzigen"

