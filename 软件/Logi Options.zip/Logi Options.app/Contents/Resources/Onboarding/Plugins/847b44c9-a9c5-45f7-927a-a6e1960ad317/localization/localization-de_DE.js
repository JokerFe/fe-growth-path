btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "ÄNDERN DER SCHRIFTGRÖSSE"
desc0 = "Markieren Sie Text und drehen Sie das Drehrad zum Anpassen der Schriftgröße"

title1 = "ÄNDERN DES SCHRIFTZEILENABSTANDS"
desc1 = "Markieren Sie Text und drehen Sie das Drehrad zum Anpassen des Schriftzeilenabstands"

title2 = "ÄNDERN DER BILDGRÖSSE"
desc2 = "Markieren Sie ein Bild in Ihrem Dokument und drehen Sie das Drehrad zum Anpassen der Größe"

title3 = "ÄNDERN DER BILDDECKKRAFT"
desc3 = "Tippen Sie auf das Drehrad und wählen Sie die Option „Deckkraft“ zum Ändern des entsprechenden Wertes aus"

