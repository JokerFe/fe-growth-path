btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "SKIFT SKRIFTSTØRRELSE"
desc0 = "Markér noget tekst, og drej Crown for at justere skriftstørrelsen"

title1 = "SKIFT SKYDNING FOR SKRIFTTYPE"
desc1 = "Markér noget tekst, og drej Crown for at justere skydningen for skrifttypen"

title2 = "SKIFT BILLEDSTØRRELSE"
desc2 = "Markér et billede i et dokument, og drej Crown for at justere størrelsen"

title3 = "JUSTER BILLEDOPACITET"
desc3 = "Tryk på Crown, og vælg en opacitetsmulighed for at ændre værdien"

