btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "ZMIANA ROZMIARU CZCIONKI"
desc0 = "Zaznacz tekst i obróć koronę, aby zmienić rozmiar czcionki"

title1 = "ZMIANA INTERLINII CZCIONKI"
desc1 = "Zaznacz tekst i obróć koronę, aby zmienić interlinię czcionki"

title2 = "ZMIANA ROZMIARU OBRAZU"
desc2 = "Zaznacz obraz w dokumencie i obróć koronę, aby zmienić jego rozmiar"

title3 = "ZMIANA KRYCIA OBRAZU"
desc3 = "Naciśnij koronę i wybierz opcję krycia, aby zmienić tę wartość"

