btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "MODIFICA DELLE DIMENSIONI DEL CARATTERE"
desc0 = "Seleziona parte del testo e ruota il pulsante girevole per regolare le dimensioni del carattere"

title1 = "MODIFICA DELL'INTERLINEA DEL CARATTERE"
desc1 = "Seleziona parte del testo e ruota il pulsante girevole per regolare l'interlinea del carattere"

title2 = "MODIFICA DELLE DIMENSIONI DELL'IMMAGINE"
desc2 = "Seleziona un'immagine nel documento e ruota il pulsante girevole per regolarne le dimensioni"

title3 = "MODIFICA DELL'OPACITÀ DELL'IMMAGINE"
desc3 = "Tocca il pulsante girevole e seleziona l'opzione di opacità per modificare questo valore"

