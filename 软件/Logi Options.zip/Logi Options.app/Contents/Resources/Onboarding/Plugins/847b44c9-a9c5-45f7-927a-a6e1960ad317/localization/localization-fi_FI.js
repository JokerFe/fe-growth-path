btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "MUUTA FONTTIKOKOA"
desc0 = "Valitse tekstiä ja säädä fonttikokoa kääntämällä kruunua"

title1 = "MUUTA FONTIN RIVIVÄLIÄ"
desc1 = "Valitse tekstiä ja säädä fontin riviväliä kääntämällä kruunua"

title2 = "MUUTA KUVAN KOKOA"
desc2 = "Valitse kuva dokumentissasi ja säädä sen kokoa kääntämällä kruunua"

title3 = "MUUTA KUVAN PEITTÄVYYTTÄ"
desc3 = "Napauta kruunua ja valitse peittävyys muuttaaksesi tätä arvoa"

