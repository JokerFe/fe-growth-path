btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "TROQUE O TAMANHO DA FONTE"
desc0 = "Selecione algum texto e ative o Crown para ajustar o tamanho da fonte"

title1 = "TROQUE O ESPAÇO DA FONTE"
desc1 = "Selecione algum texto e ative o Crown para ajustar o espaço da fonte"

title2 = "TROQUE O TAMANHO DA IMAGEM"
desc2 = "Selecione uma imagem no seu documento e ative o Crown para ajustar o tamanho"

title3 = "TROQUE A OPACIDADE DA IMAGEM"
desc3 = "Toque no Crown e selecione a opção opacidade para alterar este valor"

