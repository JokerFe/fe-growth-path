btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "ÄNDRA TECKENSTORLEK"
desc0 = "Välj lite text och vrid på kronan för att ändra teckensnittets storlek"

title1 = "ÄNDRA RADAVSTÅND"
desc1 = "Välj lite text och vrid på kronan för att ändra teckensnittets radavstånd"

title2 = "ÄNDRA BILDSTORLEK"
desc2 = "Välj en bild i ditt dokument och vrid på kronan för att ändra bildens storlek"

title3 = "ÄNDRA BILDOPACITET"
desc3 = "Tryck på kronan och välj alternativet för opacitet för att ändra det värdet"

