btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "CHANGE FONT SIZE"
desc0 = "Select some text and turn the Crown to adjust the font size"

title1 = "CHANGE FONT LEADING"
desc1 = "Select some text and turn the Crown to adjust the font leading"

title2 = "CHANGE IMAGE SIZE"
desc2 = "Select an image on your document and turn the Crown to adjust its size"

title3 = "CHANGE IMAGE OPACITY"
desc3 = "Tap the Crown and select the opacity option to change this value"

