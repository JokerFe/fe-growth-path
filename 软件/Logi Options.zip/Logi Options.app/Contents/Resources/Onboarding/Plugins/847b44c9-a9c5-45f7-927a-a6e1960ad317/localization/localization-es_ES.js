btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "CAMBIAR TAMAÑO DE FUENTE"
desc0 = "Seleccione texto y gire la corona para modificar el tamaño de fuente"

title1 = "CAMBIAR INTERLINEADO"
desc1 = "Seleccione texto y gire la corona para modificar el interlineado"

title2 = "CAMBIAR TAMAÑO DE IMAGEN"
desc2 = "Seleccione una imagen en un documento y gire la corona para modificar el tamaño de la imagen"

title3 = "CAMBIAR OPACIDAD DE IMAGEN"
desc3 = "Pulse la corona y seleccione la opción de opacidad para modificar este valor"

