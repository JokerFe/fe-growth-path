btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "ALTERAR O TAMANHO DO TIPO DE LETRA"
desc0 = "Seleccione o texto e rode a Coroa para ajustar o tamanho do tipo de letra"

title1 = "ALTERAR ESPAÇO ENTRE LINHAS"
desc1 = "Seleccione o texto e rode a Coroa para ajustar o espaço entre linhas"

title2 = "ALTERAR O TAMANHO DA IMAGEM"
desc2 = "Seleccione uma imagem no seu documento e rode a Coroa para ajustar o tamanho"

title3 = "ALTERAR A OPACIDADE DA IMAGEM"
desc3 = "Toque na Coroa e seleccione a opção de opacidade para alterar o valor"

