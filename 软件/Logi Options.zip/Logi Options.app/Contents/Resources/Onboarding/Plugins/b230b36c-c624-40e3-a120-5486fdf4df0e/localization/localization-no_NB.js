btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "KRONEN ER KONTEKSTAVHENGIG I FORHOLD TIL VALGT VERKTØY"
desc0 = "Velg et verktøy og berør kronen for å vise tilknyttede alternativer"

title1 = "DREI PÅ KRONEN FOR Å ENDRE ALTERNATIVETS VERDI"
desc1 = "Drei på kronen for å justere verdien for det første valgte objektet"

title2 = "TAPP PÅ KRONEN FOR Å AKTIVERE NESTE ALTERNATIV"
desc2 = "Hvis overlegget viser flere alternativer, tapper du på kronen for å velge neste alternativ "
