btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "KRONAN ÄR KONTEXTKÄNSLIG FÖR DET VERKTYG DU ANVÄNDER"
desc0 = "Välj ett verktyg och tryck på kronan för att se de associerade alternativen"

title1 = "VRID KRONAN FÖR ATT VÄLJA ALTERNATIV"
desc1 = "Vrid kronan för att justera det först valda alternativets värde"

title2 = "TRYCK PÅ KRONAN FÖR ATT AKTIVERA NÄSTA ALTERNATIV"
desc2 = "När överlägget visar flera alternativ pekar du på kronan och väljer nästa "
