btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "A COROA É CONTEXTUAL À FERRAMENTA QUE SELECCIONAR"
desc0 = "Seleccione uma ferramenta e toque na Coroa para ver as opções associadas"

title1 = "RODE A COROA PARA ALTERAR O VALOR DA OPÇÃO"
desc1 = "Rode a Coroa para ajustar o valor da primeira opção seleccionada"

title2 = "TOQUE NA COROA PARA ACTIVAR A OPÇÃO SEGUINTE"
desc2 = "Quando a sobreposição apresentar várias opções, toque na Coroa para seleccionar a seguinte "
