btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "KRUUNU ON SISÄLTÖKOHTAINEN VALITSEMASI TYÖKALUN MUKAAN"
desc0 = "Valitse työkalu ja kosketa kruunua, niin näet siihen liittyvät toiminnot"

title1 = "KÄÄNNÄ KRUUNUA VAIHTAAKSESI VALINNAN ARVOA"
desc1 = "Käännä kruunua säätääksesi ensiksi valitun vaihtoehdon arvoa"

title2 = "NAPAUTA KRUUNUA AKTIVOIDAKSESI SEURAAVA VAIHTOEHTO"
desc2 = "Kun asettelussa on useita vaihtoehtoja, napauta kruunua valitaksesi seuraava "
