btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "CROWN ER KONTEKSTAFHÆNGIG I FORHOLD TIL DET VALGTE VÆRKTØJ"
desc0 = "Vælg et værktøj, og tryk på Crown for at se valgmulighederne"

title1 = "DREJ CROWN FOR AT ÆNDRE INDSTILLINGENS VÆRDI"
desc1 = "Drej Crown for at ændre værdien for den først valgte mulighed"

title2 = "TRYK PÅ CROWN FOR AT AKTIVERE DEN NÆSTE MULIGHED"
desc2 = "Tryk på Crown for at vælge den næste mulighed hvis der vises flere på bjælken "
