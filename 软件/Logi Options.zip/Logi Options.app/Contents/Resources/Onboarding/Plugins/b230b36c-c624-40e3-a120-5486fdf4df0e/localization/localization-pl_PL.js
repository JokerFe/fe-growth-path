btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "KORONA ZAPEWNIA KONTEKSTOWE FUNKCJE NA POTRZEBY WYBRANEGO NARZĘDZIA"
desc0 = "Wybierz narzędzie i dotknij korony, aby wyświetlić powiązane opcje"

title1 = "OBRACANIE KORONY W CELU ZMIANY WARTOŚCI OPCJI"
desc1 = "Obróć koronę, aby zmienić wartość pierwszej wybranej opcji"

title2 = "NACISKANIE KORONY W CELU AKTYWACJI NASTĘPNEJ OPCJI"
desc2 = "Kiedy nakładka wyświetla wiele opcji, naciśnij koronę, aby wybrać następną opcję "
