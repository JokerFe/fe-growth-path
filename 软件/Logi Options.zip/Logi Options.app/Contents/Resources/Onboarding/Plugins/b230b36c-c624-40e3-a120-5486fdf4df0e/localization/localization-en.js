btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "THE CROWN IS CONTEXTUAL TO THE TOOL YOU SELECT"
desc0 = "Select a tool and touch the Crown to see the associated options"

title1 = "TURN THE CROWN TO CHANGE THE OPTION VALUE"
desc1 = "Turn the Crown to adjust the value of the first selected option"

title2 = "TAP THE CROWN TO ACTIVATE NEXT OPTION"
desc2 = "When the overlay shows multiple options, tap the Crown to select the next one "


