btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "DE DRAAIKNOP PAST ZICH AAN DE TOOL DIE U SELECTEERT AAN"
desc0 = "Selecteer een tool en raak de draaiknop aan om de bijbehorende opties te zien"

title1 = "DRAAIKNOP ROTEREN OM OPTIEWAARDE TE WIJZIGEN"
desc1 = "Roteer de draaiknop om de waarde van de eerste geselecteerde optie aan te passen"

title2 = "OP DRAAIKNOP TIKKEN OM VOLGENDE OPTIE TE ACTIVEREN"
desc2 = "Wanneer de overlay meerdere opties weergeeft, tikt u op de draaiknop om de volgende optie te selecteren "
