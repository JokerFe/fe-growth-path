btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "LA CORONA ES CONTEXTUAL PARA LA HERRAMIENTA SELECCIONADA"
desc0 = "Seleccione una herramienta y toque la corona para ver las opciones asociadas"

title1 = "GIRE LA CORONA PARA CAMBIAR EL VALOR DE LA OPCIÓN"
desc1 = "Gire la corona para ajustar el valor de la primera opción seleccionada"

title2 = "PULSE LA CORONA PARA ACTIVAR LA SIGUIENTE OPCIÓN"
desc2 = "Cuando la superposición muestre varias opciones, pulse la corona para selecciona la siguiente opción "
