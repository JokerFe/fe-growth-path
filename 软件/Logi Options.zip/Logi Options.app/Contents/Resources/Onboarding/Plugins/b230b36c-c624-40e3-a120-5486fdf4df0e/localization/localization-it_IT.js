btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "IL PULSANTE GIREVOLE È CONTESTUALE RISPETTO ALLO STRUMENTO SELEZIONATO"
desc0 = "Seleziona uno strumento e tocca il pulsante girevole per visualizzare le opzioni associate"

title1 = "RUOTARE DEL PULSANTE GIREVOLE PER MODIFICARE IL VALORE DELL'OPZIONE"
desc1 = "Ruota il pulsante girevole per regolare il valore della prima opzione selezionata"

title2 = "TOCCARE IL PULSANTE GIREVOLE PER ATTIVARE L'OPZIONE SUCCESSIVA"
desc2 = "Quando la sovraimpressione mostra più opzioni, tocca il pulsante girevole per selezionare quella successiva "
