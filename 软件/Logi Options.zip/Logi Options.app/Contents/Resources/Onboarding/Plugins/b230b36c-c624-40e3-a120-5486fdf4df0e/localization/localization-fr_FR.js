btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "LA MOLETTE EST CONTEXTUELLE EN FONCTION DE L'OUTIL QUE VOUS SÉLECTIONNEZ"
desc0 = "Sélectionnez un outil et touchez la molette pour voir les options associées."

title1 = "TOURNEZ LA MOLETTE POUR MODIFIER LA VALEUR DE L'OPTION."
desc1 = "Tournez la molette pour ajuster la valeur de la première option sélectionnée."

title2 = "APPUYEZ SUR LA MOLETTE POUR ACTIVER L'OPTION SUIVANTE"
desc2 = "Lorsque la superposition affiche plusieurs options, appuyez sur la molette pour sélectionner l'option suivante. "
