btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "DAS DREHRAD IST KONTEXTSPEZIFISCH FÜR DAS AUSGEWÄHLTE TOOL"
desc0 = "Wählen Sie ein Tool aus und berühren Sie das Drehrad zum Anzeigen der damit verbundenen Optionen"

title1 = "DREHEN DES DREHRADS ZUM ÄNDERN VON OPTIONSEINSTELLUNGEN"
desc1 = "Drehen Sie das Drehrad zum Anpassen des Wertes für die zuerst ausgewählte Option"

title2 = "TIPPEN AUF DAS DREHRAD ZUM AKTIVIEREN DER NÄCHSTEN OPTION"
desc2 = "Wenn mehrere Optionen eingeblendet werden, tippen Sie auf das Drehrad zum Auswählen der nächsten Option "
