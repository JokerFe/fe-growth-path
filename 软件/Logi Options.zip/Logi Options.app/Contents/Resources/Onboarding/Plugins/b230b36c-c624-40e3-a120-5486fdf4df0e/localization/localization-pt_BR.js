btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "O CROWN É CONTEXTUAL À FERRAMENTA SELECIONADA"
desc0 = "Selecione uma ferramenta e toque no Crown para ver as opções associadas"

title1 = "GIRE O CROWN PARA ALTERAR O VALOR DA OPÇÃO"
desc1 = "Gire o Crown para ajustar o valor da primeira opção selecionada"

title2 = "TOQUE NO CROWN PARA ATIVAR A PRÓXIMA OPÇÃO"
desc2 = "Quando a sobreposição mostra várias opções, toque no Crown para selecionar a próxima "
