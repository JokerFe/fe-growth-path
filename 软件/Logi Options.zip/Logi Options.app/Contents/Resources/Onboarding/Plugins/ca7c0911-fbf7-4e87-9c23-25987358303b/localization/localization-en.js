btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "CHANGE THEME STYLE"
desc0 = "Turn the Crown to browse the different theme styles"

title1 = "CHANGE FONT SIZE"
desc1 = "Select some text and turn the Crown to adjust the font size"

title2 = "CHANGE IMAGE SIZE"
desc2 = "Select an image on your document and turn the Crown to adjust its size"
