btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "SKIFT TEMASTIL"
desc0 = "Drej Crown for at gennemse de forskellige temastile"

title1 = "SKIFT SKRIFTSTØRRELSE"
desc1 = "Markér noget tekst, og drej Crown for at justere skriftstørrelsen"

title2 = "SKIFT BILLEDSTØRRELSE"
desc2 = "Markér et billede i et dokument, og drej Crown for at justere størrelsen"
