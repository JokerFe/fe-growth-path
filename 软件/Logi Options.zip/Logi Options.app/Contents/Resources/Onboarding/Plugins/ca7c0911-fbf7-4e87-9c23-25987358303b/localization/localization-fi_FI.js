btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "MUUTA TEEMAN TYYLIÄ"
desc0 = "Käännä kruunua selataksesi erilaisia teeman tyylejä"

title1 = "MUUTA FONTTIKOKOA"
desc1 = "Valitse tekstiä ja säädä fonttikokoa kääntämällä kruunua"

title2 = "MUUTA KUVAN KOKOA"
desc2 = "Valitse kuva dokumentissasi ja säädä sen kokoa kääntämällä kruunua"
