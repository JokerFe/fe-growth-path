btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "MODIFICA DELLO STILE DEL TEMA"
desc0 = "Ruota il pulsante girevole per esplorare i vari stili di tema"

title1 = "MODIFICA DELLE DIMENSIONI DEL CARATTERE"
desc1 = "Seleziona parte del testo e ruota il pulsante girevole per regolare le dimensioni del carattere"

title2 = "MODIFICA DELLE DIMENSIONI DELL'IMMAGINE"
desc2 = "Seleziona un'immagine nel documento e ruota il pulsante girevole per regolarne le dimensioni"
