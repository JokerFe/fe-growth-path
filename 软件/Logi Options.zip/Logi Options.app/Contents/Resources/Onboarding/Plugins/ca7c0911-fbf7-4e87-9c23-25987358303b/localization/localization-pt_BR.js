btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "TROQUE O ESTILO DO TEMA"
desc0 = "Gire o Crown para navegar pelos diferentes estilos de tema"

title1 = "TROQUE O TAMANHO DA FONTE"
desc1 = "Selecione algum texto e ative o Crown para ajustar o tamanho da fonte"

title2 = "TROQUE O TAMANHO DA IMAGEM"
desc2 = "Selecione uma imagem no seu documento e ative o Crown para ajustar o tamanho"
