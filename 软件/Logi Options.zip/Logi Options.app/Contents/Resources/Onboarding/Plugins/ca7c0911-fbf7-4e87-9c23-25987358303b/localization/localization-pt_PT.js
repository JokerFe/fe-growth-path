btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "ALTERAR O ESTILO DO TEMA"
desc0 = "Rode a Coroa para navegar os diferentes estilos do tema"

title1 = "ALTERAR O TAMANHO DO TIPO DE LETRA"
desc1 = "Seleccione o texto e rode a Coroa para ajustar o tamanho do tipo de letra"

title2 = "ALTERAR O TAMANHO DA IMAGEM"
desc2 = "Seleccione uma imagem no seu documento e rode a Coroa para ajustar o tamanho"
