btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "ENDRE TEMASTIL"
desc0 = "Drei på kronen for å bla gjennom de ulike temastilene"

title1 = "ENDRE SKRIFTSTØRRELSE"
desc1 = "Merk en vilkårlig tekst og drei på kronen for å justere skriftstørrelsen"

title2 = "ENDRE BILDESTØRRELSE"
desc2 = "Merk et bilde i dokumentet og drei på kronen for å justere størrelsen"
