btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "THEMASTIJL WIJZIGEN"
desc0 = "Roteer de draaiknop om door de verschillende themastijlen te bladeren"

title1 = "LETTERGROOTTE WIJZIGEN"
desc1 = "Selecteer wat tekst en roteer de draaiknop om de lettergrootte aan te passen"

title2 = "AFBEELDINGSGROOTTE WIJZIGEN"
desc2 = "Selecteer een afbeelding in uw document en roteer de draaiknop om de grootte aan te passen"
