btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "CAMBIAR ESTILO DE TEMA"
desc0 = "Gire la corona para ver distintos estilos de tema"

title1 = "CAMBIAR TAMAÑO DE FUENTE"
desc1 = "Seleccione texto y gire la corona para modificar el tamaño de fuente"

title2 = "CAMBIAR TAMAÑO DE IMAGEN"
desc2 = "Seleccione una imagen en un documento y gire la corona para modificar el tamaño de la imagen"
