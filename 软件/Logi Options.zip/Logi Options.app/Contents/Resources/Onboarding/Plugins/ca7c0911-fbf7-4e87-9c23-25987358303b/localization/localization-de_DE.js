btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "ÄNDERN DES SCHEMASTILS"
desc0 = "Drehen Sie das Drehrad zum Durchblättern durch die unterschiedlichen Schemastile"

title1 = "ÄNDERN DER SCHRIFTGRÖSSE"
desc1 = "Markieren Sie Text und drehen Sie das Drehrad zum Anpassen der Schriftgröße"

title2 = "ÄNDERN DER BILDGRÖSSE"
desc2 = "Markieren Sie ein Bild in Ihrem Dokument und drehen Sie das Drehrad zum Anpassen der Größe"
