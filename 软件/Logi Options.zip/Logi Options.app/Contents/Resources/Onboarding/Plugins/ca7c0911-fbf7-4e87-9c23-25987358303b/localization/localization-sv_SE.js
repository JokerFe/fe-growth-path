btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "ÄNDRA TEMAFORMAT"
desc0 = "Vrid kronan för att bläddra genom de olika temaformaten"

title1 = "ÄNDRA TECKENSTORLEK"
desc1 = "Välj lite text och vrid på kronan för att ändra teckensnittets storlek"

title2 = "ÄNDRA BILDSTORLEK"
desc2 = "Välj en bild i ditt dokument och vrid på kronan för att ändra bildens storlek"
