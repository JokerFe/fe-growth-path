btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "ZMIANA STYLU MOTYWU"
desc0 = "Obróć koronę, aby przeglądać różne style motywów"

title1 = "ZMIANA ROZMIARU CZCIONKI"
desc1 = "Zaznacz tekst i obróć koronę, aby zmienić rozmiar czcionki"

title2 = "ZMIANA ROZMIARU OBRAZU"
desc2 = "Zaznacz obraz w dokumencie i obróć koronę, aby zmienić jego rozmiar"
