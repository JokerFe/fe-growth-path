btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "MODIFIEZ LE STYLE DU THÈME"
desc0 = "Tournez la molette pour naviguer entre les différents styles de thèmes."

title1 = "MODIFIEZ LA TAILLE DE LA POLICE"
desc1 = "Sélectionnez du texte et tournez la molette pour ajuster la taille de la police."

title2 = "MODIFIEZ LA TAILLE DE L'IMAGE"
desc2 = "Sélectionnez une image dans votre document et tournez la molette pour ajuster sa taille."
