btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "TROQUE O ESTILO DO SLIDE"
desc0 = "Selecione seu slide e ative o Crown para alterar o estilo do slide"

title1 = "TROQUE O TAMANHO DA FONTE"
desc1 = "Selecione texto no seu slide e ative o Crown para ajustar o tamanho da fonte"

title2 = "TROQUE O TAMANHO DO OBJETO"
desc2 = "Selecione objeto no seu slide e ative o Crown para ajustar o tamanho"

