btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "CAMBIAR ESTILO DE DIAPOSITIVA"
desc0 = "Seleccione una diapositiva y gire la corona para cambiar su estilo"

title1 = "CAMBIAR TAMAÑO DE FUENTE"
desc1 = "Seleccione texto en una diapositiva y gire la corona para modificar el tamaño de fuente"

title2 = "CAMBIAR TAMAÑO DE OBJETO"
desc2 = "Seleccione un objeto en una diapositiva y gire la corona para modificar el tamaño del objeto"

