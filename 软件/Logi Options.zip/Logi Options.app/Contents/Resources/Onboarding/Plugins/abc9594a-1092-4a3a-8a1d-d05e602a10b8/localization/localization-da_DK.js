btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "SKIFT DIASSTIL"
desc0 = "Markér et dias, og drej Crown for ændre diasstilen"

title1 = "SKIFT SKRIFTSTØRRELSE"
desc1 = "Markér tekst på et dias, og drej Crown for at justere skriftstørrelsen"

title2 = "SKIFT OBJEKTSTØRRELSE"
desc2 = "Markér et objekt på et dias, og drej Crown for at justere størrelsen"

