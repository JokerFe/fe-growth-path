btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "MODIFICA STILE PRESENTAZIONE"
desc0 = "Seleziona la presentazione desiderata, quindi ruota il pulsante girevole per modificare lo stile della presentazione"

title1 = "MODIFICA DELLE DIMENSIONI DEL CARATTERE"
desc1 = "Seleziona il testo nella presentazione e ruota il pulsante girevole per regolare le dimensioni del carattere"

title2 = "MODIFICA DELLE DIMENSIONI DELL'OGGETTO"
desc2 = "Seleziona un oggetto nel documento e ruota il pulsante girevole per regolarne le dimensioni"

