btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "ALTERAR O ESTILO DO DIAPOSITIVO"
desc0 = "Seleccione o diapositivo e rode a Coroa para alterar o estilo do diapositivo"

title1 = "ALTERAR O TAMANHO DO TIPO DE LETRA"
desc1 = "Seleccione o texto no seu diapositivo e rode a Coroa para ajustar o tamanho do tipo de letra"

title2 = "ALTERAR O TAMANHO DO OBJECTO"
desc2 = "Seleccione um objecto no seu diapositivo e rode a Coroa para ajustar o tamanho"

