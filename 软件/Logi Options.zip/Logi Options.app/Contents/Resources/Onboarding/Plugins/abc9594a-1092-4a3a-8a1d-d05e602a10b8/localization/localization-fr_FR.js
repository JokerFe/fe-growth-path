btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "MODIFIEZ LE STYLE DE DIAPOSITIVE"
desc0 = "Sélectionnez votre diapositive et tournez la molette pour modifier votre style de diapositive."

title1 = "MODIFIEZ LA TAILLE DE LA POLICE"
desc1 = "Sélectionnez le texte de votre diapositive et tournez la molette pour ajuster la taille de la police."

title2 = "MODIFIEZ LA TAILLE DE L'OBJET"
desc2 = "Sélectionnez un objet dans votre document et tournez la molette pour ajuster sa taille."

