btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "ENDRE LYSBILDESTIL"
desc0 = "Velg et lysbilde og drei på kronen for å endre lysbildestilen"

title1 = "ENDRE SKRIFTSTØRRELSE"
desc1 = "Merk ønsket tekst på lysbildet og drei på kronen for å justere skriftstørrelsen"

title2 = "ENDRE OBJEKTSTØRRELSE"
desc2 = "Merk et objekt på lysbildet og drei på kronen for å justere størrelsen"

