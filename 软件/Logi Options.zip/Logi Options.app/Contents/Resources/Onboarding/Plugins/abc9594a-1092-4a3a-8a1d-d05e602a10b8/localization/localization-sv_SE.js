btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "ÄNDRA FORMAT FÖR PRESENTATIONSBILD"
desc0 = "Välj presentationsbild och vrid kronan för att ändra format för presentationsbilden"

title1 = "ÄNDRA TECKENSTORLEK"
desc1 = "Välj text på din presentationsbild och vrid på kronan för att ändra teckensnittets storlek"

title2 = "ÄNDRA OBJEKTSTORLEK"
desc2 = "Välj ett objekt i ditt dokument och vrid på kronan för att ändra dess storlek"

