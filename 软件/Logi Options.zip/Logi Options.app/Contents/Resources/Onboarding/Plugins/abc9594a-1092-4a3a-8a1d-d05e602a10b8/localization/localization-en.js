btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "CHANGE SLIDE STYLE"
desc0 = "Select your slide then turn the Crown to change your slide style"

title1 = "CHANGE FONT SIZE"
desc1 = "Select text on your slide and turn the Crown to adjust the font size"

title2 = "CHANGE OBJECT SIZE"
desc2 = "Select an object on your slide and turn the Crown to adjust its size"

