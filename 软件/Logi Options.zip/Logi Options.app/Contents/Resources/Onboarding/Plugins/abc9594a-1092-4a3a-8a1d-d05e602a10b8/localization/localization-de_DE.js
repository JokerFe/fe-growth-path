btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "ÄNDERN DES FOLIENSTILS"
desc0 = "Wählen Sie eine Folie aus und drehen Sie dann das Drehrad zum Ändern des Folienstils"

title1 = "ÄNDERN DER SCHRIFTGRÖSSE"
desc1 = "Markieren Sie Text auf Ihrer Folie und drehen Sie das Drehrad zum Anpassen der Schriftgröße"

title2 = "ÄNDERN DER OBJEKTGRÖSSE"
desc2 = "Markieren Sie ein Objekt auf Ihrer Folie und drehen Sie das Drehrad zum Anpassen der Größe"

