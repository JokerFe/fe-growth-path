btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "MUUTA DIAN TYYLIÄ"
desc0 = "Valitse dia ja vaihda sen tyyliä kääntämällä kruunua"

title1 = "MUUTA FONTTIKOKOA"
desc1 = "Valitse tekstiä diassasi ja säädä fonttikokoa kääntämällä kruunua"

title2 = "MUUTA OBJEKTIN KOKOA"
desc2 = "Valitse objekti diassasi ja muuta sen kokoa kääntämällä kruunua"

