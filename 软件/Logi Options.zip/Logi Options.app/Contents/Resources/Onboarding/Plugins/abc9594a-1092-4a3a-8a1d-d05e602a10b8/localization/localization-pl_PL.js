btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "ZMIANA STYLU SLAJDU"
desc0 = "Zaznacz slajd i obróć koronę, aby zmienić jego styl"

title1 = "ZMIANA ROZMIARU CZCIONKI"
desc1 = "Zaznacz tekst na slajdzie i obróć koronę, aby zmienić rozmiar czcionki"

title2 = "ZMIANA ROZMIARU OBIEKTU"
desc2 = "Zaznacz obiekt na slajdzie i obróć koronę, aby zmienić jego rozmiar"

