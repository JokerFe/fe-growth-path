btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "DIASTIJL WIJZIGEN"
desc0 = "Selecteer uw dia en roteer de draaiknop om de stijl te wijzigen"

title1 = "LETTERGROOTTE WIJZIGEN"
desc1 = "Selecteer tekst in uw dia en roteer de draaiknop om de lettergrootte aan te passen"

title2 = "OBJECTGROOTTE WIJZIGEN"
desc2 = "Selecteer een object in uw dia en roteer de draaiknop om de grootte aan te passen"

