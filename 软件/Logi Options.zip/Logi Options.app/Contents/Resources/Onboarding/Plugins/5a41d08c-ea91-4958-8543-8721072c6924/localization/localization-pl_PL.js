btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "NAWIGACJA PO OSI CZASU"
desc0 = "Obróć koronę, aby nawigować po osi czasu "

title1 = "NAWIGACJA PRZY UŻYCIU POKRĘTŁA OBROTOWEGO"
desc1 = "Im bardziej obrócisz koronę, tym szybsza będzie nawigacja po osi czasu"

