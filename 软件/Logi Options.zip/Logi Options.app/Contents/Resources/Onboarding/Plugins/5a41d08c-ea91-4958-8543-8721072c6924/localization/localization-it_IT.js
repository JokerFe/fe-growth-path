btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "ESPLORAZIONE DELLA CRONOLOGIA"
desc0 = "Ruota il pulsante girevole per esplorare la cronologia "

title1 = "ESPLORAZIONE CON LA JOG WHEEL"
desc1 = "Più viene ruotato il pulsante girevole, maggiore sarà la velocità di esplorazione della cronologia"

