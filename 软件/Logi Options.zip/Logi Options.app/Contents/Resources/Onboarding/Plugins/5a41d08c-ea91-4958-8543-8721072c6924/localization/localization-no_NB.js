btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "NAVIGER PÅ TIDSLINJEN"
desc0 = "Drei på kronen for å navigere på tidslinjen "

title1 = "NAVIGER MED SKYTTELHJULET"
desc1 = "Jo mer du dreier på kronen, jo raskere navigerer du på tidslinjen"

