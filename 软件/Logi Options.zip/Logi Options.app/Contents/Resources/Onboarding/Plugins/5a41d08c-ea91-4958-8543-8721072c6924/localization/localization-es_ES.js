btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "NAVEGAR EN LA LÍNEA DE TIEMPO"
desc0 = "Gire la corona para recorrer la línea de tiempo "

title1 = "NAVEGAR CON EL DISCO DE EMPUJE"
desc1 = "Cuanto más gire la corona, más rápido navegará por la línea de tiempo"

