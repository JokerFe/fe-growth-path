btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "NAVEGAR NA LINHA DE TEMPO"
desc0 = "Rode a Coroa para navegar na linha de tempo "

title1 = "NAVEGAR COM A RODA DE NAVEGAÇÃO"
desc1 = "Quanto mais rodar a Coroa, mais rápido será a navegação da linha de tempo"

