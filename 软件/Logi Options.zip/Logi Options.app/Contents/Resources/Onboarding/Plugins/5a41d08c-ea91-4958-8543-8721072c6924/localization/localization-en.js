btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "NAVIGATE TIMELINE"
desc0 = "Turn the Crown to navigate the timeline "

title1 = "NAVIGATE WITH THE JOG WHEEL"
desc1 = "The more you turn the Crown, the faster you'll navigate the timeline"

