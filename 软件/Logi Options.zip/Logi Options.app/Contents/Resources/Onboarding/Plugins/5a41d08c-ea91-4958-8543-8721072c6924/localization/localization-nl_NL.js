btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "OVER TIJDLIJN NAVIGEREN"
desc0 = "Roteer de draaiknop om over de tijdlijn te navigeren "

title1 = "NAVIGEREN MET DRAAIWIEL"
desc1 = "Hoe sneller u de draaiknop roteert, hoe sneller u over de tijdlijn navigeert"

