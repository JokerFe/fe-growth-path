btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "NAVEGAR PELA LINHA DO TEMPO"
desc0 = "Ative o Crown para navegar pela linha do tempo "

title1 = "NAVEGUE COM A JOG WHEEL"
desc1 = "Quanto mais você gira o Crown, mais rápido você poderá navegar na linha do tempo"

