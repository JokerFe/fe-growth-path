btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "NAVIGATE I TIDSLINJEN"
desc0 = "Vrid kronan för att navigera i tidslinjen "

title1 = "NAVIGERA MED RULLHJULET"
desc1 = "Ju mer du vrider kronan, desto snabbare navigerar du på tidslinjen"

