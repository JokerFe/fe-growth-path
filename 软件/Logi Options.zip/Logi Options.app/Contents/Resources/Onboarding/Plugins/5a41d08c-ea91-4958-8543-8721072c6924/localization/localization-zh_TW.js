btn_back = "上一頁"
btn_next = "下一頁"
btn_done = "完成"

title0 = "瀏覽時間軸"
desc0 = "轉動多功能轉鈕可瀏覽時間軸 "

title1 = "使用滾輪瀏覽"
desc1 = "轉動多功能轉鈕越多，瀏覽時間軸的速度就會越快"

