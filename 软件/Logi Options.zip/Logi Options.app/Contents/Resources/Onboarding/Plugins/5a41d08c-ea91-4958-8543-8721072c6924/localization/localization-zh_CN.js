btn_back = "后退"
btn_next = "前进"
btn_done = "完成"

title0 = "在时间线中导航"
desc0 = "旋转多功能旋钮来在时间线中导航 "

title1 = "通过缓动轮导航"
desc1 = "多功能旋钮的转幅越大，在时间线上的导航速度越快"

