btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "LIIKU AIKAJANALLA"
desc0 = "Käännä kruunua liikkuaksesi aikajanalla "

title1 = "LIIKKUMINEN VALINTARULLAN AVULLA"
desc1 = "Mitä enemmän käännät kruunua, sitä nopeammin liikut aikajanalla"

