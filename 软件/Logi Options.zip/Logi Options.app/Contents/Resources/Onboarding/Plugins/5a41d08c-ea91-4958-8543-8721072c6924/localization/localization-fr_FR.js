btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "NAVIGUEZ DANS LA TIMELINE"
desc0 = "Tournez la molette pour naviguer dans la timeline. "

title1 = "NAVIGUEZ AVEC LA ROUE DE NAVIGATION"
desc1 = "Plus vous tournez la molette, plus vous naviguerez rapidement dans la timeline."

