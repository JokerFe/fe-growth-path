btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "NAVIGER PÅ TIDSLINJEN"
desc0 = "Drej Crown for at navigere på tidslinjen "

title1 = "NAVIGER MED SCROLLEHJULET"
desc1 = "Jo mere du drejer Crown, jo hurtigere navigerer du på tidslinjen"

