btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "NAVIGIEREN DURCH DIE ZEITACHSE"
desc0 = "Drehen Sie das Drehrad zur Navigation durch die Zeitachse "

title1 = "NAVIGIEREN MIT DEM JOG-RAD"
desc1 = "Je mehr Sie am Drehrad drehen, umso schneller navigieren Sie durch die Zeitachse"

