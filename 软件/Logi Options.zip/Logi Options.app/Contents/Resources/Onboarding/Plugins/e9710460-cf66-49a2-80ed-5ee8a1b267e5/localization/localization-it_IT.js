btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "UTILIZZA IL PULSANTE GIREVOLE PER MODIFICARE LA FOTO"
desc0 = "Tocca il pulsante girevole per selezionare uno strumento<br>e ruota il pulsante girevole per modificarne il valore"

title1 = "SELEZIONA LO STRUMENTO DA REGOLARE"
desc1 = "Tieni premuto il tasto Maiusc e tocca il pulsante girevole per accedere allo strumento precedente"

title2 = "PERSONALIZZA LE FUNZIONI DEL PULSANTE GIREVOLE"
desc2 = "Scegli gli strumenti preferiti in Options<br>per creare il flusso di lavoro ottimale"
