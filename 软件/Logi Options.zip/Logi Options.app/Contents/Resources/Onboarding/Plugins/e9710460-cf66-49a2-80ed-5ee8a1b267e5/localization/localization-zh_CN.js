btn_back = "后退"
btn_next = "下一步"
btn_done = "完成"

title0 = "使用多功能旋钮编辑照片"
desc0 = "轻击多功能旋钮选择一款工具<br>并旋转多功能调整设定值"

title1 = "选择您要进行调节的工具"
desc1 = "按住 shift 键并轻击多功能旋钮，可返回上一个工具"

title2 = "自定义多功能旋钮功能"
desc2 = "在 Options 中选择您喜爱的工具<br>来制定您的专属工作流程"
