btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "USE LA CORONA PARA EDITAR LA FOTO"
desc0 = "Toque la corona para seleccionar una herramienta<br>y gire la corona para cambiar su valor"

title1 = "SELECCIONE LA HERRAMIENTA QUE QUIERE AJUSTAR"
desc1 = "Mantenga presionada la tecla Mayús y toque la corona para ir a la herramienta anterior"

title2 = "PERSONALICE LAS FUNCIONES DE LA CORONA"
desc2 = "Elija sus herramientas favoritas en Options<br>para crear su flujo de trabajo óptimo"
