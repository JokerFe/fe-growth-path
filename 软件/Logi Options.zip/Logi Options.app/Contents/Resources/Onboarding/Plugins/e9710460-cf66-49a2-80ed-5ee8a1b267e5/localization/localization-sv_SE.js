btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "ANVÄND KRONAN FÖR ATT REDIGERA FOTON"
desc0 = "Tryck på kronan för att välja ett verktyg<br>och vrid kronan för att ändra dess värde"

title1 = "VÄLJ DET VERKTYG DU VILL JUSTERA"
desc1 = "Håll ner Skift-tangenten och tryck på kronan för att gå till föregående verktyg"

title2 = "ANPASSA KRONANS FUNKTIONER"
desc2 = "Välj och vraka bland dina favoritverktyg i Options<br>för att skapa optimalt arbetsflöde"
