btn_back = "上一頁"
btn_next = "下一頁"
btn_done = "完成"

title0 = "使用多功能轉鈕來編輯您的照片"
desc0 = "點按多功能轉鈕可選擇工具，<br>轉動多功能轉鈕可變更其數值"

title1 = "選擇您要調整的工具"
desc1 = "按住 Shift 鍵然後點按多功能轉鈕可回到上一個工具"

title2 = "自訂多功能轉鈕功能"
desc2 = "在 Options 中挑選您喜愛的工具<br>來建立您最佳的工作流程"
