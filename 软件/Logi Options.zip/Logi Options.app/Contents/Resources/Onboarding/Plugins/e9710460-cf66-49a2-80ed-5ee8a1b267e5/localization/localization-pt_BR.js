btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "USE O CROWN PARA EDITAR SUA FOTO"
desc0 = "Toque no Crown para selecionar uma ferramenta<br>e transformar o Crown para mudar seu valor"

title1 = "SELECIONE A FERRAMENTA QUE QUER AJUSTAR"
desc1 = "Segure a tecla shift e toque no Crown para ir para a ferramenta anterior"

title2 = "PERSONALIZE AS FUNÇÕES DO CROWN"
desc2 = "Escolha suas ferramentas favoritas no Options<br>para criar seu fluxo de trabalho"
