btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "MUOKKAA VALOKUVAASI KRUUNUN AVULLA"
desc0 = "Valitse työkalu napauttamalla kruunua<br>ja muuta sen arvoa kiertämällä kruunua"

title1 = "VALITSE TYÖKALU, JOTA HALUAT SÄÄTÄÄ"
desc1 = "Siirry edelliseen työkaluun painamalla vaihtonäppäintä ja napauttamalla kruunua"

title2 = "MUKAUTA KRUUNUN TOIMINTOJA"
desc2 = "Valitse suosikkityökalusi Options -ohjelmistossa<br>ja luo itsellesi sopiva työnkulku"
