btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "GEBRUIK DE DRAAIKNOP OM UW FOTO TE BEWERKEN"
desc0 = "Tik op de draaiknop om een tool te selecteren<br>en draai de knop om de waarde ervan te wijzigen"

title1 = "SELECTEER DE TOOL DIE U WILT AANPASSEN"
desc1 = "Houd de Shift-toets ingedrukt en tik op de draaiknop om naar de vorige tool te gaan"

title2 = "PAS DE DRAAIKNOPFUNCTIES AAN"
desc2 = "Kies uw favoriete tools in Options<br>om uw eigen optimale workflow in te stellen"
