btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "DREHREGLER ZUR FOTO-BEARBEITUNG VERWENDEN"
desc0 = "Zum Auswählen eines Werkzeugs auf den Drehregler tippen<br>und dann zum Ändern von Werten den Drehregler drehen"

title1 = "DAS WERKZEUG AUSWÄHLEN, DAS ANGEPASST WERDEN SOLL"
desc1 = "Die Umschalttaste gedrückt halten und auf den Drehregler tippen, um zum vorher ausgewählten Werkzeug zurückzugehen"

title2 = "DREHREGLER-FUNKTIONEN ANPASSEN"
desc2 = "In Options Lieblingswerkzeuge auswählen,<br>um für einen optimalen Arbeitsablauf zu sorgen"
