btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "UTILISEZ LA MOLETTE POUR ÉDITER VOTRE PHOTO"
desc0 = "Appuyez sur la molette pour sélectionner un outil<br>et faites-la pivoter pour changer sa valeur"

title1 = "SÉLECTIONNEZ L'OUTIL QUE VOUS SOUHAITEZ AJUSTER"
desc1 = "Maintenez la touche Maj enfoncée et appuyez sur la molette pour accéder à l'outil précédent"

title2 = "PERSONNALISER LES FONCTIONS DE LA MOLETTE"
desc2 = "Choisissez vos outils préférés dans Options<br>pour créer votre flux de travail optimal"
