btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "UŻYJ KORONY, ABY EDYTOWAĆ ZDJĘCIE"
desc0 = "Naciśnij koronę, aby wybrać narzędzie.<br>Obróć koronę, aby zmienić jego wartość."

title1 = "WYBIERZ NARZĘDZIE, KTÓRE CHCESZ DOSTOSOWAĆ"
desc1 = "Przytrzymaj klawisz Shift i naciśnij koronę, aby przejść do poprzedniego narzędzia."

title2 = "DOSTOSUJ FUNKCJE KORONY"
desc2 = "Aby stworzyć optymalny przepływ pracy, wybierz<br>ulubione narzędzia w oprogramowaniu Options."
