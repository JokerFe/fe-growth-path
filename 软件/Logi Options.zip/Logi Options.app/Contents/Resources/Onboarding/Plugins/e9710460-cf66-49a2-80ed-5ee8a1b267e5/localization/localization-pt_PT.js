btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "UTILIZAR A COROA PARA EDITAR A SUA FOTOGRAFIA"
desc0 = "Toque na Coroa para seleccionar uma ferramenta<br>e rode a Coroa para alterar o valor"

title1 = "SELECCIONAR A FERRAMENTA QUE PRETENDE AJUSTAR"
desc1 = "Mantenha premida a tecla Shift e toque na Coroa para aceder à ferramenta anterior"

title2 = "PERSONALIZAR AS FUNÇÕES DA COROA"
desc2 = "Escolha as suas ferramentas favoritas no Options<br>para criar o seu fluxo de trabalho optimizado"
