btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "BRUK KRONEN TIL Å REDIGERE BILDET DITT"
desc0 = "Trykk på Kronen for å velge et verktøy<br>og drei på Kronen for å endre verdien"

title1 = "VELG VERKTØYET DU VIL JUSTERE"
desc1 = "Hold inne shift-tasten og trykk på Kronen for å gå til forrige verktøy"

title2 = "TILPASS FUNKSJONER FOR KRONEN"
desc2 = "Velg favorittverktøyene dine i Options<br>for å opprette en optimal arbeidsflyt"
