btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "BRUG KRONEN TIL AT REDIGERE FOTOET"
desc0 = "Tryk på kronen for at vælge et værktøj<br>, og drej kronen for at ændre dets værdi"

title1 = "VÆLG DET VÆRKTØJ SOM DU VIL TILPASSE"
desc1 = "Tryk på kronen mens du holder Shift-tasten nede for at gå tilbage til det forrige værktøj"

title2 = "TILPAS KRONEFUNKTIONERNE"
desc2 = "Vælg dine yndlingsværktøjer i Options<br>, og skab den perfekte arbejdsgang"
