btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "USE THE CROWN TO EDIT YOUR PHOTO"
desc0 = "Tap the Crown to select a tool<br>and turn the Crown to change its value"

title1 = "SELECT THE TOOL YOU WANT TO ADJUST"
desc1 = "Hold the shift key and tap the Crown to go to the previous tool"

title2 = "CUSTOMIZE THE CROWN FUNCTIONS"
desc2 = "Pick and choose your favorite tools in Options<br>to build your optimal workflow"
