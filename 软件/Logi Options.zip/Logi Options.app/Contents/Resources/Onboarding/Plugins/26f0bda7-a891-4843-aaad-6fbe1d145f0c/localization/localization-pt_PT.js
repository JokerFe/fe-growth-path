btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "MUDAR DE SEPARADOR"
desc0 = "Rode a Coroa para mudar entre os vários separadores abertos no seu browser"

title1 = "ALTERAR O TAMANHO DO TIPO DE LETRA NO APRESENTAÇÕES DO GOOGLE E DOCUMENTOS DO GOOGLE"
desc1 = "Seleccione o texto no seu documento e rode a Coroa para ajustar o tamanho do tipo de letra"

title2 = "ALTERAR O TAMANHO DA IMAGEM NO APRESENTAÇÕES DO GOOGLE E DOCUMENTOS DO GOOGLE"
desc2 = "Seleccione uma imagem no seu documento e rode a Coroa para ajustar o tamanho"

