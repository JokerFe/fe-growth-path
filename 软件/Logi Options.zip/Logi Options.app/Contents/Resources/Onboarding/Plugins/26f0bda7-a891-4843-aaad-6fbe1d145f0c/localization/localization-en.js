btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "SWITCH THROUGH YOUR TABS"
desc0 = "Turn the Crown to switch between the different open tabs of your browser"

title1 = "CHANGE FONT SIZE IN GOOGLE SLIDES AND GOOGLE DOCS"
desc1 = "Select text in your document and turn the Crown to adjust the font size"

title2 = "CHANGE IMAGE SIZE IN GOOGLE SLIDES AND GOOGLE DOCS"
desc2 = "Select an image in your document and turn the Crown to adjust its size"

