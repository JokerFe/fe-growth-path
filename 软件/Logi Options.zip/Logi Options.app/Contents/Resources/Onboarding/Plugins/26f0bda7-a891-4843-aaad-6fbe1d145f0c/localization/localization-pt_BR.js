btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "ALTERNE GUIAS"
desc0 = "Ative o Crown para alternar entre as vários guias abertas do navegador"

title1 = "TROQUE O TAMANHO DA FONTE NO GOOGLE SLIDES E GOOGLE DOCS"
desc1 = "Selecione texto no seu documento e ative o Crown para ajustar o tamanho da fonte"

title2 = "TROQUE O TAMANHO DA IMAGEM NO GOOGLE SLIDES E GOOGLE DOCS"
desc2 = "Selecione uma imagem no seu documento e ative o Crown para ajustar o tamanho"

