btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "CAMBIAR DE PESTAÑA"
desc0 = "Gire la corona para pasar de una pestaña a otra entra las que estén abiertas en el navegador"

title1 = "CAMBIAR TAMAÑO DE FUENTE EN DIAPOSITIVAS DE GOOGLE Y DOCUMENTOS DE GOOGLE"
desc1 = "Seleccione texto en un documento y gire la corona para modificar el tamaño de fuente"

title2 = "CAMBIAR TAMAÑO DE IMÁGENES EN DIAPOSITIVAS DE GOOGLE Y DOCUMENTOS DE GOOGLE"
desc2 = "Seleccione una imagen en un documento y gire la corona para modificar el tamaño de la imagen"

