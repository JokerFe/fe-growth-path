btn_back = "뒤로"
btn_next = "다음"
btn_done = "완료"

title0 = "탭 전환"
desc0 = "브라우저에서 열려 있는 여러 탭을 전환하려면 크라운을 돌리십시오."

title1 = "GOOGLE SLIDES 및 GOOGLE DOCS에서 글꼴 크기 변경"
desc1 = "문서에서 텍스트를 선택하고 크라운을 돌려서 글꼴 크기를 조정하십시오."

title2 = "GOOGLE SLIDES 및 GOOGLE DOCS에서 이미지 크기 변경"
desc2 = "문서에서 이미지를 선택하고 크라운을 돌려서 크기를 조정하십시오."

