btn_back = "上一頁"
btn_next = "下一頁"
btn_done = "完成"

title0 = "在標籤間切換"
desc0 = "轉動多功能轉鈕可切換您瀏覽器開啟的不同標籤"

title1 = "在 GOOGLE SLIDES 和 GOOGLE DOCS 中變更字型大小"
desc1 = "選擇您文件中的文字然後轉動多功能轉鈕可調整字型大小"

title2 = "在 GOOGLE SLIDES 和 GOOGLE DOCS 中變更影像大小"
desc2 = "選擇您文件中的影像然後轉動多功能轉鈕可調整其大小"

