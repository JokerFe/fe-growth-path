btn_back = "后退"
btn_next = "前进"
btn_done = "完成"

title0 = "切换各个选项卡"
desc0 = "旋转多功能旋钮可在浏览器中打开的多个选项卡之间进行切换"

title1 = "在 GOOGLE SLIDES 和 GOOGLE DOCS 中更改字号"
desc1 = "在文档中选中文本，并旋转多功能旋钮来调整字号"

title2 = "在 GOOGLE SLIDES 和 GOOGLE DOCS 中更改图像尺寸"
desc2 = "在文档中选中图像，并旋转多功能旋钮来调整大小"

