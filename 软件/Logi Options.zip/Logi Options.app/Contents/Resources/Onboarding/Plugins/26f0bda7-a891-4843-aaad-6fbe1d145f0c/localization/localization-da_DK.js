btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "SKIFT MELLEM FANER"
desc0 = "Drej Crown for at skifte mellem de forskellige åbne faner i browseren"

title1 = "SKIFT SKRIFTSTØRRELSE I GOOGLE SLIDES OG GOOGLE DOCS"
desc1 = "Markér tekst i et dokument, og drej Crown for at justere skriftstørrelsen"

title2 = "SKIFT BILLEDSTØRRELSE I GOOGLE SLIDES OG GOOGLE DOCS"
desc2 = "Markér et billede i et dokument, og drej Crown for at justere størrelsen"

