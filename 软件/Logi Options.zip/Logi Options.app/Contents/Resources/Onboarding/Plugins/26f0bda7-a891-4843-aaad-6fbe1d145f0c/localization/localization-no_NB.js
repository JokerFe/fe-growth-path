btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "BLA GJENNOM FANER"
desc0 = "Drei på kronen for å bytte mellom de åpne fanene i nettleseren"

title1 = "ENDRE SKRIFTSTØRRELSE I GOOGLE SLIDES OG GOOGLE DOCS"
desc1 = "Merk ønsket tekst i dokumentet og drei på kronen for å justere skriftstørrelsen"

title2 = "ENDRE BILDESTØRRELSE I GOOGLE SLIDES OG GOOGLE DOCS"
desc2 = "Merk et bilde i dokumentet og drei på kronen for å justere størrelsen"

