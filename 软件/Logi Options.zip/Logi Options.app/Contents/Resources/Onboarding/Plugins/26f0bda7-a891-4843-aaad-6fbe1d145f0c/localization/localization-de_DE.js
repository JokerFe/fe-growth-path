btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "WECHSELN ZWISCHEN REGISTERKARTEN"
desc0 = "Drehen Sie das Drehrad zum Wechseln zwischen den einzelnen in Ihrem Webbrowser geöffneten Registerkarten"

title1 = "ÄNDERN DER SCHRIFTGRÖSSE FÜR GOOGLE PRÄSENTATIONEN UND GOOGLE DOCS"
desc1 = "Markieren Sie Text in Ihrem Dokument und drehen Sie das Drehrad zum Anpassen der Schriftgröße"

title2 = "ÄNDERN DER BILDGRÖSSE FÜR GOOGLE PRÄSENTATIONEN UND GOOGLE DOCS"
desc2 = "Markieren Sie ein Bild in Ihrem Dokument und drehen Sie das Drehrad zum Anpassen der Größe"

