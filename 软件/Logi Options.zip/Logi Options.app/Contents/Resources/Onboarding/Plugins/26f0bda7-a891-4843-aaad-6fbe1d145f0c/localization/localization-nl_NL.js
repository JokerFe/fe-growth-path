btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "DOOR UW TABBLADEN BLADEREN"
desc0 = "Roteer de draaiknop om door verschillende geopende tabbladen in uw browser te bladeren"

title1 = "LETTERGROOTTE WIJZIGEN IN GOOGLE SLIDES EN GOOGLE DOCS"
desc1 = "Selecteer tekst in uw document en roteer de draaiknop om de lettergrootte aan te passen"

title2 = "AFBEELDINGSGROOTTE WIJZIGEN IN GOOGLE SLIDES EN GOOGLE DOCS"
desc2 = "Selecteer een afbeelding in uw document en roteer de draaiknop om de grootte aan te passen"

