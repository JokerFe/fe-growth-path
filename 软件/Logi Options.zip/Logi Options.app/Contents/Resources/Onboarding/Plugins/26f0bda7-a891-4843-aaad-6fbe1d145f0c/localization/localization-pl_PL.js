btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "PRZEŁĄCZANIE KART"
desc0 = "Obróć koronę, aby przełączać się między różnymi kartami otwartymi w przeglądarce"

title1 = "ZMIANA ROZMIARU CZCIONKI W PREZENTACJACH GOOGLE I DOKUMENTACH GOOGLE"
desc1 = "Zaznacz tekst w dokumencie i obróć koronę, aby dostosować rozmiar czcionki"

title2 = "ZMIANA ROZMIARU OBRAZÓW W PREZENTACJACH GOOGLE I DOKUMENTACH GOOGLE"
desc2 = "Zaznacz obraz w dokumencie i obróć koronę, aby dostosować jego rozmiar"

