btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "BLÄDDRA BLAND FLIKAR"
desc0 = "Vrid kronan för att bläddra bland olika öppna flikar i din webbläsare"

title1 = "ÄNDRA STORLEK PÅ TECKENSNITT I GOOGLE SLIDES OCH GOOGLE DOCS"
desc1 = "Välj text i ditt dokument och vrid på kronan för att ändra teckensnittets storlek"

title2 = "ÄNDRA BILDSTORLEK I GOOGLE SLIDES OCH GOOGLE DOCS"
desc2 = "Välj en bild i ditt dokument och vrid på kronan för att ändra bildens storlek"

