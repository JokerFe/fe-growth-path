btn_back = "戻る"
btn_next = "進む"
btn_done = "完了"

title0 = "タブを切り替え"
desc0 = "コントロールホイールを回して、ブラウザの様々な開いているタブを切り替えます"

title1 = "GOOGLE SLIDES と GOOGLE DOCS でフォントサイズを変更"
desc1 = "ドキュメントのテキストを選択してコントロールホイールを回し、フォントサイズを調整します"

title2 = "GOOGLE SLIDES と GOOGLE DOCS で画像サイズを変更"
desc2 = "ドキュメント内の画像を選択してコントロールホイールを回し、サイズを調整します"

