btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "VAIHDA VÄLILEHTIEN VÄLILLÄ"
desc0 = "Käännä kruunua vaihtaaksesi selaimesi avointen välilehtien välillä"

title1 = "MUUTA FONTTIKOKOA GOOGLE SLIDESISSA JA GOOGLE DOCSISSA"
desc1 = "Valitse tekstiä dokumentissasi ja säädä fonttikokoa kääntämällä kruunua"

title2 = "MUUTA FONTTIKOKOA GOOGLE SLIDESISSA JA GOOGLE DOCSISSA"
desc2 = "Valitse kuva dokumentissasi ja säädä sen kokoa kääntämällä kruunua"

