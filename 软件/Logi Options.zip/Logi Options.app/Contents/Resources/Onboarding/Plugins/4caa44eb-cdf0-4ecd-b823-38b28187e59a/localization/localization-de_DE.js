btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "NAVIGIEREN DURCH TABELLENKALKULATIONEN"
desc0 = "Markieren Sie eine Zelle und drehen Sie das Drehrad zur horizontalen Navigation durch das Tabellenblatt"

title1 = "ERSTELLEN EINES DIAGRAMMS"
desc1 = "Markieren Sie mehrere Zellen und drehen Sie das Drehrad zur Erstellung eines Diagramms"

title2 = "ÄNDERN DES DIAGRAMMSTILS"
desc2 = "Klicken Sie auf ein beliebiges Diagramm und drehen Sie das Drehrad zum Ändern des Diagrammstils"

