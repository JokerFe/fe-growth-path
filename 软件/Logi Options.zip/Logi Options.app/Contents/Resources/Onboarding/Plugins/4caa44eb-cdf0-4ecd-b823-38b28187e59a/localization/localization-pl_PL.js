btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "NAWIGACJA PO ARKUSZU KALKULACYJNYM"
desc0 = "Zaznacz komórkę i obróć koronę, aby nawigować po arkuszu kalkulacyjnym w poziomie"

title1 = "TWORZENIE WYKRESU"
desc1 = "Zaznacz wiele komórek i obróć koronę, aby utworzyć wykres"

title2 = "ZMIANA STYLU WYKRESU"
desc2 = "Kliknij dowolny wykres i obróć koronę, aby zmienić jego styl"

