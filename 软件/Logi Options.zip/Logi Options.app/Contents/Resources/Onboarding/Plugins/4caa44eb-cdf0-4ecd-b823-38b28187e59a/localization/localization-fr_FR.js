btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "NAVIGUEZ DANS UN TABLEUR"
desc0 = "Sélectionnez une cellule et tournez la molette pour naviguer dans le tableur à l'horizontale."

title1 = "CRÉEZ UN GRAPHIQUE"
desc1 = "Sélectionnez plusieurs cellules et tournez la molette pour créer un graphique."

title2 = "MODIFIEZ LE STYLE DE GRAPHIQUE"
desc2 = "Cliquez sur un graphique et tournez la molette pour modifier son style."

