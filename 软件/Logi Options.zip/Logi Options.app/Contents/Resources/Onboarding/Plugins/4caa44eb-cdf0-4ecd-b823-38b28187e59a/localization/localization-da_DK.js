btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "NAVIGER I REGNEARK"
desc0 = "Markér en celle, og drej Crown for at navigere vandret i et regneark"

title1 = "OPRET ET DIAGRAM"
desc1 = "Markér flere celler, og drej Crown for at oprette et diagram"

title2 = "SKIFT DIAGRAMSTIL"
desc2 = "Klik på et diagram, og drej Crown for at ændre stilen"

