btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "LIIKU LASKENTATAULUKOSSA"
desc0 = "Valitse solu ja liiku laskentataulukossa vaakatasossa kääntämällä kruunua"

title1 = "LUO KAAVIO"
desc1 = "Valitse useita soluja ja luo kaavio kääntämällä kruunua"

title2 = "MUUTA KAAVION TYYLIÄ"
desc2 = "Napsauta mitä tahansa kaaviota ja muutan sen tyyliä kääntämällä kruunua"

