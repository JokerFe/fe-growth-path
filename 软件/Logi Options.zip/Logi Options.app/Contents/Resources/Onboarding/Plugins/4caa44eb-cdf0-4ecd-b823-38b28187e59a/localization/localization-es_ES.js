btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "NAVEGAR EN HOJAS DE CÁLCULO"
desc0 = "Seleccione una celda y gire la corona para recorrer la hoja horizontalmente"

title1 = "CREAR GRÁFICOS"
desc1 = "Seleccione varias celdas y gire la corona para crear un gráfico"

title2 = "CAMBIAR ESTILO DE GRÁFICOS"
desc2 = "Haga clic en un gráfico y gire la corona para cambiar su estilo"

