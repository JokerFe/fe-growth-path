btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "NAVIGER I REGNEARK"
desc0 = "Velg en celle og drei på kronen for å navigere vannrett i regnearket"

title1 = "OPPRETT ET DIAGRAM"
desc1 = "Velg flere celler og drei på kronen for å opprette et diagram"

title2 = "ENDRE DIAGRAMSTIL"
desc2 = "Klikk på et vilkårlig diagram og drei på kronen for å endre stilen til diagrammet"

