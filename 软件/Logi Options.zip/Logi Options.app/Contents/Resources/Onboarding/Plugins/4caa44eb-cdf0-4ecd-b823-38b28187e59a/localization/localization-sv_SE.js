btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "NAVIGERA KALKYLBLAD"
desc0 = "Välj en cell och vrid kronan för att navigera horisontellt i kalkylbladet"

title1 = "SKAPA ETT DIAGRAM"
desc1 = "Välj flera celler och vrid kronan för att skapa ett diagram"

title2 = "ÄNDRA DIAGRAMFORMAT"
desc2 = "Klicka på ett diagram och vrid kronan för att ändra dess format"

