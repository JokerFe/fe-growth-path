btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "ESPLORAZIONE DEL FOGLIO DI CALCOLO"
desc0 = "Seleziona una cella e ruota il pulsante girevole per esplorare il foglio di calcolo orizzontalmente"

title1 = "CREAZIONE DI UN GRAFICO"
desc1 = "Seleziona più celle e ruota il pulsante girevole per creare un grafico"

title2 = "MODIFICA STILE GRAFICO"
desc2 = "Fai clic su qualsiasi grafico e ruota il pulsante girevole per modificarne lo stile"

