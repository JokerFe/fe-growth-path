btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "IN SPREADSHEET NAVIGEREN"
desc0 = "Selecteer een cel en roteer de draaiknop om horizontaal door het spreadsheet te navigeren"

title1 = "EEN DIAGRAM MAKEN"
desc1 = "Selecteer meerdere cellen en roteer de draaiknop om een diagram te maken"

title2 = "DIAGRAMSTIJL WIJZIGEN"
desc2 = "Klik op een diagram en roteer de draaiknop om de stijl te wijzigen"

