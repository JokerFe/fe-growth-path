btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "NAVEGAR FOLHAS DE CÁLCULO"
desc0 = "Seleccione uma célula e rode a Coroa para navegar horizontalmente na folha de cálculo"

title1 = "CRIAR UM GRÁFICO"
desc1 = "Seleccione várias células e rode a Coroa para criar um gráfico"

title2 = "ALTERAR O ESTILO DO GRÁFICO"
desc2 = "Clique num gráfico e rode a Coroa para alterar o estilo"

