btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "NAVIGATE SPREADSHEET"
desc0 = "Select a cell and turn the Crown to navigate the spreadsheet horizontally"

title1 = "CREATE A CHART"
desc1 = "Select multiple cells and turn the Crown to create a chart"

title2 = "CHANGE CHART STYLE"
desc2 = "Click on any chart and turn the Crown to change its style"

