btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "NAVEGAR NA PLANILHA"
desc0 = "Selecione uma célula e ative o Crown para navegar horizontalmente pela planilha"

title1 = "CRIE UM GRÁFICO"
desc1 = "Selecione múltiplas células e ative o Crown para criar um gráfico"

title2 = "TROQUE O ESTILO DO GRÁFICO"
desc2 = "Clique em qualquer gráfico e ative o Crown para alterar seu estilo"

