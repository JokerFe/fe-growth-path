btn_back = "PRÉCÉDENT"
btn_next = "SUIVANT"
btn_done = "TERMINÉ"

title0 = "LA MOLETTE EST TACTILE"
desc0 = "Touchez la molette pour accéder instantanément à des fonctions contextuelles."

title1 = "LA MOLETTE EST INTERACTIVE"
desc1 = "Tournez la molette pour interagir avec une fonction sélectionnée."

title2 = "LA MOLETTE EST CONTEXTUELLE"
desc2 = "La molette s'adapte à l'application que vous utilisez et à l'outil sélectionné"

title3 = "LA MOLETTE EST MULTIFONCTIONS"
desc3 = "Appuyez sur la molette pour changer instantanément de fonctions."
