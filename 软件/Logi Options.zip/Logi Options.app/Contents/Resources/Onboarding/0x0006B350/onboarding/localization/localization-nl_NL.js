btn_back = "VORIGE"
btn_next = "VOLGENDE"
btn_done = "GEREED"

title0 = "DE DRAAIKNOP IS AANRAAKGEVOELIG"
desc0 = "Raak de draaiknop aan om contextspecifieke functies direct te openen"

title1 = "DE DRAAIKNOP IS INTERACTIEF"
desc1 = "Roteer de draaiknop om met een geselecteerde functie te werken"

title2 = "DE DRAAIKNOP IS CONTEXTUEEL"
desc2 = "De draaiknop past zich aan de gebruikte app en de geselecteerde tool aan"

title3 = "DE DRAAIKNOP IS MULTIFUNCTIONEEL"
desc3 = "Tik op de draaiknop om bliksemsnel tussen functies te wisselen"
