btn_back = "EDELLINEN"
btn_next = "SEURAAVA"
btn_done = "VALMIS"

title0 = "KRUUNU REAGOI KOSKETUKSEEN"
desc0 = "Pääset välittömästi sisältökohtaisiin toimintoihin koskettamalla kruunua"

title1 = "KRUUNU ON INTERAKTIIVINEN"
desc1 = "Käännä kruunua käyttääksesi valittua toimintoa"

title2 = "KRUUNU ON SISÄLTÖKOHTAINEN"
desc2 = "Kruunu mukautuu käyttämääsi sovellukseen ja valitsemaasi työkaluun"

title3 = "KRUUNU ON MONITOIMINEN"
desc3 = "Vaihda välittömästi toimintoja napauttamalla kruunua"
