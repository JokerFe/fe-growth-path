function replaceString() {
        writeToLog("replaceString - start");
        /* REPLACE TEXT */

        var btns = document.getElementsByClassName('btn_cancel');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_cancel);
        }

        var btns = document.getElementsByClassName('btn_continue');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_continue);
        }

        var btns = document.getElementsByClassName('btn_back');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_back);
        }

        var btns = document.getElementsByClassName('error');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], window["error" + i]);
        }

        var btns = document.getElementsByClassName('btn_next');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_next);
        }

        var btns = document.getElementsByClassName('btn_done');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_done);
        }

        var btns = document.getElementsByClassName('link_website');
        for (var i = 0; i < btns.length; i++) {

                replaceWebsite(btns[i], link_website);
        }

        var btns = document.getElementsByClassName('link_howToPair');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], link_howToPair);
        }

        var btns = document.getElementsByClassName('btn_howTo');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_howTo);
        }

        var btns = document.getElementsByClassName('btn_enableFlow');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_enableFlow);
        }

        var btns = document.getElementsByClassName('btn_retry');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_retry);
        }

        replaceTitleAndDesc();

        function replaceTitleAndDesc() {
                writeToLog("replaceTitleAndDesc - start");

                var titles = document.getElementsByClassName('title');
                writeToLog("replaceTitleAndDesc - titles count:" + titles.length);
                for (var i = 0; i < titles.length; i++) {
                        try {
                                writeToLog("replaceTitleAndDesc - titles:" + titles[i].innerHTML + " position:" + i + " window title:" + window["title" + i]);
                                replaceStr(titles[i], window["title" + i]);
                                /* ALIGN TEXT AT BOTTOM OF DIV */

                                titles[i].parentElement.style.height = "60px";
                                titles[i].style.height = "auto";
                                titles[i].style.bottom = "20px";
                        } catch (error) {
                                writeToLog(error);
                        }
                }

                var descs = document.getElementsByClassName('desc');
                writeToLog("replaceTitleAndDesc - desc count:" + descs.length);
                for (var i = 0; i < descs.length; i++) {
                        try {
                                writeToLog("replaceTitleAndDesc - desc:" + descs[i].innerHTML + " position:" + i + " window desc:" + window["desc" + i]);
                                replaceStr(descs[i], window["desc" + i]);
                        } catch (error) {
                                writeToLog(error);
                        }
                }

                writeToLog("replaceTitleAndDesc - end");
        }

        function replaceStr(className, stringName) {
                try {
                        var newString = stringName.replace("%LogiBrand%", brand).replace("%logibrand%", brand.toLowerCase()).replace("%LOGIBRAND%", brand.toUpperCase());
                        className.innerHTML = newString;
                } catch (error) {
                        writeToLog(error);
                }
        }

        function replaceWebsite(className, stringName) {
                try {
                        var newString = stringName.replace("%logiwebsite%", website);
                        className.innerHTML = newString;
                } catch (error) {
                        writeToLog(error);
                }
        }


        /* POSITION BTN X */

        var btns_align = document.getElementsByClassName('center');
        for (var i = 0; i < btns_align.length; i++) {
                positionX(btns_align[i], "center");
        }

        var btns_align = document.getElementsByClassName('left');
        for (var i = 0; i < btns_align.length; i++) {
                positionX(btns_align[i], "left");
        }

        var btns_align = document.getElementsByClassName('right');
        for (var i = 0; i < btns_align.length; i++) {
                positionX(btns_align[i], "right");
        }

        /* POSITION BTN Y */

        var btns_align = document.getElementsByClassName('up');
        for (var i = 0; i < btns_align.length; i++) {
                positionY(btns_align[i], "up");
        }

        function positionX(div, positionX) {
                writeToLog("positionX - start");
                var posX;
                div.style.width = "auto";
                div.style.minWidth = "100px";
                div.style.paddingLeft = div.style.paddingRight = "15px";

                if (positionX === "center") {
                        posX = 500 - (div.clientWidth / 2);
                        div.style.transform = "translateX(0px) translateY(0px)";
                        div.style.left = posX + "px";
                } else if (positionX === "left") {
                        posX = 500 - (div.clientWidth) - 10;
                        div.style.transform = "translateX(0px) translateY(0px)";
                        div.style.left = posX + "px";
                } else if (positionX === "right") {
                        posX = 510;
                        div.style.transform = "translateX(0px) translateY(0px)";
                        div.style.left = posX + "px";
                }

        }

        function positionY(div, positionY) {
                writeToLog("positionY - start");
                var posY;

                if (positionY === "up") {
                        posY = 524;
                        div.style.top = posY + "px";
                } else if (positionY === "down") {
                        posY = 580;
                        div.style.top = posY + "px";
                }
        }

        writeToLog("replaceString - end");
}
