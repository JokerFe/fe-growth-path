btn_back = "TILBAKE"
btn_next = "NESTE"
btn_done = "FERDIG"

title0 = "KRONEN ER BERØRINGSFØLSOM"
desc0 = "Berør kronen for å få direkte tilgang til kontekstavhengige funksjoner"

title1 = "KRONEN ER INTERAKTIV"
desc1 = "Berør kronen for å samhandle med en valgt funksjon"

title2 = "KRONEN ER KONTEKSTAVHENGIG"
desc2 = "Kronen tilpasses appen du bruker og verktøyene du velger"

title3 = "KRONEN HAR FLERE FUNKSJONER"
desc3 = "Tapp på kronen for å endre funksjoner umiddelbart"
