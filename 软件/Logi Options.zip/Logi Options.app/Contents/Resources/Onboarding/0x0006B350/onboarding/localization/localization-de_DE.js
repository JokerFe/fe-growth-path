btn_back = "ZURÜCK"
btn_next = "WEITER"
btn_done = "FERTIG"

title0 = "DAS DREHRAD IST BERÜHRUNGSEMPFINDLICH"
desc0 = "Berühren Sie das Drehrad für sofortigen Zugriff auf kontextspezifische Funktionen"

title1 = "DAS DREHRAD IST INTERAKTIV"
desc1 = "Drehen Sie das Drehrad zur Interaktion mit einer ausgewählten Funktion"

title2 = "DAS DREHRAD IST KONTEXTSPEZIFISCH"
desc2 = "Das Drehrad passt sich an die derzeit verwendete App bzw. das derzeit verwendete Tool an"

title3 = "DAS DREHRAD VERFÜGT ÜBER EINE VIELZAHL VERSCHIEDENER FUNKTIONEN"
desc3 = "Tippen Sie auf das Drehrad zum sofortigen Ändern von Funktionen"
