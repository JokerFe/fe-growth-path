btn_back = "BACK"
btn_next = "NEXT"
btn_done = "DONE"

title0 = "THE CROWN IS TOUCH SENSITIVE"
desc0 = "Touch the Crown to instantly access context-specific functions"

title1 = "THE CROWN IS INTERACTIVE"
desc1 = "Turn the Crown to interact with a selected function"

title2 = "THE CROWN IS CONTEXTUAL"
desc2 = "The Crown adapts to the app you're using and tool selected"

title3 = "THE CROWN HAS MULTIPLE FUNCTIONS"
desc3 = "Tap the Crown to instantly change functions"
