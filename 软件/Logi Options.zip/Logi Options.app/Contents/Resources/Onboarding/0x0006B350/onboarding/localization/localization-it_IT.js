btn_back = "INDIETRO"
btn_next = "AVANTI"
btn_done = "FINE"

title0 = "IL PULSANTE GIREVOLE È SENSIBILE AL TOCCO"
desc0 = "Tocca il pulsante girevole per ottenere accesso immediato a funzioni specifiche del contesto"

title1 = "IL PULSANTE GIREVOLE È INTERATTIVO"
desc1 = "Ruota il pulsante girevole per interagire con una funzione selezionata"

title2 = "IL PULSANTE GIREVOLE È CONTESTUALE"
desc2 = "Il pulsante girevole si adatta all'app e allo strumento utilizzati al momento"

title3 = "IL PULSANTE GIREVOLE HA PIÙ FUNZIONI"
desc3 = "Tocca il pulsante girevole per modificare le funzioni istantaneamente"
