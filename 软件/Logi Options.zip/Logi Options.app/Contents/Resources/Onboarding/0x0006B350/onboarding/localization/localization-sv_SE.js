btn_back = "TILLBAKA"
btn_next = "NÄSTA"
btn_done = "KLART"

title0 = "KRONAN ÄR PEKKÄNSLIG"
desc0 = "Rör vid kronan för att direkt får tillgång till kontextspecifika funktioner"

title1 = "KRONAN ÄR INTERAKTIV"
desc1 = "Vrid kronan för att interagera med en vald funktion"

title2 = "KRONAN ÄR KONTEXTKÄNSLIG"
desc2 = "Kronan anpassar sig efter den app du använder och det verktyg du valt"

title3 = "KRONAN HAR FLERA FUNKTIONER"
desc3 = "Tryck på kronan för att byta funktion direkt"
