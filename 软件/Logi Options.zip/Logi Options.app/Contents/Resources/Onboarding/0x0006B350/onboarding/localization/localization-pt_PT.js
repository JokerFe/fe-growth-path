btn_back = "ANTERIOR"
btn_next = "SEGUINTE"
btn_done = "CONCLUÍDO"

title0 = "A COROA É SENSÍVEL AO TOQUE"
desc0 = "Toque na Coroa para aceder instantaneamente a funções de contexto específicas"

title1 = "A COROA É INTERACTIVA"
desc1 = "Rode a Coroa para interagir com a função seleccionada"

title2 = "A COROA É CONTEXTUAL"
desc2 = "A Coroa adapta-se à aplicação que estiver a utilizar e à ferramenta seleccionada"

title3 = "A COROA TEM VÁRIAS FUNÇÕES"
desc3 = "Toque na Coroa para mudar instantaneamente as funções"
