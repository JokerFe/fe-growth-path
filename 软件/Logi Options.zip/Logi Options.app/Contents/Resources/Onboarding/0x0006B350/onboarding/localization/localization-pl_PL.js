btn_back = "WSTECZ"
btn_next = "DALEJ"
btn_done = "GOTOWE"

title0 = "KORONA REAGUJE NA DOTYK"
desc0 = "Dotknij korony, aby natychmiast uzyskać dostęp do funkcji kontekstowych"

title1 = "KORONA JEST INTERAKTYWNA"
desc1 = "Obróć koronę, aby rozpocząć interakcję z wybraną funkcją"

title2 = "KORONA JEST KONTEKSTOWA"
desc2 = "Korona dostosowuje się do używanej aplikacji i wybranego narzędzia"

title3 = "KORONA MA WIELE FUNKCJI"
desc3 = "Naciśnij koronę, aby natychmiast zmieniać funkcje"
