btn_back = "TILBAGE"
btn_next = "NÆSTE"
btn_done = "OK"

title0 = "CROWN ER BERØRINGSFØLSOM"
desc0 = "Tryk på Crown for at få adgang til kontekstafhængige funktioner"

title1 = "CROWN ER INTERAKTIV"
desc1 = "Drej Crown for at interagere med den valgte funktion"

title2 = "CROWN ER KONTEKSTAFHÆNGIG"
desc2 = "Crown tilpasses efter den app du bruger, og det valgte værktøj"

title3 = "CROWN HAR MANGE FUNKTIONER"
desc3 = "Tryk på Crown for at skifte funktion"
