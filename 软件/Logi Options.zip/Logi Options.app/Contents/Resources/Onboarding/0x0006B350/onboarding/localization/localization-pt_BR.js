btn_back = "VOLTAR"
btn_next = "AVANÇAR"
btn_done = "COMPLETO"

title0 = "O CROWN É SENSÍVEL AO TOQUE"
desc0 = "Toque no Crown para acessar instantaneamente as funções específicas de contexto"

title1 = "O CROWN É INTERATIVO"
desc1 = "Vire o Crown para interagir com a função selecionada"

title2 = "O CROWN É CONTEXTUAL"
desc2 = "O Crown se adapta ao aplicativo que você está usando e à ferramenta selecionada"

title3 = "O CROWN TEM DIVERSAS FUNÇÕES"
desc3 = "Toque no Crown para alterar instantaneamente as funções"
