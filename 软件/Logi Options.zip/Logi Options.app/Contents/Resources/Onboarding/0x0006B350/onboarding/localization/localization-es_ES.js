btn_back = "ATRÁS"
btn_next = "SIGUIENTE"
btn_done = "HECHO"

title0 = "LA CORONA ES SENSIBLE AL TACTO"
desc0 = "Toque la corona para acceder al instante a funciones contextuales"

title1 = "LA CORONA ES INTERACTIVA"
desc1 = "Gire la corona para interactuar con una función seleccionada"

title2 = "LA CORONA ES CONTEXTUAL"
desc2 = "La corona se adapta a la aplicación en uso y la herramienta seleccionada"

title3 = "LA CORONA TIENE VARIAS FUNCIONES"
desc3 = "Pulse la corona para cambiar de función al instante"
