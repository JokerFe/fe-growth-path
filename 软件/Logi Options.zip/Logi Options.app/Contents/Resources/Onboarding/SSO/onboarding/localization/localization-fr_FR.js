title0 = "CONNECTEZ-VOUS POUR SAUVEGARDER VOS PARAMÈTRES SUR LE CLOUD"
desc0 = "En vous connectant, vous pouvez sauvegarder vos paramètres sur le cloud et rester informé des nouveautés produits."

btn_continue = "CONNECTEZ-VOUS OU CRÉEZ UN COMPTE"