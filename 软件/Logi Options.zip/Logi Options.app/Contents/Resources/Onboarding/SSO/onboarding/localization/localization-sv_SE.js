title0 = "LOGGA IN FÖR ATT SÄKERHETSKOPIERA DINA INSTÄLLNINGAR TILL MOLNET"
desc0 = "Genom att logga in kan du säkerhetskopiera dina inställningar till molnet och hålla dig uppdaterad med produktinformation."

btn_continue = "LOGGA IN ELLER SKAPA ETT KONTO"