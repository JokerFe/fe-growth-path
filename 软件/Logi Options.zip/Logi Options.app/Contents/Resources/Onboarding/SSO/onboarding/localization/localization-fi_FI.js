title0 = "KIRJAUDU SISÄÄN VARMUUSKOPIOIDAKSESI ASETUKSESI PILVIPALVELUUN"
desc0 = "Kun olet kirjautunut sisään, voit varmuuskopioida asetuksesi pilvipalveluun ja saat ajantasaisia tuotetietoja."

btn_continue = "KIRJAUDU SISÄÄN TAI LUO TILI"