title0 = "FAÇA LOGIN PARA FAZER BACKUP DE SUAS CONFIGURAÇÕES NA NUVEM"
desc0 = "Ao fazer login, você pode fazer backup de suas configurações na nuvem e manter-se atualizado com as informações do produto."

btn_continue = "FAÇA LOGIN OU CRIE CONTA"