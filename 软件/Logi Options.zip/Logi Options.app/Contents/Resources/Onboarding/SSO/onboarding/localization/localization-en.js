title0 = "LOG IN TO BACKUP YOUR SETTINGS TO THE CLOUD"
desc0 = "By logging in, you can back up your settings to the cloud and stay up to date with product information."

btn_continue = "LOG IN OR CREATE ACCOUNT"