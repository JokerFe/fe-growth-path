title0 = "LOG IND FOR AT SIKKERHEDSKOPIERE DINE INDSTILLINGERNE TIL SKYEN"
desc0 = "Når du logger på, kan du sikkerhedskopiere dine indstillinger til skyen og holde dig opdateret med de seneste produktnyheder."

btn_continue = "LOG IND, ELLER OPRET EN KONTO"