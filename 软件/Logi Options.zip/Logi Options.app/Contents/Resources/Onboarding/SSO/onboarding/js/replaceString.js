function replaceString(){


		
		var titles = document.getElementsByClassName('title');
		replaceStr(titles[0],window["title0"]);
		titles[0].style.height = "auto";
		
		
		var descs = document.getElementsByClassName('desc');
		replaceStr(descs[0],window["desc0"]);
	

		var btns = document.getElementsByClassName('btn_continue');
		replaceStr(btns[0],window["btn_continue"]);	
		positionButton(btns[0]);

		rePosition();

		function replaceStr(className, stringName) {
			var newString = stringName.replace("%LogiBrand%", brand).replace("%logibrand%", brand.toLowerCase()).replace("%LOGIBRAND%", brand.toUpperCase());
	  		className.innerHTML = newString;
		}
		

		function positionButton(div) {
			div.style.position = "relative";
			div.style.display = "inline-block";
			div.style.paddingLeft = div.style.paddingRight = "15px";
			div.style.width = "auto";
			div.style.left = "50%";
			div.style.transform = "perspective(1px) translateX(-50%)";
			div.style.top = "540px"; 
		}

		function rePosition() {
			if (titles[0].clientHeight >= 40){
				descs[0].style.top = "20px";
				btns[0].style.top = "540px";
			}
				
		}

	}
