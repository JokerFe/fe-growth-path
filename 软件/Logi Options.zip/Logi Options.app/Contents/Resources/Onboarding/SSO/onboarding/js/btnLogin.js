function btnLogin(){
	writeToLog("btnLogin - start");
	var message =
	{
		command   : 'proceed',
		parameters: null
	};
	
	try
	{
		window.external.NativeOnboarderSendMessage(JSON.stringify(message));
	}

	catch ( exception )
	{
		NativeOnboarder.sendMessage(JSON.stringify(message));
	}
}