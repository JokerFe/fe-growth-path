title0 = "INICIE SESIÓN PARA CREAR UNA COPIA DE SEGURIDAD DE SU CONFIGURACIÓN EN LA NUBE"
desc0 = "Con una sesión iniciada, puede hacer copias de seguridad de su configuración en la nube y mantenerse al día con la información del producto."

btn_continue = "INICIAR SESIÓN O CREAR CUENTA"