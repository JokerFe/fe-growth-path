title0 = "LOGG PÅ FOR Å SIKKERHETSKOPIERE INNSTILLINGENE DINE TIL SKYEN"
desc0 = "Ved å logge på kan du sikkerhetskopiere innstillingene til skyen og holde produktinformasjonen oppdatert."

btn_continue = "LOGG PÅ ELLER OPPRETT KONTO"