title0 = "INICIE SESSÃO PARA CRIAR UMA CÓPIA DE SEGURANÇA DAS SUAS DEFINIÇÕES NA NUVEM"
desc0 = "Ao iniciar sessão, pode criar cópias de segurança das suas definições na nuvem e manter-se actualizado sobre as informações do produto."

btn_continue = "INICIE SESSÃO OU CRIE UMA CONTA"