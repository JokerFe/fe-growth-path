title0 = "ACCEDI AL BACKUP DELLE IMPOSTAZIONI SUL CLOUD"
desc0 = "Effettuando l'accesso, è possibile eseguire il backup delle impostazioni sul cloud e rimanere aggiornati con le informazioni sul prodotto."

btn_continue = "ACCEDI O CREA ACCOUNT"