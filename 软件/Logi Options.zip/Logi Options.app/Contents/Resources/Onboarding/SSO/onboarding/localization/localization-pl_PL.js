title0 = "ZALOGUJ SIĘ, ABY UTWORZYĆ KOPIĘ ZAPASOWĄ USTAWIEŃ W CHMURZE"
desc0 = "Po zalogowaniu się możesz utworzyć kopię zapasową ustawień w chmurze i otrzymywać na bieżąco informacje o produktach."

btn_continue = "ZALOGUJ SIĘ LUB UTWÓRZ KONTO"