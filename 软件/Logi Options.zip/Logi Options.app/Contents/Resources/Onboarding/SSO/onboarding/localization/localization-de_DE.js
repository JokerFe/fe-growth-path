title0 = "EINLOGGEN ZUM SICHERN IHRER EINSTELLUNGEN IN DER CLOUD"
desc0 = "Durch Einloggen können Sie Ihre Einstellungen in der Cloud speichern und alle Produktinformationen auf dem neuesten Stand halten."

btn_continue = "EINLOGGEN ODER KONTO ERSTELLEN"