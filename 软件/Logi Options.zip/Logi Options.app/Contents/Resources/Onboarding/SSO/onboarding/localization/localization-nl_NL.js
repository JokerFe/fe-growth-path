title0 = "AANMELDEN OM EEN BACK-UP VAN UW INSTELLINGEN NAAR DE CLOUD TE MAKEN"
desc0 = "Door u aan te melden, kunt u een back-up van uw instellingen naar de cloud maken en op de hoogte blijven over productinformatie."

btn_continue = "AANMELDEN OF ACCOUNT MAKEN"