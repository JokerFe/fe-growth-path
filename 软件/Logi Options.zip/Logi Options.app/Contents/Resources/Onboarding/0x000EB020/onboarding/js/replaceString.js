function replaceString() {
        writeToLog("replaceString - start");
        /* REPLACE TEXT */

        var btns = document.getElementsByClassName('btn_cancel');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_cancel);
        }

        var btns = document.getElementsByClassName('btn_continue');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_continue);
                setPosition();
        }

        var btns = document.getElementsByClassName('btn_back');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_back);
        }

        var btns = document.getElementsByClassName('error');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], window["error" + i]);
        }

        var btns = document.getElementsByClassName('btn_next');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_next);
        }

        var btns = document.getElementsByClassName('btn_done');
        for (var i = 0; i < btns.length; i++) {

                replaceStr(btns[i], btn_done);
        }

        var btns = document.getElementsByClassName('link_website');
        for (var i = 0; i < btns.length; i++) {

                replaceWebsite(btns[i], link_website);
        }

        var btns = document.getElementsByClassName('link_howToPair');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], link_howToPair);
        }

        var btns = document.getElementsByClassName('btn_howTo');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_howTo);
        }

        var btns = document.getElementsByClassName('btn_enableFlow');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_enableFlow);
        }

        var btns = document.getElementsByClassName('btn_retry');
        for (var i = 0; i < btns.length; i++) {
                replaceStr(btns[i], btn_retry);
        }

        var pointerSpeed1Elements = document.getElementsByClassName('pointerspeed1');
        for (var i = 0; i < pointerSpeed1Elements.length; i++) {
                var element = pointerSpeed1Elements[i];
                var htmlContent = pointerspeed + " 1";
                replaceStr(element, htmlContent);
                if (element.scrollHeight > 25) {
                        element.style.position = "absolute";
                        element.style.top = "-8px";                     
                }
        }

        var pointerSpeed2Elements = document.getElementsByClassName('pointerspeed2');
        for (var i = 0; i < pointerSpeed2Elements.length; i++) {
                var element = pointerSpeed2Elements[i];
                var htmlContent = pointerspeed + " 2";
                replaceStr(element, htmlContent);
                if (element.scrollHeight > 25) {
                        element.style.position = "absolute";
                        element.style.top = "-8px";                     
                }
        }

        replaceTitleAndDesc();

        function replaceTitleAndDesc() {
                writeToLog("replaceTitleAndDesc - start");

                var titles = document.getElementsByClassName('title');
                writeToLog("replaceTitleAndDesc - titles count:" + titles.length);
                for (var i = 0; i < titles.length; i++) {
                        try {
                                writeToLog("replaceTitleAndDesc - titles:" + titles[i].innerHTML + " position:" + i + " window title:" + window["title" + i]);
                                replaceStr(titles[i], window["title" + i]);
                        } catch (error) {
                                writeToLog(error);
                        }
                }

                var descs = document.getElementsByClassName('desc');
                writeToLog("replaceTitleAndDesc - desc count:" + descs.length);
                for (var i = 0; i < descs.length; i++) {
                        try {
                                writeToLog("replaceTitleAndDesc - desc:" + descs[i].innerHTML + " position:" + i + " window desc:" + window["desc" + i]);
                                replaceStr(descs[i], window["desc" + i]);
                        } catch (error) {
                                writeToLog(error);
                        }
                }

                writeToLog("replaceTitleAndDesc - end");
        }

        function replaceStr(className, stringName) {
                try {
                        var newString = stringName.replace("%LogiBrand%", brand).replace("%logibrand%", brand.toLowerCase()).replace("%LOGIBRAND%", brand.toUpperCase());
                        className.innerHTML = newString;
                } catch (error) {
                        writeToLog(error);
                }
        }

        function replaceWebsite(className, stringName) {
                try {
                        var newString = stringName.replace("%logiwebsite%", website);
                        className.innerHTML = newString;
                } catch (error) {
                        writeToLog(error);
                }
        }
	
        function setPosition() {

                /* POSITION BTN X */

                var btns_align = document.getElementsByClassName('center');
                for (var i = 0; i < btns_align.length; i++) {
                        positionX(btns_align[i], "center");
                }

                var btns_align = document.getElementsByClassName('left');
                for (var i = 0; i < btns_align.length; i++) {
                        positionX(btns_align[i], "left");
                }

                var btns_align = document.getElementsByClassName('right');
                for (var i = 0; i < btns_align.length; i++) {
                        positionX(btns_align[i], "right");
                }

                /* POSITION BTN Y */

                var btns_align = document.getElementsByClassName('up');
                for (var i = 0; i < btns_align.length; i++) {
                        positionY(btns_align[i], "up");
                }

                var btns_align = document.getElementsByClassName('down');
                for (var i = 0; i < btns_align.length; i++) {
                        positionY(btns_align[i], "down");
                }
        }

        function positionX(div, positionX) {
                writeToLog("positionX - start");
                var posX;
                div.style.paddingLeft = div.style.paddingRight = "12px";
                div.style.width = "auto";

                if (positionX === "center") {
                        div.parentElement.style.display = "flex";
                        div.parentElement.style.justifyContent = "center";
                        div.style.top = "0px";
                        div.style.webkitTransform = "";
                        div.style.position = "relative";
                } else if (positionX === "left") {
                        posX = 500 - (div.clientWidth) - 10;
                        div.style.transform = "translateX(0px) translateY(0px)";
                        div.style.left = posX + "px";
                } else if (positionX === "right") {
                        posX = 510;
                        div.style.transform = "translateX(0px) translateY(0px)";
                        div.style.left = posX + "px";
                }

        }

        function positionY(div, positionY) {
                writeToLog("positionY - start");
                var posY;

                if (positionY === "up") {
                        posY = 524;
                        div.style.top = posY + "px";
                } else if (positionY === "down") {
                        posY = 560;
                        div.style.top = posY + "px";
                }
        }

        writeToLog("replaceString - end");
}
