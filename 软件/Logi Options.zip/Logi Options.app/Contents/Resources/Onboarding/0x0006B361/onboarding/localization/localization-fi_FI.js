title0 = "TERVETULOA KÄYTTÄMÄÄN MX KEYS:LLE MACille"
desc0 = "Ajattele se. Ota se haltuun."

title1 = "TAUSTAVALAISTUS"
desc1 = "Ympäristön valontunnistin mukautuu taustavalaistukseen, mikä säästää akkua silloin, kun luonnonvaloa on riittävästi. Voit vaihtaa käsin taustavalaistuksen tasoa kahdesta valaistusta näppäimestä."

title2 = "AKUN ILMOITUKSET"
desc2 = "Taustavalot sammuvat, kun akun varaustaso laskee alle 10 prosenttiin. LED-valo vilkkuu tällöin punaisena ja näytöllä näkyy ilmoitus."

title3 = "NÄPPÄIMISTÖN MUKAUTUS"
desc3 = "Näppäimistössä on joitakin oletuspikanäppäimiä, mutta voit määrittää niitä myös itse."

title4 = "EASY SWITCH"
desc4 = "Voit yhdistää jopa kolme laitetta Logitech Unifying- vastaanottimen tai Bluetooth-yhteyden kautta."

title5 = "VALMISTA TULI"
desc5 = "Voit muokata MX Keys Macille -asetuksia milloin tahansa Logitech Options -ohjelmistossa."

appTitle_fallback = "KAIKKI MUUT SOVELLUKSET";

easySwitch0 = "Laite 1"
easySwitch1 = "Laite 2"
easySwitch2 = "Laite 3"

btn_continue = "JATKA";
skip = "OHITA";
btn_continueToSetup = "TAKAISIN OPTIONSIIN";

btn_back = "EDELLINEN";
btn_next = "SEURAAVA";

link_website = "%logiwebsite%"
