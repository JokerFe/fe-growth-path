title0 = "WILLKOMMEN ZU MX KEYS FÜR MAC"
desc0 = "Stellen Sie sich das vor. Beherrschen Sie es."

title1 = "HINTERGRUNDBELEUCHTUNG"
desc1 = "Der Sensor für die Umgebungsbeleuchtung passt die Hintergrundbeleuchtung an, um bei ausreichendem natürlichem Licht Energie zu sparen. Mit den beiden hervorgehobenen Tasten können Sie die Hintergrundbeleuchtung manuell ändern."

title2 = "BENACHRICHTIGUNGEN ZUM AKKULADESTAND"
desc2 = "Die Hintergrundbeleuchtung erlischt, wenn der Ladestand unter 10 % sinkt. Die LED blinkt rot und Sie erhalten eine Benachrichtigung auf dem Bildschirm."

title3 = "TASTEN ANPASSEN"
desc3 = "Wir haben einige Standard-Shortcuts bereitgestellt, Sie können jedoch auch eigene erstellen."

title4 = "EASY SWITCH"
desc4 = "Schließen Sie bis zu 3 Geräte über den Logitech Unifying Empfänger oder Bluetooth an."

title5 = "ALLES FERTIG"
desc5 = "Sie können die Einstellungen für MX Keys für Mac jederzeit in Logitech Options anpassen"

appTitle_fallback = "ALLE ANDEREN ANWENDUNGEN";

easySwitch0 = "Gerät 1"
easySwitch1 = "Gerät 2"
easySwitch2 = "Gerät 3"

btn_continue = "WEITER";
skip = "ÜBERSPRINGEN";
btn_continueToSetup = "ZURÜCK ZU OPTIONS";

btn_back = "ZURÜCK";
btn_next = "WEITER";

link_website = "%logiwebsite%"
