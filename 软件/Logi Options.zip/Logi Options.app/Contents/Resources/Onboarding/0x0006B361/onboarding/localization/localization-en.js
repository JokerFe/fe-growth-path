title0 = "WELCOME TO MX KEYS FOR MAC"
desc0 = "Think it. Master it."

title1 = "BACKLIGHTING"
desc1 = "The ambient light sensor adapts your backlighting level to save power when there is enough natural light. Use the two highlighted keys to manually change the backlighting."

title2 = "BATTERY NOTIFICATIONS"
desc2 = "Backlighting turns off when battery life goes below 10%. The LED will blink red and you'll get an-onscreen notification."

title3 = "CUSTOMIZE KEYS"
desc3 = "We've set some default shortcuts, but you can also create your own."

title4 = "EASY SWITCH"
desc4 = "Connect up to 3 devices using Logitech Unifying receiver or Bluetooth."

title5 = "YOU ARE ALL SET"
desc5 = "You can adjust your MX Keys for Mac settings at any time in Logitech Options"

appTitle_fallback = "ALL OTHER APPLICATIONS";

easySwitch0 = "Device 1"
easySwitch1 = "Device 2"
easySwitch2 = "Device 3"

btn_continue = "CONTINUE";
skip = "SKIP";
btn_continueToSetup = "BACK TO OPTIONS";

btn_back = "BACK";
btn_next = "NEXT";

link_website = "%logiwebsite%"
