title0 = "BEM-VINDO AO MX KEYS PARA MAC"
desc0 = "Pense. Controle."

title1 = "RETROILUMINAÇÃO"
desc1 = "O sensor de luz ambiente adapta o nível da retroiluminação para poupar energia quando existe luz natural suficiente. Utilize as duas teclas realçadas para alterar manualmente a retroiluminação."

title2 = "NOTIFICAÇÕES DE BATERIA"
desc2 = "A retroiluminação desliga-se quando a duração da bateria está abaixo de 10%. O LED pisca a vermelho e receberá uma notificação no ecrã."

title3 = "PERSONALIZAR TECLAS"
desc3 = "Nós predefinimos alguns atalhos, mas também pode criar os seus próprios atalhos."

title4 = "EASY SWITCH"
desc4 = "Ligue até 3 dispositivos utilizando o receptor Logitech Unifying ou o Bluetooth."

title5 = "ESTÁ PRONTO"
desc5 = "Pode ajustar as suas definições do MX Keys para Mac em qualquer momento no Logitech Options"

appTitle_fallback = "TODAS AS OUTRAS APLICAÇÕES";

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUAR";
skip = "IGNORAR";
btn_continueToSetup = "VOLTAR AO OPTIONS";

btn_back = "ANTERIOR";
btn_next = "SEGUINTE";

link_website = "%logiwebsite%"
