title0 = "KLAWIATURA MX KEYS DLA SYSTEMU MAC — ZAPRASZAMY!"
desc0 = "Przemyśl. Opanuj."

title1 = "PODŚWIETLENIE"
desc1 = "Czujnik światła otoczenia dostosowuje poziom podświetlenia, aby oszczędzać energię w warunkach dobrego światła naturalnego. Użyj dwóch podświetlonych klawiszy, aby ręcznie zmienić podświetlenie."

title2 = "POWIADOMIENIA DOTYCZĄCE BATERII"
desc2 = "Podświetlenie wyłącza się, gdy poziom naładowania baterii spada poniżej 10%. Dioda LED zacznie migać na czerwono, a na ekranie zostanie wyświetlone powiadomienie."

title3 = "DOSTOSOWYWANIE KLAWISZY"
desc3 = "Ustawiliśmy kilka domyślnych skrótów, ale możesz także tworzyć własne."

title4 = "EASY SWITCH"
desc4 = "Podłącz maksymalnie 3 urządzenia za pomocą odbiornika Logitech Unifying lub funkcji Bluetooth."

title5 = "WSZYSTKO GOTOWE"
desc5 = "Możesz dostosować ustawienia MX Keys dla systemu Mac w dowolnym momencie w aplikacji Logitech Options"

appTitle_fallback = "WSZYSTKIE INNE APLIKACJE";

easySwitch0 = "Urządzenie 1"
easySwitch1 = "Urządzenie 2"
easySwitch2 = "Urządzenie 3"

btn_continue = "KONTYNUUJ";
skip = "POMIŃ";
btn_continueToSetup = "POWRÓT DO OPROGRAMOWANIA OPTIONS";

btn_back = "WSTECZ";
btn_next = "DALEJ";

link_website = "%logiwebsite%"
