title0 = "BIENVENIDO A MX KEYS PARA MAC"
desc0 = "Piénselo. Domínelo."

title1 = "RETROILUMINACIÓN"
desc1 = "El sensor de luz ambiental adapta el nivel de retroiluminación para ahorrar energía cuando hay suficiente luz natural. Use las dos teclas retroiluminadas para cambiar la retroiluminación manualmente."

title2 = "NOTIFICACIONES DE PILAS"
desc2 = "La retroiluminación se desactiva cuando la carga es inferior al 10%. El LED emitirá destellos rojos y se mostrará una notificación."

title3 = "PERSONALIZAR TECLAS"
desc3 = "Hemos creado accesos directos predeterminados, pero puede crear sus propios accesos directos."

title4 = "EASY SWITCH"
desc4 = "Conecte hasta tres dispositivos usando el receptor Logitech Unifying o Bluetooth."

title5 = "TODO LISTO"
desc5 = "Puede ajustar su configuración de MX Keys para Mac cuando quiera en Logitech Options"

appTitle_fallback = "OTRAS APLICACIONES";

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUAR";
skip = "OMITIR";
btn_continueToSetup = "REGRESAR A OPTIONS";

btn_back = "ATRÁS";
btn_next = "SIGUIENTE";

link_website = "%logiwebsite%"
