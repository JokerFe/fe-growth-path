title0 = "BEM-VINDO AO MX KEYS PARA MAC"
desc0 = "Pense. Domine."

title1 = "LUZ DE FUNDO"
desc1 = "O sensor de luz ambiente adapta o seu nível de luz de fundo para economizar energia quando há luz natural suficiente. Use as duas teclas realçadas para alterar manualmente a luz de fundo."

title2 = "NOTIFICAÇÕES DE BATERIA"
desc2 = "A luz de fundo apaga quando a duração da bateria fica abaixo de 10%. O LED piscará em vermelho e você receberá uma notificação na tela."

title3 = "PERSONALIZAR TECLAS"
desc3 = "Nós definimos alguns atalhos padrão, mas você também pode criar seus próprios atalhos."

title4 = "EASY SWITCH"
desc4 = "Conecte até 3 dispositivos usando o receptor Logitech Unifying ou Bluetooth."

title5 = "VOCÊ ESTÁ PRONTO"
desc5 = "Você pode ajustar suas configurações do MX Keys para Mac a qualquer momento no Logitech Options"

appTitle_fallback = "TODAS OS OUTROS APLICATIVOS";

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUAR";
skip = "IGNORAR";
btn_continueToSetup = "VOLTAR PARA OPTIONS";

btn_back = "VOLTAR";
btn_next = "AVANÇAR";

link_website = "%logiwebsite%"
