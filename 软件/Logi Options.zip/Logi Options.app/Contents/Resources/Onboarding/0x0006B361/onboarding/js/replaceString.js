function replaceString() {

  /* REPLACE TEXT */

  var btns = document.getElementsByClassName('btn_cancel');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_cancel);
  }

  var btns = document.getElementsByClassName('btn_continue');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_continue);
  }
  var skipbutton = document.getElementsByClassName('skip');
  for (var i = 0; i < skipbutton.length; i++) {

    replaceStr(skipbutton[i], skip);
  }
  var btns = document.getElementsByClassName('btn_continueToSetup');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_continueToSetup);
  }

  var btns = document.getElementsByClassName('btn_back');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_back);
  }

  var btns = document.getElementsByClassName('error');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], window["error" + i]);
  }

  var btns = document.getElementsByClassName('btn_next');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_next);
  }

  var btns = document.getElementsByClassName('btn_done');
  for (var i = 0; i < btns.length; i++) {

    replaceStr(btns[i], btn_done);
  }

  var linkWebsite = document.getElementsByClassName('link_website');
  for (var i = 0; i < linkWebsite.length; i++) {

    replaceWebsite(linkWebsite[i], link_website);
  }

  var titles = document.getElementsByClassName('title');
  for (var i = 0; i < titles.length; i++) {
    replaceStr(titles[i], window["title" + i]);
  }

  var descs = document.getElementsByClassName('desc');
  for (var i = 0; i < descs.length; i++) {
    replaceStr(descs[i], window["desc" + i]);
  }

  var easySwitches = document.getElementsByClassName('easySwitch');
  for (var i = 0; i < easySwitches.length; i++) {
    replaceStr(easySwitches[i], window["easySwitch" + i]);
  }

  function replaceStr(className, stringName) {
    var newString = stringName.replace("%LogiBrand%", brand).replace("%logibrand%", brand.toLowerCase()).replace("%LOGIBRAND%", brand.toUpperCase());
    className.innerHTML = newString;

  }

  function replaceWebsite(className, stringName) {
    var newString = stringName.replace("%logiwebsite%", website);
    className.innerHTML = newString;
  }
}
