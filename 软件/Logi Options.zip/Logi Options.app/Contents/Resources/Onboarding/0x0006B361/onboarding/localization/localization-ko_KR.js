title0 = "MAC 용 MX KEYS에 오신 것을 환영합니다"
desc0 = "생각하세요. 마스터하세요."

title1 = "백라이트"
desc1 = "자연광이 충분할 경우, 전원을 절약할 수 있도록 실내 조명 센서가 백라이트 레벨을 조정합니다. 두 개의 강조 표시된 키를 사용해서 수동으로 백라이트를 변경하십시오."

title2 = "배터리 알림"
desc2 = "배터리 수명이 10% 미만일 때 백라이트를 끕니다. LED가 빨간색으로 깜박이고 화면에 알림이 표시됩니다."

title3 = "키 사용자 지정"
desc3 = "몇몇 기본적인 단축키가 설정되어 있으나, 사용자가 원하는 대로 단축키를 구성할 수 있습니다."

title4 = "EASY SWITCH"
desc4 = "Logitech Unifying 수신기 또는 Bluetooth를 사용해서 최대 3대의 장치에 연결할 수 있습니다."

title5 = "만반의 준비가 되었습니다."
desc5 = "언제든지 Logitech Options에서Mac 용 MX Keys의 설정을 조정할 수 있습니다."

appTitle_fallback = "다른 모든 애플리케이션";

easySwitch0 = "장치 1"
easySwitch1 = "장치 2"
easySwitch2 = "장치 3"

btn_continue = "계속";
skip = "건너뛰기";
btn_continueToSetup = "OPTIONS 이동";

btn_back = "뒤로";
btn_next = "다음";

link_website = "%logiwebsite%"
