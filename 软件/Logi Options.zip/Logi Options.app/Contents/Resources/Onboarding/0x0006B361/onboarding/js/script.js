var screenNb = 0,
  customKeyIncr = 0,
  fnIncr = 0,
  slides;
var customKeyArray = [];
var batteryInterval = true,
  customKeyInterval = true,
  fnLockInterval = true;
var start;
var mainOverlay,
  functionDescription;

window.onload = function() {
  document.addEventListener('contextmenu', event => event.preventDefault());
  slides = document.getElementsByClassName('screens');
  mainOverlay = document.getElementsByClassName("mainOverlay");
  functionDescription = document.getElementsByClassName('functionDescription');

  var keyboardImg = document.getElementsByClassName("keyboardImg");
  var keyboardParam = (query('keyboard') != null)
    ? (query('keyboard').toLowerCase())
    : "0x0006B023_0x0000";
  var keyboardExtendedID = keyboardParam.split('_');
  var keyboardColor = (keyboardExtendedID.length == 2)
    ? (keyboardExtendedID[1][keyboardExtendedID[1].length - 1])
    : "0";
  for (var i = 0; i < keyboardImg.length; i++) {
    var path = "resources/productImg/" + keyboardColor + "/01.png";
    keyboardImg[i].src = path;
  }
  var os = (query('os') != null)
    ? (query('os').toLowerCase())
    : "windows";

  replaceString();
  slideMove(0);

  for (var i = 0; i < slides.length - 2; i++) { //-2 instead of 1 becasue of direct jump to Options
    let dot = document.createElement("div");
    dot.id = i;
    dot.onclick = function() {
      jumpto(parseInt(this.id) + 1);
    }
    document.getElementById("caroussel").appendChild(dot);
  }

  start = true;
  setTimeout(function() {
    document.getElementById("screen0").classList.add("fadeIn");
    document.getElementById("screen0").getElementsByClassName("keyboardImg")[0].style.top = "134px";
    document.getElementById("customKeyBlock").innerHTML = customKeyArray[0];
  }, 500);
  document.getElementById("movingKb").addEventListener("transitionend", kBMoved, false);
};

function slideMove(e) {
  var movingKbPos = [
    0,
    446,
    -447,
    447,
    -448,
    -1500
  ];
  //var movingKbPos = [0, 447, -447, 447, 447, -447, -1200];
  screenNb += e;
  let caroussel = document.getElementById("caroussel");
  for (var i = 0; i < mainOverlay.length; i++) {
    mainOverlay[i].classList.remove("fadeIn");
  }

  if (screenNb > 0 && screenNb <= 4) {
    document.getElementById("movingKb").style.left = movingKbPos[screenNb].toString() + "px";
    document.getElementById("movingKb").classList.add("fadeIn");
    mainOverlay[screenNb - 1].style.display = "block";

    for (var i = 0; i < caroussel.children.length; i++) {
      caroussel.children[i].classList.remove("activeDot");
    }
    caroussel.children[screenNb - 1].classList.add("activeDot");
  }

  //remove navigation
  if (screenNb >= 5 || screenNb <= 0) {
    caroussel.style.display = "none";
    document.getElementById("back").style.display = "none";
    document.getElementById("next").style.display = "none";
  } else {
    caroussel.style.display = "flex";
    //remove back on first page
    if (screenNb != 1) {
      document.getElementById("back").style.display = "block";
    } else {
      document.getElementById("back").style.display = "none";
    }
    document.getElementById("next").style.display = "block";
  }

  if (screenNb >= 5) {
    document.getElementById("movingKb").style.left = movingKbPos[movingKbPos.length - 1] + "px";
    document.getElementById("skipbutton").style.display = "none";
  } else {
    document.getElementById("skipbutton").style.display = "block";
  }

  var id = 'screen' + (
  screenNb).toString();
  var displaySlide = document.getElementById(id);

  for (var i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  for (var i = 0; i < functionDescription.length; i++) {
    functionDescription[i].classList.remove("fadeIn");
  }
  displaySlide.style.display = 'block';
}

function kBMoved() {
  console.log(start);

  if (screenNb < 5) {
    mainOverlay[screenNb - 1].classList.add("fadeIn");
    if (screenNb > 0) {
      document.getElementById("screen" + screenNb.toString()).getElementsByClassName("functionDescription")[0].classList.toggle("fadeIn");
    }
  } else {
    document.getElementById("movingKb").classList.remove("fadeIn");
    document.getElementById("screen5").classList.add("fadeIn");
  }
  if (screenNb == 1) {
    start = false;
  }
  //backlightAlert
  if (screenNb == 2) {
    if (batteryInterval) {
      batteryInterval = window.setInterval(batteryLed, 1750);
    }
  }

  if (screenNb != 2 && !start) {
    window.clearInterval(batteryInterval);
    var el = document.getElementById("screen2").getElementsByClassName("overlays");

    for (var i = 0; i < el.length; i++) {
      el[i].classList.remove("fadeIn");
      el[i].classList.add("dryStop");
    }
  }
}

function batteryLed() {
  var el = document.getElementById('screen2').getElementsByClassName('overlays');
  el[1].classList.toggle("fadeIn");
  el[1].classList.remove("dryStop");
}

// ----------------------------------------------------------------------------------------
function jumpto(slide) {
  screenNb = slide;
  slideMove(0);
}

function iconSelected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRightSelected.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeftSelected.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/closeSelected.png";
  }
}

function iconDeselected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRight.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeft.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/close.png";
  }
}
