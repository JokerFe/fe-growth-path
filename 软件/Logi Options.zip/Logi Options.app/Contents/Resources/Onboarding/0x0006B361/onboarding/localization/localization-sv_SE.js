title0 = "VÄLKOMMEN TILL MX KEYS FÖR MAC"
desc0 = "Tänk det. Bemästra det."

title1 = "BAKGRUNDSBELYSNING"
desc1 = "En sensor känner av det omgivande ljuset och anpassar bakgrundsbelysningsnivån för att spara ström när det finns tillräckligt med naturligt ljus. Använd de två markerade knapparna för att ändra bakgrundsbelysningen manuellt."

title2 = "BATTERIMEDDELANDEN"
desc2 = "Bakgrundsbelysningen stängs av när batteritiden är lägre än 10 %. Indikatorlampan blinkar rött och du får ett meddelande på skärmen."

title3 = "ANPASSA KNAPPAR"
desc3 = "Vi har ställt in några standardgenvägar, men du kan också skapa egna."

title4 = "EASY SWITCH"
desc4 = "Anslut upp till tre enheter med Logitech Unifying-mottagare eller Bluetooth."

title5 = "DET ÄR KLART"
desc5 = "Du kan när som helst justera MX Keys för Mac-inställningarna i Logitech Options"

appTitle_fallback = "ALLA ANDRA APPLIKATIONER";

easySwitch0 = "Enhet 1"
easySwitch1 = "Enhet 2"
easySwitch2 = "Enhet 3"

btn_continue = "FORTSÄTT";
skip = "HOPPA ÖVER";
btn_continueToSetup = "TILLBAKA TILL OPTIONS";

btn_back = "TILLBAKA";
btn_next = "NÄSTA";

link_website = "%logiwebsite%"
