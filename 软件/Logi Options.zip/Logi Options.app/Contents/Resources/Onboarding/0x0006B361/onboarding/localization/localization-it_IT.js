title0 = "BENVENUTO IN MX KEYS PER MAC"
desc0 = "Pensa. Domina."

title1 = "RETROILLUMINAZIONE"
desc1 = "Il sensore di luce ambientale adatta il livello della retroilluminazione per risparmiare energia quando la luce naturale è sufficiente. Utilizza i due tasti evidenziati per modificare manualmente la retroilluminazione."

title2 = "NOTIFICHE SULLA BATTERIA"
desc2 = "La retroilluminazione si spegne quando la carica della batteria scende al di sotto del 10%. Il LED lampeggerà in rosso e riceverai una notifica sullo schermo."

title3 = "PERSONALIZZAZIONE TASTI"
desc3 = "Abbiamo impostato alcuni collegamenti predefiniti, ma puoi anche crearne di tuoi."

title4 = "EASY SWITCH"
desc4 = "Connetti fino a 3 dispositivi utilizzando il ricevitore Logitech Unifying o il Bluetooth."

title5 = "È TUTTO PRONTO"
desc5 = "Puoi modificare le impostazioni di MX Keys per Mac in qualsiasi momento in Logitech Options"

appTitle_fallback = "TUTTE LE ALTRE APPLICAZIONI";

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUA";
skip = "IGNORA";
btn_continueToSetup = "TORNA A OPTIONS";

btn_back = "INDIETRO";
btn_next = "AVANTI";

link_website = "%logiwebsite%"
