title0 = "WELKOM BIJ MX KEYS VOOR MAC"
desc0 = "Bedenkt het. Beheers het."

title1 = "VERLICHTING"
desc1 = "De sensor voor omgevingslicht past het verlichtingsniveau aan om energie te besparen wanneer er voldoende natuurlijk licht is. Gebruik de twee verlichte toetsen om de verlichting handmatig aan te passen."

title2 = "BATTERIJMELDINGEN"
desc2 = "Verlichting wordt uitgeschakeld wanneer het batterijvermogen lager is dan 10%. De led knippert rood en je krijgt een melding op het scherm."

title3 = "TOETSEN AANPASSEN"
desc3 = "We hebben enkele standaard snelkoppelingen ingesteld, maar je kunt ze ook zelf kiezen."

title4 = "EASY SWITCH"
desc4 = "Verbind maximaal 3 apparaten met een Logitech Unifying-ontvanger of Bluetooth."

title5 = "U KUNT AAN DE SLAG"
desc5 = "Je kunt je MX Keys voor Mac-instellingen op elk moment aanpassen met Logitech Options"

appTitle_fallback = "ALLE ANDERE TOEPASSINGEN";

easySwitch0 = "Apparaat 1"
easySwitch1 = "Apparaat 2"
easySwitch2 = "Apparaat 3"

btn_continue = "DOORGAAN";
skip = "OVERSLAAN";
btn_continueToSetup = "TERUG NAAR OPTIONS";

btn_back = "VORIGE";
btn_next = "VOLGENDE";

link_website = "%logiwebsite%"
