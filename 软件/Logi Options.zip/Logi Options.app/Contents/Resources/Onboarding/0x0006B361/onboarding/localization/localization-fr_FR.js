title0 = "BIENVENUE DANS MX KEYS POUR MAC"
desc0 = "Adoptez-la. Maîtrisez-la."

title1 = "RÉTROÉCLAIRAGE"
desc1 = "Le capteur de lumière ambiante adapte votre niveau de rétroéclairage pour économiser de l'énergie lorsque vous disposez de suffisamment de lumière naturelle. Utilisez les deux touches rétroéclairées pour modifier manuellement le rétroéclairage."

title2 = "NOTIFICATIONS DE BATTERIE"
desc2 = "Le rétroéclairage se désactive lorsque la longévité de la batterie passe en dessous de 10%. Le témoin lumineux clignote en rouge et vous recevez une notification à l'écran."

title3 = "PERSONNALISER LES TOUCHES"
desc3 = "Nous avons défini des raccourcis par défaut mais vous pouvez également créer les vôtres."

title4 = "EASY SWITCH"
desc4 = "Connectez jusqu'à 3 dispositifs avec le récepteur Logitech Unifying ou via Bluetooth."

title5 = "VOUS ÊTES PRÊT"
desc5 = "Vous pouvez régler les paramètres de MX Keys pour Mac à tout moment dans Logitech Options"

appTitle_fallback = "TOUTES LES AUTRES APPLICATIONS";

easySwitch0 = "Dispositif 1"
easySwitch1 = "Dispositif 2"
easySwitch2 = "Dispositif 3"

btn_continue = "CONTINUER";
skip = "IGNORER";
btn_continueToSetup = "REVENIR DANS OPTIONS";

btn_back = "PRÉCÉDENT";
btn_next = "SUIVANT";

link_website = "%logiwebsite%"
