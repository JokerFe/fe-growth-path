title0 = "VELKOMMEN TIL MX KEYS FOR MAC"
desc0 = "Tænk det. Brug det."

title1 = "BAGBELYSNING"
desc1 = "Sensoren for det omgivende lys tilpasser dit bagbelysningsniveau for at spare strøm, når der er nok naturligt lys. Brug de to fremhævede taster til manuelt at ændre bagbelysningen."

title2 = "BATTERIINFORMATION"
desc2 = "Bagbelysning slukkes, når batterilevetiden kommer under 10 %. LED-indikatoren blinker rødt og der vises en meddelelse på skærmen."

title3 = "TILPAS TASTER"
desc3 = "Vi har konfigureret nogle standardgenveje, men du kan også oprette dine egne."

title4 = "EASY SWITCH"
desc4 = "Tilslut op til 3 enheder ved hjælp af en Logitech Unifying-modtager eller Bluetooth."

title5 = "DU ER NU HELT KLAR"
desc5 = "Du kan når som helst tilpasse indstillingerne for MX Keys for Mac i Logitech Options"

appTitle_fallback = "ALLE ANDRE APPS";

easySwitch0 = "Enhed 1"
easySwitch1 = "Enhed 2"
easySwitch2 = "Enhed 3"

btn_continue = "FORTSÆT";
skip = "SPRING OVER";
btn_continueToSetup = "TILBAGE TIL OPTIONS";

btn_back = "TILBAGE";
btn_next = "NÆSTE";

link_website = "%logiwebsite%"
