title0 = "ERGO K860 へようこそ"
desc0 = "快適性を高めましょう。"

title1 = "キーをカスタマイズ"
desc1 = "お好きにキーをカスタマイズ。"

title2 = "F キーを設定する"
desc2 = "Fnロックを押して、いつでもメディアキーと Fn キーの間で切り替えることができます。"

title3 = "EASY SWITCH"
desc3 = "Logicool Unifying レシーバーまたは <span class=italic>Bluetooth</span> を使用して、最大 3 台のデバイスを接続。"

title4 = "準備が完了しました"
desc4 = "Logicool Options で ERGO K860 の設定をいつでも調整することができます。"

easySwitch0 = "デバイス 1"
easySwitch1 = "デバイス 2"
easySwitch2 = "デバイス 3"

btn_continue = "続行";
skip = "スキップ";
btn_continueToSetup = "OPTIONS に戻る";
subdesc = "<a href=http://www.ergosetup.logi.com>ここをクリック</a>して、ワークステーションのセットアップ方法の詳細を確認してください。";

btn_back = "戻る";
btn_next = "次へ";

link_website = "%logiwebsite%"
