title0 = "Welkom bij ERGO K860"
desc0 = "Laten we ons comfortabel voelen."

title1 = "Toetsen aanpassen"
desc1 = "Pas de toetsen aan zodat ze zich op de gewenste manier gedragen."

title2 = "F-toetsen instellen"
desc2 = "Schakel op elk moment tussen media- en Fn-toetsen door op Fn Lock te drukken."

title3 = "EASY SWITCH"
desc3 = "Verbind maximaal 3 apparaten met een Logitech Unifying-ontvanger of <span class=italic>Bluetooth</span>."

title4 = "U KUNT AAN DE SLAG"
desc4 = "Je kunt je ERGO K860-instellingen op elk moment aanpassen met Logitech Options"

easySwitch0 = "Apparaat 1"
easySwitch1 = "Apparaat 2"
easySwitch2 = "Apparaat 3"

btn_continue = "DOORGAAN";
skip = "OVERSLAAN";
btn_continueToSetup = "TERUG NAAR OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Klik hier</a> voor meer informatie over het instellen van uw werkstation.";

btn_back = "VORIGE";
btn_next = "VOLGENDE";

link_website = "%logiwebsite%"
