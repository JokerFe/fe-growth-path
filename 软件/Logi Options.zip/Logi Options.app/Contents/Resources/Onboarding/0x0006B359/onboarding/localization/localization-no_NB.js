title0 = "Velkommen til ERGO K860"
desc0 = "La oss bli komfortable."

title1 = "Tilpass taster"
desc1 = "Tilpass taster slik at de oppfører seg på ønsket måte."

title2 = "Tilordne F-taster"
desc2 = "Bytt mellom medie- og Fn-taster når som helst ved å trykke på Fn-lås."

title3 = "EASY SWITCH"
desc3 = "Koble til opptil 3 enheter ved å bruke Logitech Unifying-mottakeren eller <span class=italic>Bluetooth</span>."

title4 = "DU ER KLAR TIL Å SETTE I GANG"
desc4 = "Du kan når som helst justere innstillingene for ERGO K860 i Logitech Options."

easySwitch0 = "Enhet 1"
easySwitch1 = "Enhet 2"
easySwitch2 = "Enhet 3"

btn_continue = "FORTSETT";
skip = "HOPP OVER";
btn_continueToSetup = "TILBAKE TIL OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Klikk her</a> for å lære mer om hvordan du konfigurerer arbeidsstasjonen.";

btn_back = "TILBAKE";
btn_next = "NESTE";

link_website = "%logiwebsite%"
