title0 = "Willkommen zu ERGO K860"
desc0 = "Machen wir es uns gemütlich."

title1 = "Tasten anpassen"
desc1 = "Passen Sie die Tasten so an, dass sie sich wie gewünscht verhalten."

title2 = "F-Tasten festlegen"
desc2 = "Durch Drücken von Fn-Sperre können Sie jederzeit zwischen Multimedia- und Funktionstasten wechseln."

title3 = "EASY SWITCH"
desc3 = "Schließen Sie bis zu 3 Geräte über den Logitech Unifying Empfänger oder <span class=italic>Bluetooth</span> an."

title4 = "ALLES FERTIG"
desc4 = "Sie können die Einstellungen für ERGO K860 jederzeit in Logitech Options anpassen"

easySwitch0 = "Gerät 1"
easySwitch1 = "Gerät 2"
easySwitch2 = "Gerät 3"

btn_continue = "WEITER";
skip = "ÜBERSPRINGEN";
btn_continueToSetup = "ZURÜCK ZU OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Klicken Sie hier</a>, um weitere Informationen zum Einrichten Ihrer Workstation zu erhalten.";

btn_back = "ZURÜCK";
btn_next = "WEITER";

link_website = "%logiwebsite%"
