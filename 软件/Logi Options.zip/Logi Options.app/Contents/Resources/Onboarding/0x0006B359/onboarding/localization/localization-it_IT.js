title0 = "Benvenuto in ERGO K860"
desc0 = "Mettiamoci comodi."

title1 = "Personalizzazione tasti"
desc1 = "Personalizza i tasti in modo che si comportino nel modo desiderato."

title2 = "Imposta i tasti funzione"
desc2 = "Passa dai tasti multimediali ai tasti Fn in qualsiasi momento premendo Blocco Fn."

title3 = "EASY SWITCH"
desc3 = "Connetti fino a 3 dispositivi utilizzando il ricevitore Logitech Unifying o il <span class=italic>Bluetooth</span>."

title4 = "È TUTTO PRONTO"
desc4 = "Puoi modificare le impostazioni di ERGO K860 in qualsiasi momento in Logitech Options"

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUA";
skip = "IGNORA";
btn_continueToSetup = "TORNA A OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Fai clic qui</a> per saperne di più su come configurare la tua postazione di lavoro.";

btn_back = "INDIETRO";
btn_next = "AVANTI";

link_website = "%logiwebsite%"
