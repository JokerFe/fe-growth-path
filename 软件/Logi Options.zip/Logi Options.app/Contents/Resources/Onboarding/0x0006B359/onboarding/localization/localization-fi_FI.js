title0 = "Tervetuloa ERGO K860in käyttäjäksi"
desc0 = "Mennään mukavasti."

title1 = "Näppäimistön mukautus"
desc1 = "Mukauta näppäimiä, jotta ne käyttäytyvät halutulla tavalla."

title2 = "F-näppäinten määritys"
desc2 = "Voit vaihtaa median ja Fn-näppäinten välillä milloin vain painamalla Fn Lock."

title3 = "EASY SWITCH"
desc3 = "Voit yhdistää jopa kolme laitetta Logitech Unifying- vastaanottimen tai <span class=italic>Bluetooth</span>-yhteyden kautta."

title4 = "VALMISTA TULI"
desc4 = "Voit muokata ERGO K860 -asetuksia milloin tahansa Logitech Options -ohjelmistossa."

easySwitch0 = "Laite 1"
easySwitch1 = "Laite 2"
easySwitch2 = "Laite 3"

btn_continue = "JATKA";
skip = "OHITA";
btn_continueToSetup = "TAKAISIN OPTIONSIIN";
subdesc = "<a href=http://www.ergosetup.logi.com>Napsauta tätä</a> saadaksesi lisätietoja työaseman määrittämisestä.";

btn_back = "EDELLINEN";
btn_next = "SEURAAVA";

link_website = "%logiwebsite%"
