title0 = "欢迎使用 ERGO K860"
desc0 = "轻松使用，舒适快捷。"

title1 = "自定义按键"
desc1 = "自定义按键实现随心的快捷操作。"

title2 = "设置 F 键"
desc2 = "只需按下 Fn 锁定，即可在媒体控制和 Fn 键之间轻松切换。"

title3 = "EASY SWITCH"
desc3 = "使用 Logitech Unifying™ 优联接收器或<span class=italic>蓝牙</span>，连接多达 3 个设备。"

title4 = "您已准备就绪"
desc4 = "您可以随时在 Logitech Options 中调节 ERGO K860 的设置"

easySwitch0 = "设备 1"
easySwitch1 = "设备 2"
easySwitch2 = "设备 3"

btn_continue = "继续";
skip = "跳过";
btn_continueToSetup = "回到 OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>点击此处</a>了解更多关于如何设置您的专属工作站的详细信息。";

btn_back = "返回";
btn_next = "下一步";

link_website = "%logiwebsite%"
