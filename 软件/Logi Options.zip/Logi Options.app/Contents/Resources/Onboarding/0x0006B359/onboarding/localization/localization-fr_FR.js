title0 = "Bienvenue dans ERGO K860"
desc0 = "Soyons à l'aise."

title1 = "Personnaliser les touches"
desc1 = "Personnalisez les touches pour qu'elles se comportent de la manière souhaitée."

title2 = "Définissez vos touches F"
desc2 = "Basculez entre les touches multimédia et les touches Fn à tout moment en appuyant sur Verrouillage Fn."

title3 = "EASY SWITCH"
desc3 = "Connectez jusqu'à 3 dispositifs avec le récepteur Logitech Unifying ou via <span class=italic>Bluetooth</span>."

title4 = "VOUS ÊTES PRÊT"
desc4 = "Vous pouvez régler les paramètres d'ERGO K860 à tout moment dans Logitech Options"

easySwitch0 = "Dispositif 1"
easySwitch1 = "Dispositif 2"
easySwitch2 = "Dispositif 3"

btn_continue = "CONTINUER";
skip = "IGNORER";
btn_continueToSetup = "REVENIR DANS OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Cliquez ici</a> pour en savoir plus sur la configuration de votre poste de travail.";

btn_back = "PRÉCÉDENT";
btn_next = "SUIVANT";

link_website = "%logiwebsite%"
