title0 = "Welcome to ERGO K860"
desc0 = "Let's get comfortable."

title1 = "Customize keys"
desc1 = "Customize keys to behave just the way you like it."

title2 = "Set your F-keys"
desc2 = "Switch between media & Fn keys simply by pressing Fn Lock."

title3 = "EASY SWITCH"
desc3 = 'Connect up to 3 devices using a Logitech Unifying receiver or <span class="italic"> Bluetooth</span>.'

title4 = "YOU ARE ALL SET"
desc4 = "You can adjust your ERGO K860 settings at any time in Logitech Options"

easySwitch0 = "Device 1"
easySwitch1 = "Device 2"
easySwitch2 = "Device 3"

btn_continue = "CONTINUE";
skip = "SKIP";
btn_continueToSetup = "BACK TO OPTIONS";
subdesc = '<a href="http://www.ergosetup.logi.com">Click here</a> to learn more about how to setup your work station.';

btn_back = "BACK";
btn_next = "NEXT";

link_website = "%logiwebsite%"
