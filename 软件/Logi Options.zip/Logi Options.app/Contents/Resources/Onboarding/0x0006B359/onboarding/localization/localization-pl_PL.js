title0 = "Klawiatura ERGO K860 — zapraszamy!"
desc0 = "Wygoda, na którą zasługujesz."

title1 = "Dostosowywanie klawiszy"
desc1 = "Dostosuj klawisze, aby działały dokładnie tak, jak lubisz."

title2 = "Ustawianie funkcji klawiszy funkcyjnych"
desc2 = "Przełączaj się między sterowaniem multimediami a funkcjami przypisanymi do klawiszy funkcyjnych w dowolnym momencie, naciskając klawisze Fn Lock."

title3 = "EASY SWITCH"
desc3 = "Podłącz maksymalnie 3 urządzenia za pomocą odbiornika Logitech Unifying lub funkcji <span class=italic> Bluetooth</span>."

title4 = "WSZYSTKO GOTOWE"
desc4 = "Możesz dostosować ustawienia ERGO K860 w dowolnym momencie w aplikacji Logitech Options"

easySwitch0 = "Urządzenie 1"
easySwitch1 = "Urządzenie 2"
easySwitch2 = "Urządzenie 3"

btn_continue = "KONTYNUUJ";
skip = "POMIŃ";
btn_continueToSetup = "POWRÓT DO OPROGRAMOWANIA OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Kliknij tutaj</a>, aby uzyskać więcej informacji na temat konfigurowania stacji roboczej.";

btn_back = "WSTECZ";
btn_next = "DALEJ";

link_website = "%logiwebsite%"
