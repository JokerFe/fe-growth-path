title0 = "Καλως ορισατε στο ERGO K860"
desc0 = "Εργαστείτε με άνεση."

title1 = "Προσαρμογη πληκτρων"
desc1 = "Προσαρμόστε τα πλήκτρα για να συμπεριφέρονται όπως ακριβώς σας αρέσει."

title2 = "Ρυθμιση πληκτρων F"
desc2 = "Κάντε εναλλαγή μεταξύ των πλήκτρων πολυμέσων και των πλήκτρων Fn ανά πάσα στιγμή, πιέζοντας Κλείδωμα Fn."

title3 = "EASY SWITCH"
desc3 = "Συνδέστε έως και 3 συσκευές χρησιμοποιώντας τον δέκτη Logitech Unifying ή το <span class=italic> Bluetooth</span>."

title4 = "ΕΙΣΤΕ ΕΤΟΙΜΟΙ"
desc4 = "Μπορείτε να προσαρμόσετε τις ρυθμίσεις ERGO K860 ανά πάσα στιγμή στο Logitech Options"

easySwitch0 = "Συσκευή 1"
easySwitch1 = "Συσκευή 2"
easySwitch2 = "Συσκευή 3"

btn_continue = "ΣΥΝΕΧΕΙΑ";
skip = "ΠΑΡΑΛΕΙΨΗ";
btn_continueToSetup = "ΕΠΙΣΤΡΟΦΗ ΣΕ OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Κάντε κλικ εδώ</a> για να μάθετε περισσότερα σχετικά με το πώς μπορείτε να ρυθμίσετε σταθμό εργασίας σας.";

btn_back = "ΠΙΣΩ";
btn_next = "ΕΠΟΜΕΝΟ";

link_website = "%logiwebsite%"
