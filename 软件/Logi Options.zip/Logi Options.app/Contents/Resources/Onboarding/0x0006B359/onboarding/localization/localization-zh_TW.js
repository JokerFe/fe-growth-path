title0 = "歡迎使用 ERGO K860"
desc0 = "讓我們更加舒適的工作。"

title1 = "自訂按鍵"
desc1 = "依照您喜歡的方式自訂按鍵。"

title2 = "設定您的 F 功能鍵"
desc2 = "按下 Fn 鎖定可隨時切換媒體與 Fn 按鍵。"

title3 = "EASY SWITCH"
desc3 = "使用羅技 Unifying 接收器或<span class=italic>藍牙</span>功能最多可連線到 3 個裝置。"

title4 = "您已完成所有工作"
desc4 = "您可以在 Logitech Options 中隨時調整您 ERGO K860 的設定"

easySwitch0 = "裝置 1"
easySwitch1 = "裝置 2"
easySwitch2 = "裝置 3"

btn_continue = "繼續";
skip = "跳過";
btn_continueToSetup = "回到 OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>按一下這裡</a>可瞭解更多關於如何設定您工作站的資訊。";

btn_back = "上一頁";
btn_next = "下一頁";

link_website = "%logiwebsite%"
