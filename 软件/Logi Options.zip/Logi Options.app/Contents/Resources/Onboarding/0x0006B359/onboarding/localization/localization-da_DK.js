title0 = "Velkommen til ERGO K860"
desc0 = "Lad os blive behagelige."

title1 = "Tilpas taster"
desc1 = "Tilpas taster, så de opfører sig på den ønskede måde."

title2 = "Konfigurer dine F-taster"
desc2 = "Skift mellem medie- og Fn-taster når som helst ved at trykke på Fn-lås."

title3 = "EASY SWITCH"
desc3 = "Tilslut op til 3 enheder ved hjælp af en Logitech Unifying-modtager eller <span class=italic>Bluetooth</span>."

title4 = "DU ER NU HELT KLAR"
desc4 = "Du kan når som helst tilpasse indstillingerne for ERGO K860 i Logitech Options"

easySwitch0 = "Enhed 1"
easySwitch1 = "Enhed 2"
easySwitch2 = "Enhed 3"

btn_continue = "FORTSÆT";
skip = "SPRING OVER";
btn_continueToSetup = "TILBAGE TIL OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Klik her</a> for at lære mere om, hvordan du opsætter din arbejdsstation.";

btn_back = "TILBAGE";
btn_next = "NÆSTE";

link_website = "%logiwebsite%"
