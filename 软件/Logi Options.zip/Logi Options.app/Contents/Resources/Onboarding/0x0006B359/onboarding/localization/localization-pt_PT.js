title0 = "Bem-vindo ao ERGO K860"
desc0 = "Vamos ficar confortável."

title1 = "Personalizar teclas"
desc1 = "Personalize as teclas para que se comportem da maneira desejada."

title2 = "Configure as suas teclas F"
desc2 = "Alterne entre teclas multimédia e teclas Fn em qualquer momento premindo Fn Lock."

title3 = "EASY SWITCH"
desc3 = "Ligue até 3 dispositivos utilizando o receptor Logitech Unifying ou o <span class=italic>Bluetooth</span>."

title4 = "ESTÁ PRONTO"
desc4 = "Pode ajustar as suas definições do ERGO K860 em qualquer momento no Logitech Options"

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUAR";
skip = "IGNORAR";
btn_continueToSetup = "VOLTAR AO OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Clique aqui</a> para saber mais sobre como configurar a sua estação de trabalho.";

btn_back = "ANTERIOR";
btn_next = "SEGUINTE";

link_website = "%logiwebsite%"
