title0 = "ERGO K860에 오신 것을 환영합니다"
desc0 = "편안함을 누리세요."

title1 = "키 사용자 지정"
desc1 = "선호하는 방식으로 작동하도록 키를 원하는 대로 맞춤 설정하십시오."

title2 = "F-키 설정"
desc2 = "Fn 잠금를 눌러 언제든지 미디어와 Fn 키를 전환할 수 있습니다."

title3 = "EASY SWITCH"
desc3 = "Logitech Unifying 수신기 또는 <span class=italic>Bluetooth</span>를 사용해서 최대 3대의 장치에 연결할 수 있습니다."

title4 = "만반의 준비가 되었습니다."
desc4 = "언제든지 Logitech Options에서ERGO K860의 설정을 조정할 수 있습니다."

easySwitch0 = "장치 1"
easySwitch1 = "장치 2"
easySwitch2 = "장치 3"

btn_continue = "계속";
skip = "건너뛰기";
btn_continueToSetup = "OPTIONS 이동";
subdesc = "워크스테이션 설정 방법에 대해 자세히 알아보려면 <a href=http://www.ergosetup.logi.com>여기를 클릭</a>하십시오.";

btn_back = "뒤로";
btn_next = "다음";

link_website = "%logiwebsite%"
