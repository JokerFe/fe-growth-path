var screenNb = 0,
  customKeyIncr = 0,
  fnIncr = 0;
var customKeyArray = [];
var batteryInterval = true,
  customKeyInterval = true,
  fnLockInterval = true;
var start;
var mainOverlay,
  functionDescription;

window.onload = function() {
  mainOverlay = document.getElementsByClassName("mainOverlay");
  functionDescription = document.getElementsByClassName('functionDescription');

  var stillKb = document.getElementsByClassName("stillKb");
  var keyboardParam = (query('keyboard') != null)
    ? (query('keyboard').toLowerCase())
    : "0x0006B023_0x0000";
  var keyboardExtendedID = keyboardParam.split('_');
  var keyboardColor = (keyboardExtendedID.length == 2)
    ? (keyboardExtendedID[1][keyboardExtendedID[1].length - 1])
    : "0";
  for (var i = 0; i < stillKb.length; i++) {
    let path = "resources/productImg/" + keyboardColor + "/02.png";
    stillKb[i].src = path;
  }
  document.getElementById("movingKb").src = "resources/productImg/" + keyboardColor + "/02.png";
  var os = (query('os') != null)
    ? (query('os').toLowerCase())
    : "windows";
  replaceString();
  slideMove(0);

  start = true;
  setTimeout(function() {
    document.getElementById("screen0").classList.add("fadeIn");
    document.getElementById("screen0").getElementsByClassName("stillKb")[0].style.opacity = 1;
  }, 500);
  document.getElementById("movingKb").addEventListener("transitionend", kBMoved, false);
};

function slideMove(e) {
  var movingKbPos = [0, 452, 398, -423, -1000];
  screenNb += e;
  var slides = document.getElementsByClassName('screens');
  var caroussel = document.getElementById("caroussel");
  for (var i = 0; i < mainOverlay.length; i++) {
    mainOverlay[i].classList.remove("fadeIn");
  }

  if (screenNb > 0 && screenNb <= 3) {
    document.getElementById("movingKb").style.left = movingKbPos[screenNb].toString() + "px";
    document.getElementById("movingKb").classList.add("fadeIn");
    mainOverlay[screenNb - 1].style.display = "block";
    caroussel.children[0].src = "resources/icons/caroussel/0" + screenNb.toString() + ".png";
  }
  if (screenNb == 4) {
    setTimeout(function() {
      document.getElementById("screen4").getElementsByClassName("stillKb")[0].classList.add("fadeIn");

      document.getElementById("screen4").classList.add("fadeIn");
    }, 250);
  }

  //remove navigation
  if (screenNb >= 4 || screenNb <= 0) {
    caroussel.style.display = "none";
    document.getElementById("back").style.display = "none";
    document.getElementById("next").style.display = "none";
  } else {
    caroussel.style.display = "block";
    //remove back on first page
    if (screenNb != 1) {
      document.getElementById("back").style.display = "block";
    } else {
      document.getElementById("back").style.display = "none";
    }
    document.getElementById("next").style.display = "block";
  }

  if (screenNb >= 4) {
    document.getElementById("movingKb").style.left = movingKbPos[movingKbPos.length - 1] + "px";
    document.getElementById("skipbutton").style.display = "none";
  } else {
    document.getElementById("skipbutton").style.display = "block";
  }

  var id = 'screen' + (
  screenNb).toString();
  var displaySlide = document.getElementById(id);

  for (var i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  for (var i = 0; i < functionDescription.length; i++) {
    functionDescription[i].classList.remove("fadeIn");
  }

  displaySlide.style.display = 'block';

  // var fadeInEl = document.getElementById(id).getElementsByClassName("functionDescription")[0];
  // if (fadeInEl != undefined) {
  //   setTimeout(function() {
  //     fadeInEl.classList.toggle("fadeIn");
  //   }, 0);
  // }
}

function kBMoved() {
  console.log(start);

  if (screenNb < 4) {
    mainOverlay[screenNb - 1].classList.add("fadeIn");
    if (screenNb > 0) {
      document.getElementById("screen" + screenNb.toString()).getElementsByClassName("functionDescription")[0].classList.toggle("fadeIn");
    }
  } else {
    document.getElementById("movingKb").classList.remove("fadeIn");
    document.getElementById("screen4").classList.add("fadeIn");
  }
  if (screenNb == 1) {
    start = false;
  }

  if (screenNb == 2) {
    if (fnLockInterval) {
      fnLockInterval = window.setInterval(fnLockFnc, 1750);
    }
  }
  if (screenNb != 2 && !start) {
    fnIncr = 0;
    window.clearInterval(fnLockInterval);
    el = document.getElementById("screen2").getElementsByClassName("overlays");
    for (var i = 0; i < el.length; i++) {
      console.log(el[i]);
      el[i].classList.remove("fadeIn");
    }
  }
}

function fnLockFnc() {
  var el = document.getElementById('screen2').getElementsByClassName('overlays');
  switch (fnIncr) {
    case 0:
      el[0].classList.add("fadeIn");
      el[1].classList.remove("fadeIn");
      el[2].classList.add("fadeIn");
      break;
    case 1:
      el[0].classList.remove("fadeIn");
      el[1].classList.add("fadeIn");
      el[2].classList.remove("fadeIn");
      break;
    case 2:
      el[0].classList.add("fadeIn");
      el[1].classList.add("fadeIn");
      el[2].classList.remove("fadeIn");
      break;
    case 3:
      el[0].classList.remove("fadeIn");
      el[1].classList.remove("fadeIn");
      el[2].classList.add("fadeIn");
      break;
  }

  fnIncr++;
  fnIncr %= 4;
}

// ----------------------------------------------------------------------------------------
function jumpto(slide) {
  screenNb = slide;
  slideMove(0);
}

function iconSelected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRightSelected.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeftSelected.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/closeSelected.png";
  }
}

function iconDeselected(el) {
  if (el.children.length > 1) {
    if (el.getElementsByTagName('div')[0].classList.contains('btn_next')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronRight.png";
    } else if (el.getElementsByTagName('div')[0].classList.contains('btn_back')) {
      el.getElementsByTagName('img')[0].src = "resources/icons/ChevronLeft.png";
    }
  } else {
    el.getElementsByTagName('img')[0].src = "resources/icons/close.png";
  }
}
