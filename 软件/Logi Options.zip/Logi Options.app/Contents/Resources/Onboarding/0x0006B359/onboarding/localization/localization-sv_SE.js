title0 = "Välkommen till ERGO K860"
desc0 = "Låt oss bli bekväma."

title1 = "Anpassa knappar"
desc1 = "Anpassa knapparna så att de uppträder på önskat sätt."

title2 = "Ställa in F-knapparna"
desc2 = "Växla mellan media och Fn-knapparna när som helst genom att trycka på Fn Lås."

title3 = "EASY SWITCH"
desc3 = "Anslut upp till tre enheter med Logitech Unifying-mottagare eller <span class=italic>Bluetooth</span>."

title4 = "DET ÄR KLART"
desc4 = "Du kan när som helst justera ERGO K860-inställningarna i Logitech Options"

easySwitch0 = "Enhet 1"
easySwitch1 = "Enhet 2"
easySwitch2 = "Enhet 3"

btn_continue = "FORTSÄTT";
skip = "HOPPA ÖVER";
btn_continueToSetup = "TILLBAKA TILL OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Klicka här</a> för att lära dig mer om hur du konfigurerar din arbetsstation.";

btn_back = "TILLBAKA";
btn_next = "NÄSTA";

link_website = "%logiwebsite%"
