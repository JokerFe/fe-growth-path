title0 = "Bienvenido a ERGO K860"
desc0 = "Vamos a ponernos cómodos."

title1 = "Personalizar teclas"
desc1 = "Personalice las teclas para que se comporten de la manera deseada."

title2 = "Definir teclas F"
desc2 = "Alterne cuando quiera entre las teclas Fn y las multimedia pulsando Bloqueo de Fn."

title3 = "EASY SWITCH"
desc3 = "Conecte hasta tres dispositivos usando el receptor Logitech Unifying o <span class=italic>Bluetooth</span>."

title4 = "TODO LISTO"
desc4 = "Puede ajustar su configuración de ERGO K860 cuando quiera en Logitech Options"

easySwitch0 = "Dispositivo 1"
easySwitch1 = "Dispositivo 2"
easySwitch2 = "Dispositivo 3"

btn_continue = "CONTINUAR";
skip = "OMITIR";
btn_continueToSetup = "REGRESAR A OPTIONS";
subdesc = "<a href=http://www.ergosetup.logi.com>Haga clic aquí</a> para obtener más información sobre cómo configurar su estación de trabajo.";

btn_back = "ATRÁS";
btn_next = "SIGUIENTE";

link_website = "%logiwebsite%"
