title0 = "MX KEYS へようこそ"
desc0 = "考えましょう。 マスターしましょう。"

title1 = "バックライト"
desc1 = "周辺光センサーは、自然光が十分ある場合に、節電のためにバックライトレベルを適応させます。 強調表示された 2 つのキーを使って、バックライトを手動で変更します。"

title2 = "バッテリー通知"
desc2 = "電池寿命が 10% 未満になると、バックライトがオフになります。 LED が赤で点滅し、画面上に通知が表示されます。"

title3 = "キーをカスタマイズ"
desc3 = "デフォルトのショートカットがいくつか設定されていますが、自分で作成することもできます。"

title4 = "F キーを設定する"
desc4 = "Fn+Esc を押して、いつでもメディアキーと Fn キーの間で切り替えることができます。 Fn を押し続ける必要なしに、F キーを自由に使用できます。"

title5 = "EASY SWITCH"
desc5 = "Logicool Unifying レシーバーまたは Bluetooth を使用して、最大 3 台のデバイスを接続。"

title6 = "準備が完了しました"
desc6 = "Logicool Options で MX Keys の設定をいつでも調整することができます。"

appTitle_fallback = "その他のすべてのアプリケーション";

showDesktop = "デスクトップの表示"
keystrokeAssignmentMac = "キーストロークの割当て：cmd + C"
keystrokeAssignmentWindows = "キーストロークの割当て：ctrl + C"
openApp = "アプリケーションを開く：Google Chrome"

easySwitch0 = "デバイス 1"
easySwitch1 = "デバイス 2"
easySwitch2 = "デバイス 3"

btn_continue = "続行";
skip = "スキップ";
btn_continueToSetup = "OPTIONS に戻る";

btn_back = "戻る";
btn_next = "次へ";

link_website = "%logiwebsite%"
