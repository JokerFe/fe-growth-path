title0 = "VÄLKOMMEN TILL MX KEYS"
desc0 = "Tänk det. Bemästra det."

title1 = "BAKGRUNDSBELYSNING"
desc1 = "En sensor känner av det omgivande ljuset och anpassar bakgrundsbelysningsnivån för att spara ström när det finns tillräckligt med naturligt ljus. Använd de två markerade knapparna för att ändra bakgrundsbelysningen manuellt."

title2 = "BATTERIMEDDELANDEN"
desc2 = "Bakgrundsbelysningen stängs av när batteritiden är lägre än 10 %. Indikatorlampan blinkar rött och du får ett meddelande på skärmen."

title3 = "ANPASSA KNAPPAR"
desc3 = "Vi har ställt in några standardgenvägar, men du kan också skapa egna."

title4 = "STÄLLA IN F-KNAPPARNA"
desc4 = "Växla mellan media och Fn-knapparna när som helst genom att trycka på Fn+Esc. Använd F-knapparna fritt – du behöver inte hålla in Fn."

title5 = "EASY SWITCH"
desc5 = "Anslut upp till tre enheter med Logitech Unifying-mottagare eller Bluetooth."

title6 = "DET ÄR KLART"
desc6 = "Du kan när som helst justera MX Keys-inställningarna i Logitech Options"

appTitle_fallback = "ALLA ANDRA APPLIKATIONER";

showDesktop = "Visa skrivbord"
keystrokeAssignmentMac = "Tangentkommando: cmd+C"
keystrokeAssignmentWindows = "Tangentkommando: ctrl+C"
openApp = "Öppna applikation: Google Chrome"

easySwitch0 = "Enhet 1"
easySwitch1 = "Enhet 2"
easySwitch2 = "Enhet 3"

btn_continue = "FORTSÄTT";
skip = "HOPPA ÖVER";
btn_continueToSetup = "TILLBAKA TILL OPTIONS";

btn_back = "TILLBAKA";
btn_next = "NÄSTA";

link_website = "%logiwebsite%"
