title0 = "TERVETULOA MX KEYSIN KÄYTTÄJÄKSI"
desc0 = "Ajattele se. Ota se haltuun."

title1 = "TAUSTAVALAISTUS"
desc1 = "Ympäristön valontunnistin mukautuu taustavalaistukseen, mikä säästää akkua silloin, kun luonnonvaloa on riittävästi. Voit vaihtaa käsin taustavalaistuksen tasoa kahdesta valaistusta näppäimestä."

title2 = "AKUN ILMOITUKSET"
desc2 = "Taustavalot sammuvat, kun akun varaustaso laskee alle 10 prosenttiin. LED-valo vilkkuu tällöin punaisena ja näytöllä näkyy ilmoitus."

title3 = "NÄPPÄIMISTÖN MUKAUTUS"
desc3 = "Näppäimistössä on joitakin oletuspikanäppäimiä, mutta voit määrittää niitä myös itse."

title4 = "F-NÄPPÄINTEN MÄÄRITYS"
desc4 = "Voit vaihtaa median ja Fn-näppäinten välillä milloin vain painamalla Fn+Esc. F-näppäimiä voi käyttää vapaasti: Fn-näppäintä ei tarvitse pitää painettuna."

title5 = "EASY SWITCH"
desc5 = "Voit yhdistää jopa kolme laitetta Logitech Unifying- vastaanottimen tai Bluetooth-yhteyden kautta."

title6 = "VALMISTA TULI"
desc6 = "Voit muokata MX Keys -asetuksia milloin tahansa Logitech Options -ohjelmistossa."

appTitle_fallback = "KAIKKI MUUT SOVELLUKSET";

showDesktop = "Näytä työpöytä"
keystrokeAssignmentMac = "Näppäinten määritys: cmd+C"
keystrokeAssignmentWindows = "Näppäinten määritys: ctrl+C"
openApp = "Avaa sovellus: Google Chrome"

easySwitch0 = "Laite 1"
easySwitch1 = "Laite 2"
easySwitch2 = "Laite 3"

btn_continue = "JATKA";
skip = "OHITA";
btn_continueToSetup = "TAKAISIN OPTIONSIIN";

btn_back = "EDELLINEN";
btn_next = "SEURAAVA";

link_website = "%logiwebsite%"
