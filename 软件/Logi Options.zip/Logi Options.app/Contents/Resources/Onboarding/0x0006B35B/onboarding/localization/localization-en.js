title0 = "WELCOME TO MX KEYS"
desc0 = "Think it. Master it."

title1 = "BACKLIGHTING"
desc1 = "The ambient light sensor adapts your backlighting level to save power when there is enough natural light. Use the two highlighted keys to manually change the backlighting."

title2 = "BATTERY NOTIFICATIONS"
desc2 = "Backlighting turns off when battery life goes below 10%. The LED will blink red and you'll get an-onscreen notification."

title3 = "CUSTOMIZE KEYS"
desc3 = "We've set some default shortcuts, but you can also create your own."

title4 = "SET YOUR F-KEYS"
desc4 = "Switch between media and Fn keys any time by pressing Fn+Esc. Use F-keys freely — no need to hold Fn."

title5 = "EASY SWITCH"
desc5 = "Connect up to 3 devices using Logitech Unifying receiver or Bluetooth."

title6 = "YOU ARE ALL SET"
desc6 = "You can adjust your MX Keys settings at any time in Logitech Options"

appTitle_fallback = "ALL OTHER APPLICATIONS";

showDesktop = "Show Desktop"
keystrokeAssignmentMac = "Keystroke assignment : cmd + C"
keystrokeAssignmentWindows = "Keystroke assignment : ctrl + C"
openApp = "Open Application : Google Chrome"

easySwitch0 = "Device 1"
easySwitch1 = "Device 2"
easySwitch2 = "Device 3"

btn_continue = "CONTINUE";
skip = "SKIP";
btn_continueToSetup = "BACK TO OPTIONS";

btn_back = "BACK";
btn_next = "NEXT";

link_website = "%logiwebsite%"
