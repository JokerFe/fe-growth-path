title0 = "WILLKOMMEN ZU MX KEYS"
desc0 = "Stellen Sie sich das vor. Beherrschen Sie es."

title1 = "HINTERGRUNDBELEUCHTUNG"
desc1 = "Der Sensor für die Umgebungsbeleuchtung passt die Hintergrundbeleuchtung an, um bei ausreichendem natürlichem Licht Energie zu sparen. Mit den beiden hervorgehobenen Tasten können Sie die Hintergrundbeleuchtung manuell ändern."

title2 = "BENACHRICHTIGUNGEN ZUM AKKULADESTAND"
desc2 = "Die Hintergrundbeleuchtung erlischt, wenn der Ladestand unter 10 % sinkt. Die LED blinkt rot und Sie erhalten eine Benachrichtigung auf dem Bildschirm."

title3 = "TASTEN ANPASSEN"
desc3 = "Wir haben einige Standard-Shortcuts bereitgestellt, Sie können jedoch auch eigene erstellen."

title4 = "F-TASTEN FESTLEGEN"
desc4 = "Durch Drücken von Fn+Esc können Sie jederzeit zwischen Multimedia- und Funktionstasten wechseln. Die F-Tasten können problemlos verwendet werden – ohne die Fn-Taste gedrückt zu halten."

title5 = "EASY SWITCH"
desc5 = "Schließen Sie bis zu 3 Geräte über den Logitech Unifying Empfänger oder Bluetooth an."

title6 = "ALLES FERTIG"
desc6 = "Sie können die Einstellungen für MX Keys jederzeit in Logitech Options anpassen"

appTitle_fallback = "ALLE ANDEREN ANWENDUNGEN";

showDesktop = "Desktop anzeigen"
keystrokeAssignmentMac = "Tastenanschlag-Zuweisung: CMD + C"
keystrokeAssignmentWindows = "Tastenanschlag-Zuweisung: Strg + C"
openApp = "Anwendung öffnen: Google Chrome"

easySwitch0 = "Gerät 1"
easySwitch1 = "Gerät 2"
easySwitch2 = "Gerät 3"

btn_continue = "WEITER";
skip = "ÜBERSPRINGEN";
btn_continueToSetup = "ZURÜCK ZU OPTIONS";

btn_back = "ZURÜCK";
btn_next = "WEITER";

link_website = "%logiwebsite%"
