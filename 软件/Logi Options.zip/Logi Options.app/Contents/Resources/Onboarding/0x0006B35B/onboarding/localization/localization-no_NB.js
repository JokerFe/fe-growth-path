title0 = "VELKOMMEN TIL MX KEYS"
desc0 = "Tenk på det. Mestre det."

title1 = "BAKBELYSNING"
desc1 = "Den omgivelseslyssensoren tilpasser bakbelysningsnivået for å spare strøm når det er nok naturlig lys. Bruk de to uthevede tastene for å endre bakbelysningen manuelt."

title2 = "BATTERIVARSLER"
desc2 = "Bakbelysningen slås av når batterinivået går under 10 %. Indikatorlampen blinker rødt, og du ser et varsel på skjermen."

title3 = "TILPASS TASTER"
desc3 = "Vi har opprettet flere standard hurtigtaster, men du kan også opprette dine egne."

title4 = "TILORDNE F-TASTER"
desc4 = "Bytt mellom medie- og Fn-taster når som helst ved å trykke på Fn + Esc. Bruk F-tastene fritt – du trenger ikke å holde inne Fn-tasten."

title5 = "EASY SWITCH"
desc5 = "Koble til opptil 3 enheter ved å bruke Logitech Unifying-mottakeren eller Bluetooth."

title6 = "DU ER KLAR TIL Å SETTE I GANG"
desc6 = "Du kan når som helst justere innstillingene for MX Keys i Logitech Options."

appTitle_fallback = "ALLE ANDRE PROGRAMMER";

showDesktop = "Vis skrivebord"
keystrokeAssignmentMac = "Tastetilordning: cmd + C"
keystrokeAssignmentWindows = "ambient light ctrl + C"
openApp = "Åpne appen: Google Chrome"

easySwitch0 = "Enhet 1"
easySwitch1 = "Enhet 2"
easySwitch2 = "Enhet 3"

btn_continue = "FORTSETT";
skip = "HOPP OVER";
btn_continueToSetup = "TILBAKE TIL OPTIONS";

btn_back = "TILBAKE";
btn_next = "NESTE";

link_website = "%logiwebsite%"
