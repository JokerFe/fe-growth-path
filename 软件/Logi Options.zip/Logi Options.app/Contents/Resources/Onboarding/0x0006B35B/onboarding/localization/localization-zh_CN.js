title0 = "欢迎使用 MX KEYS"
desc0 = "了解它。 掌控它。"

title1 = "背光"
desc1 = "环境光线传感器可在自然光充足时自适应调节背光亮度以节省电量。 使用高亮的两个按键手动调节背光。"

title2 = "电量通知"
desc2 = "电量低于 10% 时将自动关闭背光。 LED 指示灯将闪烁红色，并且您将收到屏幕通知。"

title3 = "自定义按键"
desc3 = "我们已预设默认快捷键，您也可以创建自己的专属快捷键。"

title4 = "设置 F 键"
desc4 = "只需按下 Fn+Esc，即可在媒体控制和 Fn 键之间轻松切换。 轻松使用 F 键，无需按住 Fn。"

title5 = "EASY SWITCH"
desc5 = "使用 Logitech Unifying™ 优联接收器或蓝牙，连接多达 3 个设备。"

title6 = "您已准备就绪"
desc6 = "您可以随时在 Logitech Options 中调节 MX Keys 的设置"

appTitle_fallback = "所有应用程序";

showDesktop = "显示桌面"
keystrokeAssignmentMac = "按键分配：cmd + C"
keystrokeAssignmentWindows = "按键分配：ctrl + C"
openApp = "打开应用程序：Google Chrome"

easySwitch0 = "设备 1"
easySwitch1 = "设备 2"
easySwitch2 = "设备 3"

btn_continue = "继续";
skip = "跳过";
btn_continueToSetup = "回到 OPTIONS";

btn_back = "返回";
btn_next = "下一步";

link_website = "%logiwebsite%"
