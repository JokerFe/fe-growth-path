title0 = "VELKOMMEN TIL MX KEYS"
desc0 = "Tænk det. Brug det."

title1 = "BAGBELYSNING"
desc1 = "Sensoren for det omgivende lys tilpasser dit bagbelysningsniveau for at spare strøm, når der er nok naturligt lys. Brug de to fremhævede taster til manuelt at ændre bagbelysningen."

title2 = "BATTERIINFORMATION"
desc2 = "Bagbelysning slukkes, når batterilevetiden kommer under 10 %. LED-indikatoren blinker rødt og der vises en meddelelse på skærmen."

title3 = "TILPAS TASTER"
desc3 = "Vi har konfigureret nogle standardgenveje, men du kan også oprette dine egne."

title4 = "KONFIGURER DINE F-TASTER"
desc4 = "Skift mellem medie- og Fn-taster når som helst ved at trykke på Fn+Esc. Brug F-tasterne frit – det ikke nødvendigt at holde Fn nede."

title5 = "EASY SWITCH"
desc5 = "Tilslut op til 3 enheder ved hjælp af en Logitech Unifying-modtager eller Bluetooth."

title6 = "DU ER NU HELT KLAR"
desc6 = "Du kan når som helst tilpasse indstillingerne for MX Keys i Logitech Options"

appTitle_fallback = "ALLE ANDRE APPS";

showDesktop = "Vis skrivebordet"
keystrokeAssignmentMac = "Tildeling af tastefunktioner: kommando + C"
keystrokeAssignmentWindows = "Tildeling af tastefunktioner: ctrl + C"
openApp = "Åbn program: Google Chrome"

easySwitch0 = "Enhed 1"
easySwitch1 = "Enhed 2"
easySwitch2 = "Enhed 3"

btn_continue = "FORTSÆT";
skip = "SPRING OVER";
btn_continueToSetup = "TILBAGE TIL OPTIONS";

btn_back = "TILBAGE";
btn_next = "NÆSTE";

link_website = "%logiwebsite%"
