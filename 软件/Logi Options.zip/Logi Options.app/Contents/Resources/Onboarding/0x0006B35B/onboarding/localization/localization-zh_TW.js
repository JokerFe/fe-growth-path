title0 = "歡迎使用 MX KEYS"
desc0 = "思考。 掌握。"

title1 = "背光"
desc1 = "環境光線感應器會在有足夠的自然光源時，調整背光等級以節省電力。 使用這兩個醒目標示的按鍵可手動變更背光。"

title2 = "電池通知"
desc2 = "電池電力低於 10% 時，會關閉背光。 LED 指示燈會閃爍紅燈，而且您會收到螢幕通知。"

title3 = "自訂按鍵"
desc3 = "我們設定了一些預設的快捷鍵，但您也可以建立自己的快捷鍵。"

title4 = "設定您的 F 功能鍵"
desc4 = "按下 Fn+Esc 可隨時切換媒體與 Fn 按鍵。 自由使用 F 功能鍵，無須按住 Fn 鍵。"

title5 = "EASY SWITCH"
desc5 = "使用羅技 Unifying 接收器或藍牙功能最多可連線到 3 個裝置。"

title6 = "您已完成所有工作"
desc6 = "您可以在 Logitech Options 中隨時調整您 MX Keys 的設定"

appTitle_fallback = "所有其他應用程式";

showDesktop = "顯示桌面"
keystrokeAssignmentMac = "按鍵指派：cmd + C"
keystrokeAssignmentWindows = "按鍵指派：ctrl + C"
openApp = "開啟應用程式：Google Chrome"

easySwitch0 = "裝置 1"
easySwitch1 = "裝置 2"
easySwitch2 = "裝置 3"

btn_continue = "繼續";
skip = "跳過";
btn_continueToSetup = "回到 OPTIONS";

btn_back = "上一頁";
btn_next = "下一頁";

link_website = "%logiwebsite%"
